# WIZARD SCAN — v5 (real-time + MC fix + group kill-switch)

Deploy: Railway → upload these files → same env vars as before
(BOT_TOKEN, OWNER_ID, USERBOT_API_ID, USERBOT_API_HASH, USERBOT_PHONE ...).

## Kya fix hua

1. **Late tracking khatam (real-time)**
   - Telethon MTProto realtime event handler + scan loop ab har **3 sec** (pehle 5s).
   - DexScreener retry ab pehle 16 sec me 8 baar (2s gap) — naya token turant pakra jata hai.
   - Bulk DexScreener refresh (30 tokens / 1 request) har tick → SpyDefi/Kolscope jaisi speed.

2. **Galat market cap X alerts me fix**
   - Pehle 2X, 3X, 4X sab posts me same live MC chapta tha.
   - Ab har milestone ka MC = entry MC × us multiple ka exact value.
   - Sirf sab se upar wala (naya) milestone live MC use karta hai, wo bhi tab jab
     live value us multiple ke 1.5x se zyada na ho (phantom MC guard).

3. **Groups / lounge me bot ab bilkul band**
   - Har update se pehle chalne wala kill-switch: group, supergroup aur channel
     ke updates turant stop (ApplicationHandlerStop).
   - Telethon realtime handler sirf **broadcast KOL channels** accept karta hai —
     megagroup/lounge ke CA kabhi track nahi honge.

4. **Update ke baad purani posts ka flood band**
   - Startup pe baseline banta hai; jab tak baseline complete na ho scan job chalti hi nahi.
   - Har post ka timestamp check hota hai — **15 min se purani post kabhi alert nahi karti**,
     sirf "seen" mark hoti hai.
   - Fail-safe timer: agar baseline kisi wajah se atak jaye to 4 min baad scanning
     safely enable ho jati hai (purani posts phir bhi filter rehti hain).

5. **N/A details khatam**
   - Agar symbol ya market cap na mile to alert **post hi nahi hoti** — call defer ho jati hai.
   - Jaise hi DexScreener/Jupiter/Pump.fun/GeckoTerminal se data aata hai,
     monitoring job wahi alert automatically sahi data ke sath bhej deti hai.
