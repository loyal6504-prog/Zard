import os
import re
import io
import json
import time
import uuid
import html
import logging
import requests
import asyncio
import functools
from datetime import datetime, timedelta
from collections import defaultdict
from bs4 import BeautifulSoup
from telegram import (
    Bot, Update, InlineKeyboardButton, InlineKeyboardMarkup, BotCommand,
)
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    ContextTypes, MessageHandler, filters, TypeHandler, ApplicationHandlerStop,
)
from telegram.error import TelegramError

logging.basicConfig(format="%(asctime)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

# ─── Config ───────────────────────────────────────────────────────────────────
BOT_TOKEN  = os.environ.get("BOT_TOKEN", "")
OWNER_ID   = int(os.environ.get("OWNER_ID", "0"))
OWNER_ID_2 = int(os.environ.get("OWNER_ID_2", "0"))
OWNER_IDS  = [oid for oid in [OWNER_ID, OWNER_ID_2] if oid != 0]
# Telegram backup chat — set BACKUP_CHAT_ID env var, or defaults to OWNER_ID
BACKUP_CHAT_ID = int(os.environ.get("BACKUP_CHAT_ID", OWNER_ID or 0))
BACKUP_TAG     = "BOT_BACKUP_v1"
# Bot ka apna user ID (token ka pehla hissa) — userbot is ID se bot ka chat dhundta hai
BOT_USER_ID    = int(BOT_TOKEN.split(":")[0]) if BOT_TOKEN and ":" in BOT_TOKEN else 0
OWNER_API_ID   = int(os.environ.get("USERBOT_API_ID", "") or os.environ.get("OWNER_API_ID", "0") or "0")
OWNER_API_HASH = os.environ.get("USERBOT_API_HASH", "") or os.environ.get("OWNER_API_HASH", "")
OWNER_PHONE    = os.environ.get("USERBOT_PHONE", "") or os.environ.get("OWNER_PHONE", "")

TARGET_CHANNEL  = "@WizardScan"
TG_CHANNEL_LINK = "https://t.me/WizardScan"
BOT_LINK        = "https://t.me/WIZARD_SCAN_BOT"
X_CHANNEL_LINK  = "https://t.me/WizardscanX"
X_ALERT_CHANNEL = ""  # X removed

# Channel post IDs for auto-update
POST_TRENDING    = 135
POST_LEADERBOARD = 136
POST_CHAMPIONS   = 137
POST_TRENDING_1  = 3560   # SOL + ETH + BSC trending (tokens 1-15)
POST_TRENDING_2  = 3562   # Robinhood + BASE + TON trending (tokens 16-30)

# Premium emoji IDs for new trending post 3560 (positions 1-15)
TRENDING2_EMOJIS_POS = {
    1:  5997041433582771180,
    2:  5996630843299208589,
    3:  5996651562221444470,
    4:  5997030232308063346,
    5:  5994684063472950720,
    6:  5996751574829898863,
    7:  5996820298601602863,
    8:  5996895748292091460,
    9:  5994803716966850151,
    10: 5996680656329907526,
    11: 5996586313078283620,
    12: 5996979577463774764,
    13: 5994808896697409956,
    14: 5997096288905077806,
    15: 5996926856740216806,
    # positions 16-30 for post 3562
    16: 5999182938636295448,
    17: 5996815157525751350,
    18: 5998989699467714710,
    19: 5996964184300985351,
    20: 5996607147964636937,
    21: 5999300878438243947,
    22: 5999226708648009426,
    23: 5999176637919279146,
    24: 5999344077219307323,
    25: 5999144876636118289,
    26: 5996733888154576402,
    27: 5999311869259553343,
    28: 5996818529075077224,
    29: 5999155257572072966,
    30: 5996565667170493190,
}

# Chain header emojis for new trending posts
TRENDING2_CHAIN_EMOJIS = {
    "SOL":  5999041428053826576,
    "ETH":  5996776519999955154,
    "BSC":  5998847136618259004,
    "RH":   5996639403169030164,
    "BASE": 5999317663170436624,
    "TON":  5994646315005387738,
}
# MC/arrow emoji for new trending posts
TRENDING2_ARROW_EMOJI = 5996709080423472380
TRENDING2_MC_EMOJI    = 5996883503340330760

# ─── File paths ───────────────────────────────────────────────────────────────
# DATA_DIR lets all persistent bot data live on a Railway Volume (survives redeploys).
# Set DATA_DIR=/app/data as an env var once a Volume is mounted there; defaults to "."
# so it still works unchanged when running locally / without a volume.
DATA_DIR = os.environ.get("DATA_DIR", ".")
os.makedirs(DATA_DIR, exist_ok=True)
def _dp(name):  # data path helper
    return os.path.join(DATA_DIR, name)

USERS_FILE            = _dp("users.json")
CHANNELS_FILE         = _dp("channels.json")
BOT_CONFIG_FILE       = _dp("bot_config.json")
USERBOT_SESSION_FILE  = _dp("userbot_session.txt")
X_ACCOUNTS_FILE       = _dp("x_accounts.json")
SUBSCRIPTIONS_FILE    = _dp("subscriptions.json")
LINKED_CHANNELS_FILE  = _dp("linked_channels.json")
PENDING_REQUESTS_FILE = _dp("pending_requests.json")
TRACKED_FILE          = _dp("tracked_calls.json")
MILESTONES_FILE       = _dp("sent_milestones.json")
SEEN_FILE             = _dp("seen_messages.json")
ADMINS_FILE           = _dp("admins.json")
MILESTONE_POSTS_FILE  = _dp("milestone_posts.json")
CHANNEL_SUBS_FILE     = _dp("channel_subs.json")
MOMENTUM_SENT_FILE    = _dp("momentum_sent.json")
CHANNEL_POINTS_FILE   = _dp("channel_points.json")
TRENDING_BLACKLIST_FILE  = _dp("trending_blacklist.json")
PINNED_TRENDING_FILE     = _dp("pinned_trending.json")
KOL_OWNERS_FILE         = _dp("kol_owners.json")   # channel.lower() -> telegram user_id of owner
TRENDING_CACHE_FILE   = _dp("trending_cache.json")
TRENDING2_CACHE_FILE  = _dp("trending2_cache.json")

# ─── Images ───────────────────────────────────────────────────────────────────
IMG_PROMO     = "attached_assets/IMG_20260613_095837_780_1781330812860.jpg"   # Promotion Hub
IMG_CONTACT   = "attached_assets/IMG_20260613_095833_447_1781330812885.jpg"   # Contact / Chat
IMG_LEADERBOARD = "attached_assets/IMG_20260708_021612_436_1783459182111.jpg" # Leaderboard
IMG_FASTTRACK = "attached_assets/IMG_20260613_095829_072_1781330812925.jpg"   # Fast Track
IMG_KOLREQUEST = "attached_assets/IMG_20260613_095820_581_1781330812951.jpg"  # Request KOL
IMG_LINKME    = "attached_assets/IMG_LINKME.png"                              # /linkme info
IMG_TRACKED   = "attached_assets/IMG_20260704_021900_436_1783113819561.jpg"   # Tracked KOLs
IMG_HISTORY   = "attached_assets/IMG_HISTORY.png"                             # /history info
IMG_ALERT     = "attached_assets/IMG_20260613_095809_422_1781330812978.jpg"   # Alert Rules
IMG_XCOMMAND  = "attached_assets/file_00000000ef9872078bbbb84ad23477b8_1781330813005.png"  # X/Twitter
VID_START     = "attached_assets/VID_20260613_095844_594_1781330812838.mp4"   # Start video (5-sec)
VID_PROMO     = "attached_assets/VID_20260613_095756_826_1781330812992.mp4"   # Command/promo video
VID_COMMAND   = "attached_assets/VID_COMMAND.mp4"                             # /command menu video
VID_XRAY      = "attached_assets/hailuo-2_3_X-Ray_Scan_text_ma_effects_dal_dain._Crystall_ball__1782604190889.mp4"  # X-Ray Report reply video
VID_HISTORY   = "attached_assets/hailuo-2_3_Clouds_ma_motion_add_krain_crow_ma_motion_add_krain_1782605705389.mp4"  # Call History reply video
VID_CHAT_US   = "attached_assets/hailuo-2_3_Wizard_Scan_Text_ma_wave_motion_add_kr_krain._Wizar_1783457473002.mp4"  # Chat With Us reply video
IMG_HASHTAG   = "hashtag.png"  # Hashtag post image (same folder as bot.py)

# ─── Momentum Active videos (rotating) ────────────────────────────────────────
VID_MOMENTUM_LIST = [
    "attached_assets/hailuo-2_3_Photo_ma_effects_dal_dain_aur_objects_ma_motivation_1782603110946.mp4",
    "attached_assets/hailuo-2_3_Text_aur_baki_cheezon_ma_powerful_effects_aur_motio_1782603110959.mp4",
    "attached_assets/hailuo-2_3_Momentum_Active_text_ma_powerful_effects_dal_dain.__1782603110982.mp4",
    "attached_assets/hailuo-2_3_Momentum_Active_ma_effects_aur_motion_add_krain._Cr_1782603110994.mp4",
    "attached_assets/hailuo-2_3_Crystal_ball_ma_effects_dal_dain._Aur_skull_ma_vibr_1782603111012.mp4",
]

HASHTAG_CAPTION = (
    "#WizardScan #Crypto #CryptoCalls #CryptoAlerts #KOL #KOLCalls "
    "#CryptoTracking #Memecoins #Altcoins #GemHunter #CryptoCommunity "
    "#CryptoSignals #Moonshots #DeFi #Solana #Ethereum #BNBChain #BaseChain "
    "#OnChain #TokenCalls #CryptoGems #Trading #BullRun #MarketCap "
    "#100xGems #CryptoAlpha #Blockchain #TrendingTokens #KOLTracker "
    "#CallerLeaderboard #WizardCommunity #CryptoWizards #DYOR #Pumps"
)

X_MILESTONES = [2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 30, 35, 40, 45, 50,
                55, 60, 65, 70, 75, 80, 85, 90, 95, 100, 150, 200, 250, 300,
                500, 600, 700, 800, 900, 1000, 2000, 3000, 4000, 5000,
                6000, 7000, 8000, 9000, 10000,
                11000, 12000, 13000, 14000, 15000, 20000, 25000, 30000,
                40000, 50000, 60000, 70000, 80000, 90000, 100000]
MAX_MILESTONE = 1_000_000  # No upper cap — calls above 10kx also tracked for leaderboard/champion

SUPPORTED_CHAINS = {"ethereum": "ETH", "bsc": "BNB", "base": "BASE", "solana": "SOL",
                    "robinhood": "RH", "ton": "TON"}   # Robinhood L2 (EVM, OP-Stack)
CHAIN_TO_DEXPATH = {"SOL": "solana", "ETH": "ethereum", "BNB": "bsc", "BASE": "base",
                    "RH": "robinhood", "TON": "ton"}

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
}

ETH_CA_PATTERN = re.compile(r'0x[a-fA-F0-9]{40}')
SOL_CA_PATTERN = re.compile(r'\b[1-9A-HJ-NP-Za-km-z]{32,44}\b')
TON_CA_PATTERN = re.compile(r'\b(EQ|UQ)[A-Za-z0-9_-]{46}\b')  # TON user-friendly addresses (48 chars)
TW_LINK_RE     = re.compile(r'(?:twitter\.com|x\.com)/([A-Za-z0-9_]+)', re.IGNORECASE)
TG_MENTION_RE  = re.compile(r'^@([A-Za-z0-9_]{3,32})\s*$')

# ─── States ───────────────────────────────────────────────────────────────────
ST_NONE = ST_TEMPLATE = ST_MILESTONE_TMPL = ST_SET_MEDIA = None
ST_EDIT_BTN = ST_EDIT_START = ST_EDIT_CMD = ST_ADD_CMD2 = None
ST_USERBOT_OTP = ST_USERBOT_2FA = ST_BTN_NAME = ST_BTN_URL = None
ST_TEMPLATE         = "edit_template"
ST_LEADERBOARD_TMPL = "edit_leaderboard_tmpl"
ST_ADD_MOMENTUM_VID = "add_momentum_vid"
ST_ADD_XRAY_VID     = "add_xray_vid"
ST_RANGE_TMPL        = "edit_range_tmpl"

# Premium emoji IDs for leaderboard post 136
LEADERBOARD_PREMIUM_EMOJIS = {
    "star":  5823304208253723019,
    "arrow": 5823644661721341672,
    1:  5823249627809323607,
    2:  5823495591996432785,
    3:  5823660454316090458,
    4:  5823196112516817383,
    5:  5823474885959098519,
    6:  5823206733970940623,
    7:  5823190073792799582,
    8:  5823699920770572135,
    9:  5823170879583952565,
    10: 5823639825588166142,
}

# Premium emoji IDs for champions post 137
CHAMPIONS_PREMIUM_EMOJIS = {
    "star":  5915598335275703773,
    "arrow": 5823568391692099527,
    1:  5823670826662108929,
    2:  5823288900990278598,
    3:  5823289412091387748,
    4:  5823639666674377774,
    5:  5823199677339673551,
    6:  5823237610490835810,
    7:  5823618874737696599,
    8:  5823591889458176055,
    9:  5823593311092349714,
    10: 5823365544681676049,
}

# Premium emoji tags for user-facing bot messages (parse_mode="HTML")
PE_CRYSTAL = '<tg-emoji emoji-id="5361837567463399422">🔮</tg-emoji>'
PE_WAND    = '<tg-emoji emoji-id="5260426225599405269">🪄</tg-emoji>'
PE_ARROW   = '<tg-emoji emoji-id="5823462288820020063">➤</tg-emoji>'

# Premium emoji IDs for trending post 135
TRENDING_PREMIUM_EMOJIS = {
    "SOL":   5818711831652343968,
    "BASE":  5818705539525255782,
    "ETH":   5821222313051301501,
    "BNB":   5820961269234016758,
    "TON":   5996819753140756074,   # TON green emoji
    "arrow": 5823462288820020063,   # arrow separator between token name and MC
    1:  5821233187908492644,
    2:  5818765681952301203,
    3:  5821435678436631722,
    4:  5820945364970118156,
    5:  5821055556651065265,
    6:  5821457668669185609,
    7:  5821379616228515432,
    8:  5821401091064995694,
    9:  5821320251190550541,
    10: 5821001508782611959,
    11: 5823306407276977559,
    12: 5823285306102652498,
    13: 5823250426673241974,
    14: 5823535711285943606,
    15: 5823301407935045875,
    16: 5821131246859723209,
    17: 5823664190937636546,
    18: 5820910872087765095,
    19: 5823393766911778754,
    20: 5823595432806194944,
}

# ─── Alert premium emoji packs (rotate every 10 posts) ────────────────────────
TEER_EMOJI_ID = 5346105514575025401  # locked — never stored in config so restore can't change it
MOMENTUM_ACTIVE_EMOJI_ID = 5920079442159344914

# ─── Maestro premium emoji IDs (per colour) ──────────────────────────────────
MAE_EMOJIS = {
    "red":    5999201634628935297,
    "blue":   5999310937251650010,
    "white":  5999292610626199656,
    "purple": 5999301028762098619,
    "green":  5999321532935970751,
    "dropped":5998857204021599539,   # special: dropped-call post MAE
}
MAESTRO_REFLINK_BASE = "https://t.me/maestro?start="
MAESTRO_REF_SUFFIX   = "_r-wizard_scan"   # appended after CA

EMOJI_PACKS = [
    {   # 0: Red
        "name": "red",
        "crystal": 5909248376452424773,
        "kol":     5909159208636391630,
        "mae":     5999201634628935297,
        "bot":     5908820284177129986,
        "chain": {
            "SOL":  5920357369493069134,
            "ETH":  5920045855515091835,
            "BNB":  5920443749875326865,
            "BSC":  5920443749875326865,
            "BASE": 5920444029048200535,
            "RH":   5963142506550926896,  # Robinhood red
            "TON":  5996795301891939236,  # TON red
        },
    },
    {   # 1: Blue
        "name": "blue",
        "crystal": 5909056627637493639,
        "kol":     5904225055717467267,
        "mae":     5999310937251650010,
        "bot":     5906892114444164583,
        "chain": {
            "SOL":  5920151760818676194,
            "ETH":  5920015992607481576,
            "BNB":  5920511086372595188,
            "BSC":  5920511086372595188,
            "BASE": 5920360015192933467,
            "RH":   5962881320999721891,  # Robinhood blue
            "TON":  5996855753556630860,  # TON blue
        },
    },
    {   # 2: White
        "name": "white",
        "crystal": 5911492432440073438,
        "kol":     5909266939301076138,
        "mae":     5999292610626199656,
        "bot":     5908863744951197586,
        "chain": {
            "SOL":  5908783523552042618,
            "ETH":  5908947999324645137,
            "BNB":  5909194796735406168,
            "BSC":  5909194796735406168,
            "BASE": 5908768143274155036,
            "RH":   5962801335823770424,  # Robinhood white
            "TON":  5996599829340363765,  # TON white
        },
    },
    {   # 3: Purple
        "name": "purple",
        "crystal": 5909214897182352449,
        "kol":     5906881183752396796,
        "mae":     5999301028762098619,
        "bot":     5909039048336351478,
        "chain": {
            "SOL":  5911071315191668044,
            "ETH":  5908865196650143288,
            "BNB":  5908955077430746579,
            "BSC":  5908955077430746579,
            "BASE": 5909036321032118088,
            "RH":   5963059871380151413,  # Robinhood purple
            "TON":  5994634430830877776,  # TON purple
        },
    },
    {   # 4: Green
        "name": "green",
        "crystal": 5998815727522422466,
        "kol":     5872792324676788914,
        "mae":     5999321532935970751,
        "bot":     5875447065437282522,
        "chain": {
            "SOL":  5875048857544432514,
            "ETH":  5875284157327744482,
            "BNB":  5872901489860550331,
            "BSC":  5872901489860550331,
            "BASE": 5875142917328215269,
            "RH":   5963226709384765386,  # Robinhood green
            "TON":  5996819753140756074,  # TON green
        },
    },
]

ST_X_TEMPLATE      = "edit_x_template"
ST_ADD_DROPPED_VID = "add_dropped_vid"
ST_DROPPED_TMPL    = "edit_dropped_tmpl"

# ─── Dropped Call feature ─────────────────────────────────────────────────────
DROPPED_CALL_EMOJI = 5983470917475376700  # SOL chain emoji — default fallback when chain unknown

# Chain-specific emojis for the two header 🔮 in dropped-call posts
DROPPED_CHAIN_EMOJIS = {
    "SOL":  5983470917475376700,
    "ETH":  5985384617463520128,
    "BNB":  5985357610709163174,
    "BSC":  5985357610709163174,
    "BASE": 5983243825374566845,
    "RH":   5983463173649342071,
    "TON":  5996839913717242929,  # TON drop call emoji
}

# Specific emoji IDs for KOL / MAE / BOT links in dropped-call posts
DROPPED_KOL_EMOJI = 5965440348414025171
DROPPED_MAE_EMOJI = 5998857204021599539   # Special Maestro emoji for dropped-call posts
DROPPED_BOT_EMOJI = 5965392377924295836

# Forced pack used by dropped-call alert so KOL/MAE/BOT get their own emojis
_DROPPED_CALL_PACK = {
    "name": "dropped", "kol": DROPPED_KOL_EMOJI,
    "mae": DROPPED_MAE_EMOJI, "bot": DROPPED_BOT_EMOJI,
}

DEFAULT_DROPPED_TEMPLATE = (
    "🔮 <b>@{channel} Dropped a Call</b> 🔮\n\n"
    '<tg-emoji emoji-id="5877468380125990242">1️⃣</tg-emoji>Token Symbol  <tg-emoji emoji-id="5884123981706956210">➡️</tg-emoji>  ${symbol}\n'
    '<tg-emoji emoji-id="5877468380125990242">1️⃣</tg-emoji>Current MC      <tg-emoji emoji-id="5884123981706956210">➡️</tg-emoji>  {entry}\n'
    '<tg-emoji emoji-id="5877468380125990242">1️⃣</tg-emoji>Chain Symbol    <tg-emoji emoji-id="5884123981706956210">➡️</tg-emoji>  {chain}\n\n'
    "We've started tracking it and will continue to send performance alerts "
    "as the token progresses. Stay tuned!\n\n"
    "Ca: <code>{ca}</code>\n\n"
    '🔮<a href="{mae_link}">MAE</a>\n'
    '🔮<a href="{kol_link}">KOL</a>\n'
    '🔮<a href="{bot_link}">BOT</a>'
)
ST_MILESTONE_TMPL = "edit_milestone_tmpl"
ST_SET_MEDIA     = "set_media"
ST_EDIT_BTN      = "edit_button"
ST_EDIT_START    = "edit_start"
ST_EDIT_CMD      = "edit_command_text"
ST_ADD_CMD2      = "add_command_response"
ST_USERBOT_OTP      = "userbot_otp"
ST_USERBOT_2FA      = "userbot_2fa"
ST_SETTEMPLATE_EM   = "settemplate_em"
ST_BROADCAST_PICK      = "broadcast_pick"
ST_BROADCAST_MSG       = "broadcast_msg"
ST_MEDIABROADCAST_MSG  = "mediabroadcast_msg"
ST_SETPROMOLINK        = "set_promo_link"
ST_SETKOLOWNER_CH      = "setkolowner_channel"
ST_SETKOLOWNER_USER    = "setkolowner_user"
ST_SETKOLOWNER_PENDING_CH = ""  # temp storage per-user

# ─── Persistence ──────────────────────────────────────────────────────────────
def load_json(path, default):
    try:
        with open(path) as f: return json.load(f)
    except Exception: return default

def save_json(path, data):
    with open(path, "w") as f: json.dump(data, f, indent=2, ensure_ascii=False)

def load_users_dict():
    """Load users as dict {str(id): {id, username, name}}. Auto-converts old list format."""
    raw = load_json(USERS_FILE, {})
    if isinstance(raw, list):
        return {str(uid): {"id": uid, "username": None, "name": None} for uid in raw}
    return raw

def save_users_dict(d): save_json(USERS_FILE, d)

def load_users():
    """Return list of user IDs (backward compat)."""
    return [int(k) for k in load_users_dict().keys()]

def save_users(u): pass  # kept for backward compat — use save_users_dict
def load_channels():         return load_json(CHANNELS_FILE, [])
def save_channels(c):        save_json(CHANNELS_FILE, c)
def load_config():           return load_json(BOT_CONFIG_FILE, {})
def save_config(c):          save_json(BOT_CONFIG_FILE, c)
def load_x_accounts():
    data = load_json(X_ACCOUNTS_FILE, {})
    if isinstance(data, list):
        # Migrate old list format → dict {channel_lower: x_handle}
        result = {}
        for item in data:
            if isinstance(item, dict):
                ch = item.get("channel","").lstrip("@").lower()
                x  = (item.get("x","") or item.get("twitter","") or item.get("handle","")).lstrip("@")
                if ch and x:
                    result[ch] = x
        if result:
            save_json(X_ACCOUNTS_FILE, result)
        return result
    return data if isinstance(data, dict) else {}
def save_x_accounts(x):      save_json(X_ACCOUNTS_FILE, x)

def _get_channel_x_handle(channel):
    """Return X/Twitter handle for a channel (without @), or '' if not set."""
    return load_x_accounts().get(channel.lstrip("@").lower(), "")
def load_subscriptions():    return load_json(SUBSCRIPTIONS_FILE, [])
def save_subscriptions(s):   save_json(SUBSCRIPTIONS_FILE, s)
def load_channel_subs():     return load_json(CHANNEL_SUBS_FILE, {})
def save_channel_subs(s):    save_json(CHANNEL_SUBS_FILE, s)
def load_momentum_sent():    return load_json(MOMENTUM_SENT_FILE, {})
def save_momentum_sent(s):   save_json(MOMENTUM_SENT_FILE, s)
def load_channel_points():       return load_json(CHANNEL_POINTS_FILE, {})
def save_channel_points(p):      save_json(CHANNEL_POINTS_FILE, p)
def load_trending_blacklist():   return set(load_json(TRENDING_BLACKLIST_FILE, []))
def save_trending_blacklist(s):  save_json(TRENDING_BLACKLIST_FILE, sorted(s))
def load_pinned_trending():      return load_json(PINNED_TRENDING_FILE, {})
def save_pinned_trending(d):     save_json(PINNED_TRENDING_FILE, d)
def load_trending_cache():    return load_json(TRENDING_CACHE_FILE, {})
def save_trending_cache(d):   save_json(TRENDING_CACHE_FILE, d)
def load_trending2_cache():   return load_json(TRENDING2_CACHE_FILE, {})
def save_trending2_cache(d):  save_json(TRENDING2_CACHE_FILE, d)
def load_kol_owners():           return load_json(KOL_OWNERS_FILE, {})
def save_kol_owners(o):          save_json(KOL_OWNERS_FILE, o)

# Single asyncio lock to protect channel_points.json from concurrent read-modify-write
import asyncio as _asyncio
_points_lock = _asyncio.Lock()
def load_linked_channels():  return load_json(LINKED_CHANNELS_FILE, {})
def save_linked_channels(l): save_json(LINKED_CHANNELS_FILE, l)
def load_pending():          return load_json(PENDING_REQUESTS_FILE, {})
def save_pending(p):         save_json(PENDING_REQUESTS_FILE, p)
def load_admins():           return load_json(ADMINS_FILE, [])
def save_admins(a):          save_json(ADMINS_FILE, a)

def is_admin_or_owner(uid):
    return uid in OWNER_IDS or uid in load_admins()

def admin_only(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not update.effective_user or not is_admin_or_owner(update.effective_user.id):
            await update.message.reply_text("⛔ Admin/Owner only."); return
        return await func(update, context)
    wrapper.__name__ = func.__name__
    return wrapper

def _inc_channel_post_count():
    c = load_config()
    c["channel_post_count"] = c.get("channel_post_count", 0) + 1
    save_config(c)
    return c["channel_post_count"]

def cfg_get(key, default=None): return load_config().get(key, default)
def cfg_set(key, value):
    c = load_config(); c[key] = value; save_config(c)

# ─── Telegram Backup / Restore (Railway pe volume nahi — data Telegram pe save) ─
_ALL_DATA_FILES = None   # lazily built after all path vars defined

def _get_data_files():
    global _ALL_DATA_FILES
    if _ALL_DATA_FILES is None:
        _ALL_DATA_FILES = {
            "channels":        CHANNELS_FILE,
            "config":          BOT_CONFIG_FILE,
            "tracked":         TRACKED_FILE,
            "milestones":      MILESTONES_FILE,
            "seen":            SEEN_FILE,
            "milestone_posts": MILESTONE_POSTS_FILE,
            "channel_points":  CHANNEL_POINTS_FILE,
            "kol_owners":      KOL_OWNERS_FILE,
            "trending_cache":  TRENDING_CACHE_FILE,
            "trending2_cache": TRENDING2_CACHE_FILE,
            "trending_bl":     TRENDING_BLACKLIST_FILE,
            "subscriptions":   SUBSCRIPTIONS_FILE,
            "channel_subs":    CHANNEL_SUBS_FILE,
            "admins":          ADMINS_FILE,
            "x_accounts":      X_ACCOUNTS_FILE,
            "linked_channels": LINKED_CHANNELS_FILE,
            "pending":         PENDING_REQUESTS_FILE,
            "momentum_sent":   MOMENTUM_SENT_FILE,
            # ← users.json was previously missing from backup — members got wiped on /restorenow
            "users":           USERS_FILE,
        }
    return _ALL_DATA_FILES

async def backup_data_to_telegram(bot):
    """Sab JSON files pack karo aur BACKUP_CHAT_ID pe document bhejo."""
    if not BACKUP_CHAT_ID:
        logger.warning("backup_data_to_telegram: BACKUP_CHAT_ID not set, skipping.")
        return
    backup = {"_timestamp": datetime.utcnow().isoformat()}
    for key, filepath in _get_data_files().items():
        backup[key] = load_json(filepath, None)
    raw = json.dumps(backup, ensure_ascii=False, indent=2).encode()
    doc = io.BytesIO(raw)
    doc.name = "bot_backup.json"
    try:
        await bot.send_document(
            BACKUP_CHAT_ID,
            document=doc,
            caption=f"#{BACKUP_TAG} {datetime.utcnow().strftime('%Y-%m-%d %H:%M')} UTC",
        )
        logger.info("✅ Telegram backup sent.")
    except Exception as e:
        logger.warning(f"Telegram backup failed: {e}")

async def restore_data_from_telegram(userbot_cl):
    """Telethon se latest backup dhundo aur files restore karo."""
    if not userbot_cl:
        return False
    try:
        # Bot ne backup OWNER_ID (user's Telegram) pe bheja.
        # Userbot (owner's account) ke liye woh messages BOT ke chat mein dikhte hain.
        # Agar custom BACKUP_CHAT_ID set hai to wahi use karo.
        if BACKUP_CHAT_ID and BACKUP_CHAT_ID != OWNER_ID:
            peers_to_try = [BACKUP_CHAT_ID]
        else:
            # Try both: bot user ID aur owner's Saved Messages / direct search
            peers_to_try = [p for p in [BOT_USER_ID, OWNER_ID] if p]

        backup_msg = None
        tried_peer = None
        for peer in peers_to_try:
            try:
                # search param chhod do — last 200 messages manually scan karo
                msgs = await userbot_cl.get_messages(peer, limit=200)
                for m in msgs:
                    caption = getattr(m, "text", "") or ""
                    if m.document and BACKUP_TAG in caption:
                        backup_msg = m
                        tried_peer = peer
                        break
                if backup_msg:
                    break
                logger.info(f"restore: peer {peer} mein backup nahi mila ({len(msgs)} msgs check kiye)")
            except Exception as pe:
                logger.warning(f"restore: peer {peer} try karte waqt error: {pe}")

        if not backup_msg:
            logger.info("ℹ️ Kisi bhi peer mein backup nahi mila.")
            return False

        data_bytes = await userbot_cl.download_media(backup_msg, bytes)
        backup = json.loads(data_bytes.decode())
        restored = 0
        for key, filepath in _get_data_files().items():
            if key in backup and backup[key] is not None:
                save_json(filepath, backup[key])
                restored += 1
        logger.info(f"✅ {restored} files Telegram backup se restore ho gaye (peer={tried_peer}, ts={backup.get('_timestamp', '?')})")
        # Always clear dropped_call_template from restored config so the hardcoded
        # DEFAULT_DROPPED_TEMPLATE (with permanent custom emojis) is always used —
        # even if an old backup had a different or no custom template.
        try:
            _cfg = load_config()
            if "dropped_call_template" in _cfg:
                del _cfg["dropped_call_template"]
                save_config(_cfg)
        except Exception as _e:
            logger.warning(f"restore: dropped_call_template clear failed: {_e}")
        # In-memory globals reload
        global seen_message_ids, tracked_calls, sent_milestones, milestone_posts
        seen_message_ids = _load_seen()
        tracked_calls    = _load_tracked()
        sent_milestones  = _load_milestones()
        milestone_posts  = _load_milestone_posts()
        # Re-seed known members so they're never lost even if backup was old
        _seed_known_members()
        return True
    except Exception as e:
        logger.warning(f"Telegram restore failed: {e}")
        return False

async def backup_job(context: ContextTypes.DEFAULT_TYPE):
    """Periodic backup — har 5 min mein chalti hai (Railway restarts se protect karta hai)."""
    await backup_data_to_telegram(context.bot)

def add_user(uid: int, username: str = None, name: str = None):
    d = load_users_dict()
    key = str(uid)
    changed = False
    if key not in d:
        d[key] = {"id": uid, "username": username, "name": name}
        changed = True
    elif username and d[key].get("username") != username:
        d[key]["username"] = username
        d[key]["name"] = name
        changed = True
    if changed:
        save_users_dict(d)

# ─── Known-member seed ────────────────────────────────────────────────────────
# Usernames of members who were in the bot before a data loss event.
# They get stable placeholder IDs (always negative, never conflict with real IDs).
# When they interact with the bot again, add_user() will upsert their real Telegram ID.
_KNOWN_MEMBERS = []  # cleared — real users counted only when they interact with bot

def _username_placeholder_id(username: str) -> int:
    """Return a stable negative placeholder ID for a username-only member entry."""
    import hashlib
    h = int(hashlib.md5(username.lower().encode()).hexdigest(), 16)
    return -(h % (10 ** 9))

def _seed_known_members():
    """Add known members to users.json using stable placeholder IDs.
    Safe to call multiple times — skips entries that already have a real (positive) ID."""
    d = load_users_dict()
    changed = False
    for uname in _KNOWN_MEMBERS:
        pid = _username_placeholder_id(uname)
        pid_key = str(pid)
        # Check if this username already exists under any real (positive) ID
        already_real = any(
            v.get("username", "").lower() == uname.lower() and int(k) > 0
            for k, v in d.items()
        )
        if already_real:
            continue  # real entry exists — don't overwrite with placeholder
        if pid_key not in d:
            d[pid_key] = {"id": pid, "username": uname, "name": uname, "_placeholder": True}
            changed = True
    if changed:
        save_users_dict(d)

def get_milestones():
    cfg = load_config()
    stored = cfg.get("custom_milestones")
    if stored:
        try: base = sorted(set(int(x) for x in stored))
        except Exception: base = list(X_MILESTONES)
    else:
        base = list(X_MILESTONES)
    # Also include X values for which milestone_media is set, so those X levels are always tracked
    try:
        media_keys = cfg.get("milestone_media", {}).keys()
        extra = [int(k) for k in media_keys if k.lstrip('-').isdigit() and int(k) <= MAX_MILESTONE]
        if extra:
            base = sorted(set(base) | set(extra))
    except Exception:
        pass
    return base

# ─── Tracked data ─────────────────────────────────────────────────────────────
def _load_tracked():
    try:
        with open(TRACKED_FILE) as f: return json.load(f)
    except Exception: return {}

def _save_tracked():
    try:
        with open(TRACKED_FILE, "w") as f: json.dump(tracked_calls, f, ensure_ascii=False)
    except Exception: pass

def _load_milestones():
    try:
        with open(MILESTONES_FILE) as f:
            return defaultdict(set, {k: set(v) for k, v in json.load(f).items()})
    except Exception: return defaultdict(set)

def _save_milestones():
    try:
        with open(MILESTONES_FILE, "w") as f:
            json.dump({k: list(v) for k, v in sent_milestones.items()}, f)
    except Exception: pass

def _load_seen():
    try:
        with open(SEEN_FILE) as f:
            return defaultdict(set, {k: set(v) for k, v in json.load(f).items()})
    except Exception: return defaultdict(set)

# Startup safety: scan_job stays idle until the startup baseline has marked all
# currently-visible posts as seen. Without this a redeploy re-posts old calls.
_BASELINE_READY = False
# Any post older than this (seconds) is never alerted — only marked seen.
FRESH_POST_WINDOW = 900

_SEEN_MAX_PER_CHANNEL = 600   # keep memory + backup payload bounded on Railway

def _prune_seen():
    """Keep only the newest N ids per channel. Without this the set grows
    forever and the container eventually gets OOM-killed by Railway."""
    for ch, ids in list(seen_message_ids.items()):
        if len(ids) <= _SEEN_MAX_PER_CHANNEL:
            continue
        try:
            keep = sorted(ids, key=lambda x: int(x))[-_SEEN_MAX_PER_CHANNEL:]
        except Exception:
            keep = list(ids)[-_SEEN_MAX_PER_CHANNEL:]
        seen_message_ids[ch] = set(keep)

def _save_seen():
    try:
        _prune_seen()
        with open(SEEN_FILE, "w") as f:
            json.dump({k: list(v) for k, v in seen_message_ids.items()}, f)
    except Exception: pass

def _load_milestone_posts():
    try:
        with open(MILESTONE_POSTS_FILE) as f:
            return json.load(f)
    except Exception:
        return {}

def _save_milestone_posts():
    try:
        with open(MILESTONE_POSTS_FILE, "w") as f:
            json.dump(milestone_posts, f)
    except Exception:
        pass

seen_message_ids = _load_seen()
tracked_calls    = _load_tracked()
sent_milestones  = _load_milestones()
milestone_posts  = _load_milestone_posts()   # {call_key: {str(x_val): wizard_scan_post_id}}
owner_edit_state = {}
_userbot_login   = {}
userbot_client   = None
_userbot_init_lock = None
_login_client    = None
_bot_ref         = None  # set on startup; used by realtime message handler

# ─── Points System (Champion KOL List) ────────────────────────────────────────
# Points awarded per milestone tier (for champion kols list only)
POINT_TIERS = [
    (250, 100),  # 250X–499X → 100 pts
    (100, 75),   # 100X–249X → 75 pts
    (50,  50),   # 50X–99X   → 50 pts
    (25,  35),   # 25X–49X   → 35 pts
    (10,  20),   # 10X–24X   → 20 pts
    (5,   10),   # 5X–9X     → 10 pts
    (2,    5),   # 2X–4X     →  5 pts
]
POINTS_FOR_CHAMPION = 100  # Points needed to appear in champion kols list
POINTS_DEDUCT_FAILED = 10  # Deducted if call never hits 2X
CALL_FAIL_DAYS = 30        # Days after which a call is considered "failed" if no 2X

def get_point_tier_reward(x_val):
    """Return (tier_threshold, points) for the given x_val, or (0, 0)."""
    for threshold, pts in POINT_TIERS:
        if x_val >= threshold:
            return threshold, pts
    return 0, 0

def get_channel_points(channel):
    """Return total points for a channel."""
    pts = load_channel_points()
    return pts.get(channel.lower(), {}).get("points", 0)

async def award_points_for_milestone(channel, call_key, x_val):
    """Award incremental points when a milestone is hit. Only awards once per tier per call.
    Uses asyncio lock to prevent concurrent read-modify-write corruption.
    Skips call_keys that existed before the last champions/leaderboard reset."""
    tier_threshold, tier_pts = get_point_tier_reward(x_val)
    if tier_pts <= 0:
        return 0
    # Skip point awards only for call_keys excluded by champion reset.
    # Leaderboard reset (lb_excluded_call_keys) must NOT block champion points —
    # they are separate systems with independent reset cycles.
    _cfg_excl = load_config()
    champ_snap = _cfg_excl.get("champion_milestone_snapshot", {})
    champ_excl = set(_cfg_excl.get("champion_excluded_call_keys", []))
    if call_key in champ_excl:
        # Legacy blanket exclusion (pre-snapshot resets) — block entirely
        return 0
    if call_key in champ_snap:
        # Snapshot-based exclusion: only block if this milestone was already
        # present at reset time (i.e. tier_threshold <= snapshot max)
        snap_max = champ_snap[call_key]
        tier_threshold, _ = get_point_tier_reward(x_val)
        if tier_threshold <= snap_max:
            return 0
    async with _points_lock:
        pts_data = load_channel_points()
        key = channel.lower()
        if key not in pts_data:
            pts_data[key] = {"points": 0, "awarded_tiers": {}, "deducted_calls": []}
        entry = pts_data[key]
        awarded = entry.get("awarded_tiers", {})
        call_awarded = awarded.get(call_key, [])
        if tier_threshold in call_awarded:
            return 0  # Already awarded this tier for this call
        # Points increment = current tier - highest previously awarded tier for this call
        prev_pts = sum(tp for tt, tp in POINT_TIERS if tt in call_awarded)
        new_pts = tier_pts - prev_pts
        if new_pts <= 0:
            return 0
        entry["points"] = entry.get("points", 0) + new_pts
        call_awarded.append(tier_threshold)
        awarded[call_key] = call_awarded
        entry["awarded_tiers"] = awarded
        pts_data[key] = entry
        save_channel_points(pts_data)
    return new_pts

async def deduct_points_for_failed_call(channel, call_key):
    """Deduct 10 points if a call never hit 2X. Only deducts once per call."""
    async with _points_lock:
        pts_data = load_channel_points()
        key = channel.lower()
        if key not in pts_data:
            pts_data[key] = {"points": 0, "awarded_tiers": {}, "deducted_calls": []}
        entry = pts_data[key]
        deducted = entry.get("deducted_calls", [])
        if call_key in deducted:
            return  # Already deducted
        entry["points"] = entry.get("points", 0) - POINTS_DEDUCT_FAILED
        deducted.append(call_key)
        entry["deducted_calls"] = deducted
        pts_data[key] = entry
        save_channel_points(pts_data)

async def give_manual_points(channel, amount):
    """Manually give points to a channel (owner command)."""
    async with _points_lock:
        pts_data = load_channel_points()
        key = channel.lower()
        if key not in pts_data:
            pts_data[key] = {"points": 0, "awarded_tiers": {}, "deducted_calls": []}
        pts_data[key]["points"] = pts_data[key].get("points", 0) + amount
        total = pts_data[key]["points"]
        save_channel_points(pts_data)
    return total

# ─── Utilities ────────────────────────────────────────────────────────────────
def safe_format(template, **kwargs):
    lk = {k.lower(): v for k, v in kwargs.items()}
    return re.sub(r'\{([A-Za-z_][A-Za-z0-9_]*)\}',
                  lambda m: str(lk[m.group(1).lower()]) if m.group(1).lower() in lk else m.group(0),
                  template)

def fmt_mc(value):
    if not value: return "N/A"
    if value >= 1_000_000_000: return f"${value/1_000_000_000:.2f}B"
    elif value >= 1_000_000:   return f"${value/1_000_000:.2f}M"
    elif value >= 1_000:       return f"${value/1_000:.1f}K"
    return f"${value:.0f}"

def parse_mc_string(s):
    """Parse MC strings like '5K', '$5K', '1.5M', '50000' into a float.
    Returns 0.0 if parsing fails."""
    if not s: return 0.0
    s = s.strip().lstrip("$").strip().upper()
    try:
        if   s.endswith("B"): return float(s[:-1]) * 1_000_000_000
        elif s.endswith("M"): return float(s[:-1]) * 1_000_000
        elif s.endswith("K"): return float(s[:-1]) * 1_000
        else:                 return float(s)
    except Exception: return 0.0

def fmt_x(x: float) -> str:
    """Format X multiplier as readable decimal string (e.g. 1.25x, 2.7x, 123x)."""
    if x <= 0: return "1x"
    if x >= 100:   return f"{x:.0f}x"
    elif x >= 10:  return f"{x:.1f}x"
    elif x >= 2:   return f"{x:.1f}x"
    elif x > 1.01: return f"{x:.2f}x"
    return "1x"

def _safe_html_cap(text, limit=1024):
    """Trim caption to limit without breaking open HTML tags."""
    if not text or len(text) <= limit:
        return text or ""
    cut = text[:limit]
    # If we sliced inside an open tag, back up to before that '<'
    last_open = cut.rfind("<")
    if last_open != -1 and ">" not in cut[last_open:]:
        cut = cut[:last_open]
    return cut.rstrip()

async def send_photo_safe(target, photo_path, caption, parse_mode="HTML", reply_markup=None):
    """Send photo from file path. Caption safely trimmed to 1024 chars. Returns message or None."""
    try:
        cap = _safe_html_cap(caption)
        with open(photo_path, "rb") as f:
            return await target.reply_photo(photo=f, caption=cap,
                                             parse_mode=parse_mode, reply_markup=reply_markup)
    except FileNotFoundError:
        logger.warning(f"Image not found: {photo_path}")
        return None
    except Exception as e:
        logger.warning(f"send_photo_safe ({photo_path}): {e}")
        return None

async def send_video_safe(target, video_path, caption, parse_mode="HTML", reply_markup=None):
    try:
        cap = caption[:1024] if caption else ""
        with open(video_path, "rb") as f:
            return await target.reply_video(video=f, caption=cap,
                                             parse_mode=parse_mode, reply_markup=reply_markup)
    except FileNotFoundError:
        logger.warning(f"Video not found: {video_path}")
        return None
    except Exception as e:
        logger.warning(f"send_video_safe ({video_path}): {e}")
        return None

# ─── Default texts ────────────────────────────────────────────────────────────
DEFAULT_START_TEXT = (
    "<b>🔮 WIZARD SCAN – Your Crypto Radar</b>\n\n"
    "While others hunt for the next gem, WIZARD SCAN watches the callers.\n\n"
    "Our system tracks selected Telegram crypto callers around the clock and automatically detects when their calls start printing serious gains.\n\n"
    "The moment a tracked call reaches a major milestone, WIZARD SCAN delivers an instant alert to your DM and announces it in the channel.\n\n"
    "🪄 Caller leaderboards & reputation.\n"
    "🪄 Real-time winner detection.\n"
    "🪄 Instant DM alerts.\n"
    "🪄 Automated channel updates.\n"
    "🪄 Performance history tracking.\n"
    "🪄 No noise. No hype. Just results.\n\n"
    "<b>See who is actually delivering winning calls. Click Command to explore what this bot is capable of.</b>"
)

DEFAULT_COMMAND_TEXT = (
    "<b>🔮 Wizard Scan Command Center</b>\n\n"
    "Welcome to the Wizard Command Center. Use the buttons below to explore tracking tools, rankings, channel analytics, and caller statistics.\n\n"
    "<b>🔮 Choose an option to continue:</b>"
)

DEFAULT_KOL_REQUEST = (
    "<b>🔮 REQUEST YOUR KOL</b>\n\n"
    "Summon a KOL to be tracked on Wizard Scan.\n\n"
    "Send: <code>/submit @channelname</code>\n\n"
    "<b>🔮 How it works:</b>\n\n"
    "Our team manually reviews every request. No guarantee when. Could be today, 1 week, or 1 month. We receive 1000+ KOL requests. Patience is key.\n\n"
    "⚠️ Channels that spam or post low-quality calls will be rejected.\n\n"
    "<b>🪄 Want priority review?\n"
    "🪄 Click Fast Track below:</b>"
)

DEFAULT_PROMO_HUB = (
    "<b>🔮 ADVERTISE WITH US</b>\n\n"
    "Promote your project or channel through the WIZARD SCAN ecosystem. Our network includes active callers, experienced traders, project builders, and crypto communities.\n\n"
    "🪄 Pinned Post on @WizardScan\n"
    "🪄 Trending Project Listings\n"
    "🪄 Project Promotions\n"
    "🪄 Channel Promotions\n"
    "🪄 User DM Campaigns\n"
    "🪄 Trending KOLs Listings\n\n"
    "<b>For pricing and campaign details, contact our team.</b>"
)

DEFAULT_CHAT_US = (
    "<b>🔮 CONTACT WIZARD SCAN</b>\n\n"
    "Need assistance, partnership info, channel tracking, or promotional services? Our team is here.\n\n"
    "<b>🪄 Contact our team:</b>"
)

DEFAULT_FAST_TRACK = (
    "<b>🔮 FAST TRACK ACCESS</b>\n\n"
    "Skip the waiting list and receive priority review for your channel.\n\n"
    "Standard tracking requests have no guaranteed review timeframe due to high volume. 1,000+ channels are currently awaiting review.\n\n"
    "<b>🔮 Fast Track provides:</b>\n\n"
    "🪄 Priority Review\n"
    "🪄 Lifetime Tracking\n"
    "🪄 Faster Channel Approval\n\n"
    "<b>🔮 Fee: $180 ONLY</b>\n\n"
    "<b>Contact our team for Fast Track access.</b>"
)

DEFAULT_LEADERBOARD = (
    "<b>🔮 LEADERBOARD KOLS</b>\n\n"
    "The Leaderboard ranks KOL channels by their highest confirmed call multiplier — tracked live by Wizard Scan. "
    "It's easy to make it onto the KOL leaderboard since it doesn't use a points-based system.\n\n"
    "📌 View live rankings → <a href=\"https://t.me/WizardScan/136\">Post 136</a>\n\n\n"
    "<b>🔮 CHAMPION KOLS</b>\n\n"
    "Reaching the Champion KOLs leaderboard is more challenging. To qualify, you must first earn 100 points. "
    "The Champion KOLs leaderboard resets every 7 days, and every 7 days, the points of all KOLs who have reached "
    "100 points will be reset, giving everyone a fresh chance to compete.\n\n"
    "📌 View live Champions → <a href=\"https://t.me/WizardScan/137\">Post 137</a>\n\n\n"
    "<b>🔮 How points are earned:</b>\n\n"
    "▪ Call hits 2X–4X → +5 pts\n"
    "▪ Call hits 5X–9X → +10 pts\n"
    "▪ Call hits 10X–24X → +20 pts\n"
    "▪ Call hits 25X–49X → +35 pts\n"
    "▪ Call hits 50X–99X → +50 pts\n"
    "▪ Call hits 100X–249X → +75 pts\n"
    "▪ Call hits 250X+ → +100 pts\n\n"
    "▪ A call that fails to reach 2X within 30 days → −10 pts"
)

DEFAULT_ALERT_RULES = (
    "<b>🔮 ALERT RULES</b>\n\n"
    "Wizard Scan tracks KOL calls and sends alerts at key milestones:\n\n"
    "<b>🔮 Alert Schedule:</b>\n\n"
    "🪄 2X, 3X, 4X, 5X\n"
    "🪄 Every +5X from 10X to 100X\n"
    "🪄 Every +50X from 100X to 500X\n"
    "🪄 Every +100X from 500X to 1,000X\n"
    "🪄 Every +500X from 1,000X to 10,000X\n"
    "🪄 Every +1,000X above 10,000X\n\n"
    "No spam. Just real milestones.\n\n"
    "Use /command for more options."
)

DEFAULT_XCOMMAND = (
    "<b>🔮 WIZARD SCAN X</b>\n\n"
    "Wizard Scan now tracks Twitter (X) accounts for calls and contract addresses.\n\n"
    "📌 How to get listed:\n"
    "DM the OWNER with the X account you want tracked. Manual review required.\n\n"
    "<b>🔮 Twitter Alerts Channel:</b>\n"
    ""
    "📌 Tracked X Accounts:\n"
    "/xlist — View all X accounts currently tracked by Wizard Scan"
)

DEFAULT_HISTORY_INFO = (
    "<b>🔮 CHANNEL HISTORY LOOKUP</b>\n\n"
    "Instantly look up the full call history of any tracked KOL channel. How to use:\n\n"
    "🪄 Simply type: <code>/history @channelname</code>\n\n"
    "🪄 Example: <code>/history @SomeCryptoKOL</code>\n\n"
    "🪄 Or paste the @channel name directly in the chat.\n\n"
    "🔮 Once you do that, the bot will display the KOL's call history. Just make sure the KOL you're checking is already being tracked by our bot."
)

DEFAULT_LINKME_INFO = (
    "<b>🔮 LINK YOUR CHANNEL FOR ALERTS</b>\n\n"
    "If your KOL channel is tracked by Wizard Scan, you can link it to automatically receive all milestone alerts — directly inside your own channel.\n\n"
    "<b>🔮 How it works:</b>\n\n"
    "🪄 Wizard Scan tracks your KOL channel for winning calls\n"
    "🪄 When a call hits a milestone (2X, 10X, 100X...), Wizard Scan posts an alert\n"
    "🪄 With /linkme, that same alert is ALSO forwarded to your channel automatically\n"
    "🪄 Your community gets instant updates without leaving your channel\n\n"
    "<b>🔮 Setup (2 steps):</b>\n\n"
    "Step 1: Add @WIZARD_SCAN_BOT as admin to your channel (with post permission)\n"
    "Step 2: Send this command:\n"
    "<code>/linkme @your_kol_channel</code>\n\n"
    "Example:\n"
    "<code>/linkme @SomeCryptoKOL</code>\n\n"
    "<i>Only channels already tracked by Wizard Scan are eligible. Use /submit to request tracking first if needed.</i>"
)

# Apply premium emoji tags to all user-facing default templates.
# InlineKeyboardButton labels and channel-post templates (userbot entity injection)
# are intentionally NOT included here — they use plain emoji characters.
def _pe(text: str) -> str:
    return text.replace("🔮", PE_CRYSTAL).replace("🪄", PE_WAND).replace("➤", PE_ARROW)

DEFAULT_START_TEXT   = _pe(DEFAULT_START_TEXT)
DEFAULT_COMMAND_TEXT = _pe(DEFAULT_COMMAND_TEXT)
DEFAULT_KOL_REQUEST  = _pe(DEFAULT_KOL_REQUEST)
DEFAULT_PROMO_HUB    = _pe(DEFAULT_PROMO_HUB)
DEFAULT_CHAT_US      = _pe(DEFAULT_CHAT_US)
DEFAULT_FAST_TRACK   = _pe(DEFAULT_FAST_TRACK)
DEFAULT_LEADERBOARD  = _pe(DEFAULT_LEADERBOARD)
DEFAULT_ALERT_RULES  = _pe(DEFAULT_ALERT_RULES)
DEFAULT_XCOMMAND     = _pe(DEFAULT_XCOMMAND)
DEFAULT_HISTORY_INFO = _pe(DEFAULT_HISTORY_INFO)
DEFAULT_LINKME_INFO  = _pe(DEFAULT_LINKME_INFO)

# ─── Keyboards ────────────────────────────────────────────────────────────────
CONTACT_BUTTONS = InlineKeyboardMarkup([
    [InlineKeyboardButton("🔮 X 🔮",       url="https://x.com/WizardScan")],
    [InlineKeyboardButton("🔮 ADMIN 🔮",   url="https://t.me/Wizard_Scan")],
    [InlineKeyboardButton("🔮 CHANNEL 🔮", url="https://t.me/WizardScan")],
])

CHAT_US_BUTTON = InlineKeyboardMarkup([
    [InlineKeyboardButton("🔮  Chat With Us  🔮", callback_data="chat_us")]
])

def build_command_keyboard():
    config = load_config(); labels = config.get("button_labels", {})
    def lbl(k, d): return labels.get(k, d)
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(lbl("kol_request",  "🔮 Request your KOL 🔮"),  callback_data="kol_request")],
        [InlineKeyboardButton(lbl("promo_hub",    "🔮 Promotion HUB 🔮"),     callback_data="promo_hub")],
        [InlineKeyboardButton(lbl("tracked_kols", "🔮 Tracked KOLs 🔮"),      callback_data="tracked_kols")],
        [InlineKeyboardButton(lbl("leaderboard",  "🔮 Leaderboard 🔮"),       callback_data="leaderboard")],
        [InlineKeyboardButton(lbl("fast_track",   "🔮 Fast Track 🔮"),        callback_data="fast_track")],
        [InlineKeyboardButton(lbl("chat_us",      "🔮  Chat With Us  🔮"),    callback_data="chat_us")],
    ])

def history_keyboard(channel):
    ch = channel[:28]
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🔮BNB",  callback_data=f"h|{ch}|bnb"),
            InlineKeyboardButton("🔮ETH",  callback_data=f"h|{ch}|eth"),
            InlineKeyboardButton("🔮SOL",  callback_data=f"h|{ch}|sol"),
        ],
        [
            InlineKeyboardButton("🔮BASE", callback_data=f"h|{ch}|base"),
            InlineKeyboardButton("🔮TON",  callback_data=f"h|{ch}|ton"),
            InlineKeyboardButton("🔮RH",   callback_data=f"h|{ch}|rh"),
        ],
        [
            InlineKeyboardButton("🔮TOP",  callback_data=f"h|{ch}|top"),
            InlineKeyboardButton("🔮ALL",  callback_data=f"h|{ch}|all"),
        ],
    ])

# ─── Userbot ──────────────────────────────────────────────────────────────────
def load_userbot_session():
    try:
        with open(USERBOT_SESSION_FILE) as f: return f.read().strip()
    except Exception: return ""

def save_userbot_session(s):
    with open(USERBOT_SESSION_FILE, "w") as f: f.write(s)

def _install_telethon_exception_handler():
    """Install a custom asyncio exception handler that swallows Telethon v1.44.0's
    known internal bugs (coroutine-not-awaited, event-loop-closed) so they don't
    crash the Railway process.

    Telethon v1.44.0 has two confirmed bugs:
      1. MTProtoSender._reconnect coroutine created but never awaited → RuntimeWarning
      2. TelegramBaseClient._disconnect_coro coroutine never awaited → RuntimeWarning
    Both are benign for our use-case — the watchdog job handles reconnection.
    """
    loop = asyncio.get_event_loop()

    def _handler(loop, context):
        msg       = context.get("message", "")
        exc       = context.get("exception")
        exc_str   = str(exc) if exc else ""
        # Known Telethon v1.44.0 benign errors — log as debug, don't crash
        telethon_noise = [
            "Event loop is closed",
            "coroutine 'MTProtoSender",
            "coroutine 'TelegramBaseClient",
            "_reconnect",
            "_disconnect_coro",
            "was never awaited",
            "NoneType can't be used in 'await'",
        ]
        if any(s in msg or s in exc_str for s in telethon_noise):
            logger.debug(f"[Telethon noise suppressed] {msg or exc_str}")
            return
        # All other exceptions: use the default handler
        loop.default_exception_handler(context)

    try:
        loop.set_exception_handler(_handler)
        logger.info("✅ Asyncio exception handler installed (Telethon crash suppression active)")
    except Exception as e:
        logger.warning(f"Could not install asyncio exception handler: {e}")


async def init_userbot():
    """Initialize (or re-initialize) the Telethon userbot client.

    Config hardened for Railway long-running deployments:
    - connection_retries=10  : retry network drops up to 10× before giving up
    - retry_delay=5          : 5s between retries
    - auto_reconnect=True    : Telethon auto-reconnects on connection drops
    - catch_up=False         : don't replay missed updates on reconnect (saves RAM/CPU)
    - receive_updates=True   : required for NewMessage event handler
    - flood_sleep_threshold=60 : auto-sleep on FLOOD_WAIT up to 60s
    """
    global userbot_client, _userbot_init_lock
    session_str = load_userbot_session() or os.environ.get("SESSION_STRING", "").strip()
    if not session_str or not OWNER_API_ID or not OWNER_API_HASH:
        logger.warning("⚠️ Userbot session not found.")
        return
    if _userbot_init_lock is None:
        _userbot_init_lock = asyncio.Lock()
    async with _userbot_init_lock:
        # post_init and the watchdog used to enter here together, disconnecting
        # each other's MTProto transport and causing `_connection.recv()` on None.
        if userbot_client and userbot_client.is_connected():
            return
        candidate = None
        try:
            from telethon import TelegramClient
            from telethon.sessions import StringSession
            candidate = TelegramClient(
                StringSession(session_str),
                OWNER_API_ID,
                OWNER_API_HASH,
                connection_retries=3,
                retry_delay=3,
                auto_reconnect=True,
                catch_up=False,
                receive_updates=True,
                flood_sleep_threshold=60,
            )
            await asyncio.wait_for(candidate.connect(), timeout=45)
            if not await asyncio.wait_for(candidate.is_user_authorized(), timeout=15):
                logger.warning("Userbot: session exists but not authorized")
                await candidate.disconnect()
                return
            me = await asyncio.wait_for(candidate.get_me(), timeout=15)
            userbot_client = candidate
            logger.info(f"✅ Userbot: @{me.username or me.id}")
            _install_telethon_exception_handler()
        except Exception as e:
            logger.error(f"Userbot init failed: {type(e).__name__}: {e}")
            if candidate:
                try:
                    await candidate.disconnect()
                except Exception:
                    pass
            userbot_client = None

# ─── DexScreener ─────────────────────────────────────────────────────────────
# In-memory cache: {ca: (result_dict, expiry_timestamp)}
# TTL = 20s so milestone_job gets fresh data on every 15s tick without hammering API
_dex_cache: dict = {}
_DEX_CACHE_TTL = 5   # seconds (real-time: refreshed every monitoring tick)

# Chain slug map for v3 endpoint (DexScreener chainId → v3 slug)
_DEX_V3_CHAIN = {
    "solana": "solana", "ethereum": "ethereum", "bsc": "bsc",
    "base": "base", "ton": "ton", "arbitrum": "arbitrum",
}

def _pick_market_cap(pairs: list) -> float:
    """Return the most trustworthy market cap from a DexScreener pairs list.

    DexScreener reports marketCap/fdv per pair and a single stale pair can be
    badly wrong. We therefore:
      1. take marketCap from the deepest-liquidity pair,
      2. cross-check it against the median marketCap of all pairs of the same
         token — if it is more than 3x off, trust the median instead,
      3. fall back to fdv only when no pair reports a marketCap.
    """
    mcs = []
    for p in pairs:
        try:
            v = float(p.get("marketCap") or 0)
        except (TypeError, ValueError):
            v = 0.0
        if v > 0:
            mcs.append(v)
    if mcs:
        primary = mcs[0]
        if len(mcs) >= 3:
            ordered = sorted(mcs)
            median = ordered[len(ordered) // 2]
            if median > 0 and (primary > median * 3 or primary * 3 < median):
                return median
        return primary
    for p in pairs:
        try:
            v = float(p.get("fdv") or 0)
        except (TypeError, ValueError):
            v = 0.0
        if v > 0:
            return v
    return 0.0


def _parse_dex_pairs(pairs: list, min_liquidity: int) -> dict | None:
    """Parse a DexScreener pairs list into our internal dict. Returns None if unusable."""
    sup = [p for p in pairs if p.get("chainId","").lower() in SUPPORTED_CHAINS
           and (p.get("liquidity",{}).get("usd") or 0) >= min_liquidity]
    if not sup:
        return None
    sup = sorted(sup, key=lambda p: p.get("liquidity",{}).get("usd",0) or 0, reverse=True)
    best = sup[0]
    chain  = SUPPORTED_CHAINS[best.get("chainId","").lower()]
    price  = float(best.get("priceUsd") or 0)
    mc     = _pick_market_cap(sup)
    symbol = best.get("baseToken",{}).get("symbol","")
    if price <= 0 and mc <= 0 and not symbol:
        return None
    price_change_h1  = float((best.get("priceChange") or {}).get("h1") or 0)
    price_change_h24 = float((best.get("priceChange") or {}).get("h24") or 0)
    volume_h24       = float((best.get("volume") or {}).get("h24") or 0)
    liquidity_usd    = float((best.get("liquidity") or {}).get("usd") or 0)
    txns_h24_buys    = int((best.get("txns") or {}).get("h24", {}).get("buys") or 0)
    txns_h24_sells   = int((best.get("txns") or {}).get("h24", {}).get("sells") or 0)
    listed_at        = best.get("pairCreatedAt")
    socials = best.get("info",{}).get("socials") or []
    tg_link = ""
    for s in socials:
        if "t.me" in (s.get("url","")) or "telegram" in (s.get("type","")).lower():
            tg_link = s.get("url",""); break
    return {
        "chain":           chain,
        "mcap":            mc,
        "mcap_fmt":        fmt_mc(mc) if mc > 0 else "N/A",
        "price":           price,
        "symbol":          symbol,
        "name":            best.get("baseToken",{}).get("name",""),
        "pair_addr":       best.get("pairAddress",""),
        "tg_link":         tg_link,
        "price_change_h1": price_change_h1,
        "price_change_h24":price_change_h24,
        "volume_h24":      volume_h24,
        "liquidity_usd":   liquidity_usd,
        "txns_buys":       txns_h24_buys,
        "txns_sells":      txns_h24_sells,
        "listed_at":       listed_at,
        "_partial":        (price <= 0 and mc <= 0),
    }

# ── Shared HTTP session with connection pooling + automatic retries ──────────
_dex_session = requests.Session()
try:
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
    _dex_retry = Retry(
        total=2, connect=2, read=2, backoff_factor=0.6,
        status_forcelist=(500, 502, 503, 504),
        allowed_methods=frozenset(["GET"]),
        raise_on_status=False,
    )
    _dex_adapter = HTTPAdapter(max_retries=_dex_retry, pool_connections=20, pool_maxsize=40)
    _dex_session.mount("https://", _dex_adapter)
    _dex_session.mount("http://", _dex_adapter)
except Exception as _e_adapter:  # urllib3 API change — plain session still works
    logger.warning(f"DexScreener retry adapter unavailable: {_e_adapter}")
_dex_session.headers.update(HEADERS)

# Negative cache: CA -> expiry. Stops us hammering DexScreener for tokens
# that are simply not indexed yet (main source of rate-limit 429 storms).
_dex_miss_cache: dict = {}
_DEX_MISS_TTL = 15          # seconds
_DEX_CACHE_MAX = 4000       # hard cap so long-running Railway deploys never OOM


def _dex_cache_gc():
    """Evict expired / overflowing cache entries (prevents unbounded RAM growth)."""
    import time as _time
    now = _time.time()
    for cache in (_dex_cache, _dex_miss_cache):
        if len(cache) < _DEX_CACHE_MAX:
            continue
        for k in [k for k, v in list(cache.items())
                  if (v[1] if isinstance(v, tuple) else v) < now]:
            cache.pop(k, None)
        while len(cache) > _DEX_CACHE_MAX:
            try:
                cache.pop(next(iter(cache)))
            except StopIteration:
                break


def _dex_get(url: str, timeout: int = 12):
    """GET with shared session. Returns parsed JSON or None. Never raises."""
    try:
        resp = _dex_session.get(url, timeout=timeout)
    except Exception as e:
        logger.warning(f"DexScreener network error ({url.split('/')[-1][:16]}…): {e}")
        return None
    if resp.status_code == 429:
        return 429
    if resp.status_code != 200:
        return None
    try:
        return resp.json()
    except Exception:
        return None


def _dex_candidate_chains(ca: str) -> list:
    """Which DexScreener chains can this address exist on? Keeps the
    chain-scoped lookup to 1-4 cheap requests instead of brute-forcing."""
    if ca.startswith("0x") and len(ca) == 42:
        return ["ethereum", "bsc", "base", "robinhood"]
    if ca.startswith(("EQ", "UQ")):
        return ["ton"]
    return ["solana"]


def _fetch_dex_sync(ca, retries=3, min_liquidity=500):
    """Fetch live token data from DexScreener.

    Order of operations:
      1. Fresh positive cache hit (< 20s)  -> return instantly
      2. Fresh negative cache hit (< 45s)  -> return None without a request
      3. /latest/dex/tokens/{ca}           -> primary, all chains
      4. /latest/dex/search?q={ca}         -> fallback for freshly-created pairs
      5. 429 -> exponential backoff, then retry
    """
    import time as _time
    if not ca:
        return None

    cached = _dex_cache.get(ca)
    if cached:
        result, exp = cached
        if _time.time() < exp:
            return result

    miss_exp = _dex_miss_cache.get(ca)
    if miss_exp and _time.time() < miss_exp:
        return None

    for attempt in range(max(1, retries)):
        data = _dex_get(f"https://api.dexscreener.com/latest/dex/tokens/{ca}")
        if data == 429:
            wait = 2 * (attempt + 1)
            logger.warning(f"DexScreener 429 (ca={ca[:12]}…) — backing off {wait}s")
            _time.sleep(wait)
            continue

        pairs = (data or {}).get("pairs") or []

        # Fallback: brand-new pairs sometimes only show on the search endpoint.
        if not pairs:
            sdata = _dex_get(f"https://api.dexscreener.com/latest/dex/search?q={ca}")
            if sdata and sdata != 429:
                pairs = [
                    p for p in (sdata.get("pairs") or [])
                    if ca.lower() in (
                        (p.get("baseToken", {}).get("address", "") or "").lower(),
                        (p.get("quoteToken", {}).get("address", "") or "").lower(),
                    )
                ]

        if pairs:
            result = _parse_dex_pairs(pairs, min_liquidity)
            if result is None:
                # Pairs exist but all below the liquidity floor — retry without it
                # so the UI still shows a live price instead of "N/A".
                result = _parse_dex_pairs(pairs, 0)
        else:
            result = None

        # The /latest endpoint caps its answer at 30 pairs, so a multi-chain
        # token can come back with zero pairs on a chain we support. Ask the
        # chain-scoped v1 endpoint directly for the chains this CA can live on.
        if not result:
            scoped = []
            for chain_slug in _dex_candidate_chains(ca):
                cdata = _dex_get(f"https://api.dexscreener.com/tokens/v1/{chain_slug}/{ca}", timeout=10)
                if cdata == 429:
                    break
                if isinstance(cdata, list) and cdata:
                    scoped.extend(cdata)
            if scoped:
                result = _parse_dex_pairs(scoped, min_liquidity) or _parse_dex_pairs(scoped, 0)

        if True:
            if result:
                _dex_cache[ca] = (result, _time.time() + _DEX_CACHE_TTL)
                _dex_miss_cache.pop(ca, None)
                _dex_cache_gc()
                return result

        # Not indexed yet -> short negative cache, no more retries this round.
        _dex_miss_cache[ca] = _time.time() + _DEX_MISS_TTL
        _dex_cache_gc()
        return None

    return None


def _bulk_refresh_dex_sync(cas: list, min_liquidity: int = 0) -> int:
    """Refresh the DexScreener cache for many tokens with few requests.

    /latest/dex/tokens/{a,b,c} accepts up to 30 comma-separated addresses, so
    tracking 300 tokens costs ~10 requests instead of 300. This is what makes
    real-time (5 s) tracking possible without hitting rate limits.
    """
    import time as _time
    uniq, seen_local = [], set()
    for ca in cas or []:
        if ca and ca not in seen_local:
            seen_local.add(ca)
            uniq.append(ca)
    updated = 0
    for i in range(0, len(uniq), 30):
        batch = uniq[i:i + 30]
        data = _dex_get(f"https://api.dexscreener.com/latest/dex/tokens/{','.join(batch)}")
        if data == 429:
            _time.sleep(1.5)
            continue
        pairs = (data or {}).get("pairs") or []
        if not pairs:
            continue
        grouped: dict = {}
        wanted = {c.lower(): c for c in batch}
        for p in pairs:
            for side in ("baseToken", "quoteToken"):
                addr = ((p.get(side) or {}).get("address") or "").lower()
                if addr in wanted:
                    grouped.setdefault(wanted[addr], []).append(p)
                    break
        for ca, plist in grouped.items():
            result = _parse_dex_pairs(plist, min_liquidity)
            if result:
                _dex_cache[ca] = (result, _time.time() + _DEX_CACHE_TTL)
                _dex_miss_cache.pop(ca, None)
                updated += 1
        if i + 30 < len(uniq):
            _time.sleep(0.2)
    _dex_cache_gc()
    return updated


def _invalidate_dex_cache(ca: str):
    """Force next fetch to bypass cache — call when we need a guaranteed fresh price."""
    _dex_cache.pop(ca, None)

async def fetch_dexscreener(ca):
    return await asyncio.to_thread(_fetch_dex_sync, ca)


def _fetch_token_info_fallback_sync(ca: str, chain_guess: str) -> dict:
    """Fallback token info fetch when DexScreener has no/partial data.
    For SOL tokens : Jupiter → pump.fun → DexScreener search.
    For EVM tokens : GeckoTerminal (specific chain first) → DexScreener search.
    `chain_guess` may be the already-resolved chain ("ETH","BNB","BASE","SOL")
    or the raw guess ("EVM","SOL").
    Returns dict with 'symbol' and optionally 'mcap'/'mcap_fmt'/'chain', or {}.
    """
    # Normalise chain_guess → GeckoTerminal network string + display chain
    _GECKO_NET = {"ETH": "eth", "BNB": "bsc", "BASE": "base", "RH": "robinhood",
                  "ethereum": "eth", "bsc": "bsc", "base": "base", "robinhood": "robinhood"}
    _CHAIN_DISP = {"eth": "ETH", "bsc": "BNB", "base": "BASE", "robinhood": "RH"}

    result = {}
    try:
        # ══════════════════════════════════════════════════════════════════
        # SOL path
        # ══════════════════════════════════════════════════════════════════
        if chain_guess in ("SOL", "solana"):
            # 1. Jupiter token list
            try:
                r = requests.get(f"https://tokens.jup.ag/token/{ca}",
                                 headers=HEADERS, timeout=8)
                if r.status_code == 200:
                    d   = r.json()
                    sym = d.get("symbol") or d.get("name") or ""
                    if sym:
                        result["symbol"] = sym
                        result["chain"]  = "SOL"
                        logger.info(f"🔍 Jupiter fallback: symbol={sym} for {ca[:12]}...")
            except Exception as e:
                logger.debug(f"Jupiter fallback failed: {e}")

            # 2. Pump.fun API (covers tokens not yet on Jupiter)
            if not result.get("symbol"):
                try:
                    r = requests.get(f"https://frontend-api.pump.fun/coins/{ca}",
                                     headers=HEADERS, timeout=8)
                    if r.status_code == 200:
                        d   = r.json()
                        sym = d.get("symbol") or ""
                        mc  = float(d.get("market_cap") or 0)
                        if sym:
                            result["symbol"] = sym
                            result["chain"]  = "SOL"
                            if mc > 0:
                                result["mcap"]     = mc
                                result["mcap_fmt"] = fmt_mc(mc)
                            logger.info(f"🔍 Pump.fun fallback: sym={sym} mc={mc} for {ca[:12]}...")
                except Exception as e:
                    logger.debug(f"Pump.fun fallback failed: {e}")

            # 3. DexScreener search endpoint (catches tokens with symbol but no direct hit)
            if not result.get("symbol") or not result.get("mcap"):
                try:
                    r = requests.get(
                        f"https://api.dexscreener.com/latest/dex/search?q={ca}",
                        headers=HEADERS, timeout=10)
                    if r.status_code == 200:
                        for p in (r.json().get("pairs") or []):
                            if p.get("baseToken", {}).get("address", "").lower() != ca.lower():
                                continue
                            sym = p.get("baseToken", {}).get("symbol", "")
                            mc  = float(p.get("marketCap") or p.get("fdv") or 0)
                            if sym:
                                if not result.get("symbol"):
                                    result["symbol"] = sym
                                if mc > 0 and not result.get("mcap"):
                                    result["mcap"]     = mc
                                    result["mcap_fmt"] = fmt_mc(mc)
                                result.setdefault("chain", SUPPORTED_CHAINS.get(
                                    p.get("chainId","").lower(), "SOL"))
                                logger.info(f"🔍 DEX search SOL fallback: sym={sym} mc={mc} for {ca[:12]}...")
                                break
                except Exception as e:
                    logger.debug(f"DexScreener SOL search fallback failed: {e}")

        # ══════════════════════════════════════════════════════════════════
        # TON path
        # ══════════════════════════════════════════════════════════════════
        elif chain_guess == "TON":
            # DexScreener supports TON directly
            try:
                r = requests.get(
                    f"https://api.dexscreener.com/latest/dex/tokens/{ca}",
                    headers=HEADERS, timeout=10)
                if r.status_code == 200:
                    for p in (r.json().get("pairs") or []):
                        if p.get("chainId","").lower() != "ton":
                            continue
                        sym = p.get("baseToken",{}).get("symbol","")
                        mc  = float(p.get("marketCap") or p.get("fdv") or 0)
                        if sym:
                            result["symbol"] = sym
                            result["chain"]  = "TON"
                            if mc > 0:
                                result["mcap"]     = mc
                                result["mcap_fmt"] = fmt_mc(mc)
                            logger.info(f"🔍 DexScreener TON: sym={sym} mc={mc} for {ca[:12]}...")
                            break
            except Exception as e:
                logger.debug(f"DexScreener TON fallback failed: {e}")

            # GeckoTerminal TON fallback
            if not result.get("symbol"):
                try:
                    r = requests.get(
                        f"https://api.geckoterminal.com/api/v2/networks/ton/tokens/{ca}",
                        headers={"Accept": "application/json"}, timeout=8)
                    if r.status_code == 200:
                        attr = r.json().get("data", {}).get("attributes", {})
                        sym  = attr.get("symbol") or attr.get("name") or ""
                        mc   = float(attr.get("market_cap_usd") or attr.get("fdv_usd") or 0)
                        if sym:
                            result["symbol"] = sym
                            result["chain"]  = "TON"
                            if mc > 0:
                                result["mcap"]     = mc
                                result["mcap_fmt"] = fmt_mc(mc)
                            logger.info(f"🔍 GeckoTerminal TON: sym={sym} mc={mc} for {ca[:12]}...")
                except Exception as e:
                    logger.debug(f"GeckoTerminal TON fallback failed: {e}")

        # ══════════════════════════════════════════════════════════════════
        # EVM path  (ETH / BNB / BASE — or unknown "EVM")
        # ══════════════════════════════════════════════════════════════════
        else:
            # Determine which networks to try, most-likely first
            # RH (Robinhood) is EVM-compatible; GeckoTerminal uses "robinhood" network key
            _GECKO_NET["RH"] = "robinhood"
            known_net = _GECKO_NET.get(chain_guess)
            if known_net:
                nets_to_try = [known_net] + [n for n in ("eth", "bsc", "base", "robinhood")
                                              if n != known_net]
            else:
                nets_to_try = ["eth", "bsc", "base", "robinhood"]

            # 1. GeckoTerminal token endpoint — often has fdv_usd / market_cap_usd
            for network in nets_to_try:
                if result.get("symbol") and result.get("mcap"):
                    break
                try:
                    r = requests.get(
                        f"https://api.geckoterminal.com/api/v2/networks/{network}/tokens/{ca}",
                        headers={"Accept": "application/json"}, timeout=8)
                    if r.status_code != 200:
                        continue
                    attr = r.json().get("data", {}).get("attributes", {})
                    sym  = attr.get("symbol") or attr.get("name") or ""
                    mc   = float(attr.get("market_cap_usd") or attr.get("fdv_usd") or 0)
                    if sym:
                        if not result.get("symbol"):
                            result["symbol"] = sym
                            result["chain"]  = _CHAIN_DISP.get(network, "EVM")
                        if mc > 0 and not result.get("mcap"):
                            result["mcap"]     = mc
                            result["mcap_fmt"] = fmt_mc(mc)
                        logger.info(
                            f"🔍 GeckoTerminal ({network}): sym={sym} mc={mc} for {ca[:12]}...")
                except Exception as e:
                    logger.debug(f"GeckoTerminal {network} failed: {e}")

            # 2. GeckoTerminal top pools for the token — pools have reliable fdv/mc data
            if not result.get("mcap"):
                for network in (nets_to_try if result.get("chain") is None
                                else [_GECKO_NET.get(result["chain"], "eth")]):
                    try:
                        r = requests.get(
                            f"https://api.geckoterminal.com/api/v2/networks/{network}"
                            f"/tokens/{ca}/pools?page=1",
                            headers={"Accept": "application/json"}, timeout=8)
                        if r.status_code != 200:
                            continue
                        for pool in (r.json().get("data") or []):
                            attr = pool.get("attributes", {})
                            mc   = float(attr.get("market_cap_usd") or attr.get("fdv_usd") or 0)
                            sym  = (attr.get("name") or "").split(" / ")[0].strip()
                            if mc > 0:
                                if not result.get("mcap"):
                                    result["mcap"]     = mc
                                    result["mcap_fmt"] = fmt_mc(mc)
                                if sym and not result.get("symbol"):
                                    result["symbol"] = sym
                                result.setdefault("chain", _CHAIN_DISP.get(network, "EVM"))
                                logger.info(
                                    f"🔍 GeckoTerminal pools ({network}): sym={sym} mc={mc} for {ca[:12]}...")
                                break
                        if result.get("mcap"):
                            break
                    except Exception as e:
                        logger.debug(f"GeckoTerminal pools {network} failed: {e}")

            # 3. DexScreener search — catches tokens where direct endpoint had no MC
            if not result.get("symbol") or not result.get("mcap"):
                try:
                    r = requests.get(
                        f"https://api.dexscreener.com/latest/dex/search?q={ca}",
                        headers=HEADERS, timeout=10)
                    if r.status_code == 200:
                        for p in (r.json().get("pairs") or []):
                            if p.get("baseToken", {}).get("address", "").lower() != ca.lower():
                                continue
                            chain_id = p.get("chainId", "").lower()
                            if chain_id not in SUPPORTED_CHAINS:
                                continue
                            sym = p.get("baseToken", {}).get("symbol", "")
                            mc  = float(p.get("marketCap") or p.get("fdv") or 0)
                            if sym and not result.get("symbol"):
                                result["symbol"] = sym
                                result["chain"]  = SUPPORTED_CHAINS[chain_id]
                            if mc > 0 and not result.get("mcap"):
                                result["mcap"]     = mc
                                result["mcap_fmt"] = fmt_mc(mc)
                            if result.get("symbol") and result.get("mcap"):
                                break
                        if result.get("symbol") or result.get("mcap"):
                            logger.info(
                                f"🔍 DEX search EVM fallback: sym={result.get('symbol')} "
                                f"mc={result.get('mcap_fmt')} for {ca[:12]}...")
                except Exception as e:
                    logger.debug(f"DexScreener EVM search fallback failed: {e}")

    except Exception as e:
        logger.warning(f"_fetch_token_info_fallback_sync crash: {e}")

    return result

def _extract_tg_link(links):
    """Find a Telegram group/channel link from DexScreener links list."""
    if not links: return ""
    for link in links:
        url = link.get("url","")
        ltype = link.get("type","").lower()
        label = link.get("label","").lower()
        if "t.me" in url or "telegram" in ltype or "telegram" in label:
            return url
    return ""

def _extract_tg_link_from_pairs(ca):
    """Fallback: get TG link from DexScreener pair data."""
    try:
        r = requests.get(f"https://api.dexscreener.com/latest/dex/tokens/{ca}", timeout=10, headers=HEADERS)
        if r.status_code != 200: return ""
        for pair in (r.json().get("pairs") or []):
            info = pair.get("info", {}) or {}
            for s in (info.get("socials") or []):
                u = s.get("url",""); t = s.get("type","").lower()
                if "t.me" in u or "telegram" in t: return u
            for lnk in (info.get("links") or []):
                u = lnk.get("url",""); t = lnk.get("type","").lower()
                if "t.me" in u or "telegram" in t: return u
    except Exception: pass
    return ""

def _fetch_gecko_chain(gecko_network: str, dex_chain_key: str, blacklist: set) -> list:
    """Fetch top-5 trending tokens for one chain via GeckoTerminal.
    Returns list of {symbol, mc_fmt, tg_url, dex_url, has_tg} dicts.
    """
    GECKO_HEADERS = {"Accept": "application/json"}
    DEXPATH = {"ETH": "ethereum", "BNB": "bsc", "BASE": "base", "SOL": "solana"}
    results = []
    try:
        r = requests.get(
            f"https://api.geckoterminal.com/api/v2/networks/{gecko_network}/trending_pools"
            f"?page=1&include=base_token",
            headers=GECKO_HEADERS, timeout=15
        )
        if r.status_code != 200:
            logger.warning(f"GeckoTerminal {gecko_network}: HTTP {r.status_code}")
            return results
        data = r.json()
    except Exception as e:
        logger.warning(f"GeckoTerminal {gecko_network} fetch failed: {e}")
        return results

    # Build included base_token lookup: id -> {symbol, address, telegram}
    # Accept ANY type — GeckoTerminal has used "token" and "base_token" at different times
    included_map: dict = {}
    for item in (data.get("included") or []):
        attr = item.get("attributes", {})
        item_id = item.get("id", "")
        if not item_id: continue
        included_map[item_id] = {
            "symbol":   attr.get("symbol", ""),
            "address":  attr.get("address", ""),
            "telegram": attr.get("telegram_chat_url") or "",
        }

    def _ca_from_rel_id(rel_id: str) -> str:
        """GeckoTerminal rel IDs are like 'eth_0xabc…' or 'base_0xabc…'.
        Strip the network prefix to get the raw contract address as fallback."""
        if not rel_id: return ""
        if "_" in rel_id:
            parts = rel_id.split("_", 1)
            candidate = parts[1]
            # Basic sanity: looks like an address (hex) or Solana pubkey (base58)
            if len(candidate) > 20:
                return candidate
        return ""

    seen_tokens: set = set()
    for pool in (data.get("data") or []):
        attr = pool.get("attributes", {})

        # Market cap / FDV — try all available fields; fall back to volume as a last resort
        mc_raw = (attr.get("market_cap_usd") or attr.get("fdv_usd")
                  or attr.get("reserve_in_usd") or 0)
        try: mc = float(mc_raw)
        except Exception: mc = 0.0
        # If still zero, use 24h volume as a rough proxy so the pool isn't silently dropped
        if mc <= 0:
            try: mc = float(attr.get("volume_usd", {}).get("h24") or 0)
            except Exception: mc = 0.0
        if mc <= 0: continue

        # Get base token info — try included_map first, then parse rel_id as fallback
        rel_id = (
            pool.get("relationships", {})
            .get("base_token", {})
            .get("data", {})
            .get("id", "")
        )
        token_info = included_map.get(rel_id, {})
        ca  = token_info.get("address", "") or _ca_from_rel_id(rel_id)
        sym = (token_info.get("symbol")
               or attr.get("name", "TOKEN").split(" / ")[0]
               or attr.get("base_token_symbol", "TOKEN"))

        if not ca or ca.lower() in blacklist: continue
        if ca in seen_tokens: continue
        seen_tokens.add(ca)

        tg  = token_info.get("telegram", "")
        dex = f"https://dexscreener.com/{DEXPATH.get(dex_chain_key, gecko_network)}/{ca}"
        results.append({
            "symbol":  sym,
            "mc_fmt":  fmt_mc(mc),
            "tg_url":  tg,
            "dex_url": dex,
            "has_tg":  bool(tg),
            "_ca":     ca,   # temp field for DexScreener TG supplement
        })
        if len(results) >= 10: break  # collect up to 10, sort below

    # ── Supplement missing TG links via DexScreener batch lookup ─────────────
    no_tg = [r for r in results if not r["tg_url"] and r.get("_ca")]
    if no_tg:
        batch_cas = [r["_ca"] for r in no_tg]
        try:
            rs = requests.get(
                f"https://api.dexscreener.com/latest/dex/tokens/{','.join(batch_cas)}",
                headers=HEADERS, timeout=15
            )
            if rs.status_code == 200:
                tg_map: dict = {}
                for p in (rs.json().get("pairs") or []):
                    ca_key = p.get("baseToken", {}).get("address", "")
                    if ca_key and ca_key not in tg_map:
                        info = p.get("info") or {}
                        for s in (info.get("socials") or []):
                            u = s.get("url", ""); t = s.get("type", "").lower()
                            if "t.me" in u or "telegram" in t:
                                tg_map[ca_key] = u; break
                        if ca_key not in tg_map:
                            for lnk in (info.get("links") or []):
                                u = lnk.get("url", ""); t = lnk.get("type", "").lower()
                                if "t.me" in u or "telegram" in t:
                                    tg_map[ca_key] = u; break
                for r in results:
                    if not r["tg_url"] and r.get("_ca") and r["_ca"] in tg_map:
                        r["tg_url"] = tg_map[r["_ca"]]
                        r["has_tg"] = True
        except Exception as e:
            logger.warning(f"DexScreener TG supplement {gecko_network}: {e}")

    # Remove temp field
    for r in results: r.pop("_ca", None)

    # TG-first sort, return top 5
    results.sort(key=lambda x: (0 if x["has_tg"] else 1))
    return results[:5]


def _inject_pinned_tokens(chain_tokens: dict):
    """Mutate chain_tokens in-place: insert owner-pinned tokens at position 0.
    Pins expire after 24 hours. Fetches live MC from DexScreener for each pinned CA.
    Works for both old posts (SOL/ETH/BNB/BASE) and new posts (SOL/ETH/BSC/RH/BASE/TON)."""
    try:
        pins = load_pinned_trending()
        now  = datetime.utcnow()
        changed = False
        for chain_key, pin in list(pins.items()):
            try:
                pinned_at = datetime.fromisoformat(pin.get("pinned_at",""))
                if now - pinned_at > timedelta(hours=24):
                    del pins[chain_key]; changed = True; continue
            except Exception: pass
            ca      = pin.get("ca","")
            tg_link = pin.get("tg_link","")
            sym     = pin.get("symbol","PIN")
            mc_fmt  = pin.get("mc_fmt","N/A")
            dex_url = pin.get("dex_url","")

            # Fetch live MC from DexScreener
            try:
                r = requests.get(
                    f"https://api.dexscreener.com/latest/dex/tokens/{ca}",
                    timeout=10, headers=HEADERS)
                if r.status_code == 200:
                    pairs = r.json().get("pairs") or []
                    if pairs:
                        best = max(pairs, key=lambda p: float(p.get("liquidity",{}).get("usd",0) or 0))
                        mc_raw = float(best.get("marketCap") or best.get("fdv") or 0)
                        if mc_raw > 0:
                            mc_fmt = fmt_mc(mc_raw)
                            sym    = best.get("baseToken",{}).get("symbol", sym)
                        if not dex_url:
                            # Build dex_url from pair chain info
                            pair_chain = best.get("chainId","").lower()
                            dex_url = f"https://dexscreener.com/{pair_chain}/{ca}"
                        # Update stored mc_fmt and symbol for next cycle
                        pin["mc_fmt"]  = mc_fmt
                        pin["symbol"]  = sym
                        pin["dex_url"] = dex_url
                        changed = True
            except Exception:
                pass

            pinned_token = {
                "symbol": sym, "mc_fmt": mc_fmt,
                "tg_url": tg_link, "dex_url": dex_url, "has_tg": bool(tg_link),
                "_pinned": True,
            }
            # Insert at index 0 for every variant of the chain key that matches
            for ck in (chain_tokens if isinstance(chain_tokens, dict) else {}).keys():
                if ck.upper() == chain_key.upper():
                    lst = list(chain_tokens[ck])
                    # Remove any old pinned entry first
                    lst = [t for t in lst if not t.get("_pinned")]
                    chain_tokens[ck] = [pinned_token] + lst
                    break

        if changed:
            save_pinned_trending(pins)
    except Exception as e:
        logger.warning(f"_inject_pinned_tokens: {e}")


def _fetch_trending_sync():
    """Fetch trending tokens.
    SOL  → DexScreener token-boosts (works well for Solana).
    ETH / BNB / BASE → GeckoTerminal trending_pools (reliable per-chain endpoint).
    """
    chain_tokens: dict = {"ETH": [], "BNB": [], "SOL": [], "BASE": []}
    blacklist = load_trending_blacklist()

    # ── SOL: DexScreener boosts (unchanged, works perfectly) ─────────────────
    try:
        resp = requests.get(
            "https://api.dexscreener.com/token-boosts/top/v1",
            timeout=20, headers=HEADERS
        )
        if resp.status_code == 200:
            raw = resp.json()
            if isinstance(raw, list):
                sol_candidates = []
                seen = set()
                for token in raw:
                    if token.get("chainId", "").lower() != "solana": continue
                    ca = token.get("tokenAddress", "")
                    if not ca or ca in seen or ca.lower() in blacklist: continue
                    seen.add(ca)
                    tg = _extract_tg_link(token.get("links") or [])
                    sol_candidates.append((ca, tg))

                # Batch pairs lookup for SOL
                sol_results = []
                for batch_start in range(0, min(len(sol_candidates), 60), 10):
                    batch = sol_candidates[batch_start: batch_start + 10]
                    cas   = [ca for ca, _ in batch]
                    tg_map = {ca: tg for ca, tg in batch}
                    try:
                        r = requests.get(
                            f"https://api.dexscreener.com/latest/dex/tokens/{','.join(cas)}",
                            timeout=15, headers=HEADERS
                        )
                        if r.status_code != 200: continue
                        pairs_data = r.json().get("pairs") or []
                    except Exception as e:
                        logger.warning(f"SOL batch pairs failed: {e}"); continue

                    best_per_ca: dict = {}
                    for pair in pairs_data:
                        ca_key = pair.get("baseToken", {}).get("address", "")
                        if ca_key not in best_per_ca:
                            best_per_ca[ca_key] = pair
                        else:
                            liq_new = pair.get("liquidity", {}).get("usd", 0) or 0
                            liq_old = best_per_ca[ca_key].get("liquidity", {}).get("usd", 0) or 0
                            if liq_new > liq_old:
                                best_per_ca[ca_key] = pair
                    for ca in cas:
                        pair = best_per_ca.get(ca)
                        if not pair: continue
                        mc = float(pair.get("marketCap") or pair.get("fdv") or 0)
                        if mc <= 0: continue
                        tg = tg_map.get(ca, "")
                        if not tg:
                            info = pair.get("info") or {}
                            for s in (info.get("socials") or []):
                                u = s.get("url",""); t = s.get("type","").lower()
                                if "t.me" in u or "telegram" in t: tg = u; break
                        sol_results.append({
                            "symbol":  pair.get("baseToken", {}).get("symbol", "TOKEN"),
                            "mc_fmt":  fmt_mc(mc),
                            "tg_url":  tg,
                            "dex_url": f"https://dexscreener.com/solana/{ca}",
                            "has_tg":  bool(tg),
                        })
                    time.sleep(0.2)

                sol_results.sort(key=lambda x: (0 if x["has_tg"] else 1))
                chain_tokens["SOL"] = sol_results[:5]
    except Exception as e:
        logger.warning(f"SOL trending fetch failed: {e}")

    # ── ETH / BNB / BASE: GeckoTerminal (reliable, per-chain trending) ───────
    gecko_map = [
        ("eth",  "ETH"),
        ("bsc",  "BNB"),
        ("base", "BASE"),
    ]
    for gecko_net, chain_key in gecko_map:
        try:
            chain_tokens[chain_key] = _fetch_gecko_chain(gecko_net, chain_key, blacklist)
        except Exception as e:
            logger.warning(f"GeckoTerminal {gecko_net} failed: {e}")
        time.sleep(0.3)  # polite pause between chain calls

    # ── Inject pinned tokens at position 0 for their chain ─────────────────────
    _inject_pinned_tokens(chain_tokens)
    return chain_tokens

async def fetch_trending():
    return await asyncio.to_thread(_fetch_trending_sync)

def _calc_trending_kols():
    """Top 10 tracked channels sorted by highest X milestone (descending).
    Respects trending_kols_reset_since — only counts calls tracked AFTER last reset.
    Returns list of dicts: {channel, best_x, wizard_post_id}"""
    channels = load_channels()

    cfg_now = load_config()
    # Primary exclusion: call_keys snapshot at reset time (most reliable)
    excluded_keys = set(cfg_now.get("lb_excluded_call_keys", []))
    # Secondary: date-based filter (catches calls added after reset but before snapshot)
    tk_reset_since = cfg_now.get("trending_kols_reset_since", "")
    tk_reset_dt = None
    if tk_reset_since:
        try: tk_reset_dt = datetime.fromisoformat(tk_reset_since)
        except Exception: tk_reset_dt = None

    scores = []
    for ch in channels:
        best_x = 0
        best_call_key = None
        for call_key, call in tracked_calls.items():
            if call.get("channel", "").lower() != ch.lower(): continue
            # Skip calls that were present at reset time
            if call_key in excluded_keys:
                continue
            # Also skip calls tracked before the last manual reset (secondary guard)
            if tk_reset_dt:
                ts_str = call.get("tracked_since", "")
                if not ts_str:
                    continue
                try:
                    ts = datetime.fromisoformat(ts_str)
                    if ts < tk_reset_dt: continue
                except Exception:
                    continue
            ms = list(sent_milestones.get(call_key, set()))
            if ms:
                mx = max(ms)
                if mx > best_x:
                    best_x = mx
                    best_call_key = call_key
        # Only include channels that have reached at least 2x after reset
        if best_x < 2:
            continue
        # Get WizardScan post ID for this channel's highest X milestone
        wizard_post_id = None
        if best_call_key:
            posts = milestone_posts.get(best_call_key, {})
            wizard_post_id = posts.get(str(best_x))
        scores.append({"channel": ch, "best_x": best_x, "wizard_post_id": wizard_post_id})
    scores.sort(key=lambda x: x["best_x"], reverse=True)
    return scores[:10]

# ─── Channel scraping ─────────────────────────────────────────────────────────
def _fetch_posts_sync(channel):
    try:
        resp = requests.get(f"https://t.me/s/{channel}", headers=HEADERS, timeout=15)
        if resp.status_code != 200: return []
        soup  = BeautifulSoup(resp.text, "html.parser")
        posts = []
        for div in soup.find_all("div", class_="tgme_widget_message"):
            attr   = div.get("data-post","")
            msg_id = attr.split("/")[-1] if "/" in attr else attr
            td     = div.find("div", class_="tgme_widget_message_text")
            text   = td.get_text(separator="\n") if td else ""
            ts = 0
            try:
                tnode = div.find("time")
                if tnode and tnode.get("datetime"):
                    ts = datetime.fromisoformat(
                        tnode["datetime"].replace("Z", "+00:00")).timestamp()
            except Exception:
                ts = 0
            posts.append({"id": msg_id, "text": text, "ts": ts})
        return posts
    except Exception as e:
        logger.error(f"Fetch {channel}: {e}"); return []

async def _fetch_posts_via_userbot(channel: str, limit: int = 25) -> list:
    """REALTIME-GRADE: Fetch recent posts via Telethon MTProto instead of t.me/s scraping.
    Much faster, more reliable, fetches full message text including hidden links.
    Falls back to t.me/s if userbot unavailable."""
    global userbot_client
    if not userbot_client or not userbot_client.is_connected():
        return []
    try:
        posts = []
        async for msg in userbot_client.iter_messages(channel, limit=limit):
            if not msg: continue
            msg_id = str(msg.id)
            raw_text = msg.text or msg.message or ""
            # Also try to get caption from media
            if not raw_text and hasattr(msg, 'caption') and msg.caption:
                raw_text = msg.caption
            # Extract text from message entities (inline buttons etc have URLs)
            if msg.entities:
                try:
                    from telethon.tl.types import MessageEntityTextUrl, MessageEntityUrl
                    for ent in msg.entities:
                        if isinstance(ent, MessageEntityTextUrl):
                            raw_text += f" {ent.url}"
                        elif isinstance(ent, MessageEntityUrl):
                            offset, length = ent.offset, ent.length
                            raw_text += f" {msg.message[offset:offset+length]}" if msg.message else ""
                except Exception:
                    pass
            try:
                ts = msg.date.timestamp() if getattr(msg, "date", None) else 0
            except Exception:
                ts = 0
            posts.append({"id": msg_id, "text": raw_text, "ts": ts})
        return posts
    except Exception as e:
        logger.warning(f"Userbot fetch @{channel}: {e}")
        return []

async def fetch_channel_posts(channel, limit: int = 25):
    """Fetch recent posts. Prefers Telethon MTProto (fast/reliable), falls back to t.me/s scraping."""
    # Try Telethon first — like SpyDefi/Kolscope, direct MTProto is far more reliable
    if userbot_client and userbot_client.is_connected():
        posts = await _fetch_posts_via_userbot(channel, limit=limit)
        if posts:
            return posts
    # Fallback: t.me/s HTML scraping (only ~20 posts, slow, but works without userbot)
    return await asyncio.to_thread(_fetch_posts_sync, channel)

def extract_ca(text):
    # TON first — check before SOL to avoid misidentification (TON addresses can match SOL pattern)
    ton = TON_CA_PATTERN.findall(text)
    if ton:
        # findall returns prefix groups; reconstruct full address
        full_matches = TON_CA_PATTERN.finditer(text)
        for m in full_matches:
            return ("TON", m.group(0))
    eth = ETH_CA_PATTERN.findall(text)
    if eth: return ("EVM", eth[0].lower())
    for s in SOL_CA_PATTERN.findall(text):
        if not s.startswith("0x") and 32 <= len(s) <= 44: return ("SOL", s)
    return None

# ─── Extract CA from chart / DEX links ────────────────────────────────────────
_DEX_LINK_CHAIN_MAP = {
    "solana": "SOL", "sol": "SOL",
    "ethereum": "EVM", "eth": "EVM",
    "bsc": "EVM", "bnb": "EVM", "binance": "EVM",
    "base": "EVM",
    "robinhood": "EVM", "rh": "EVM",
    "ton": "TON",
}

# Regex: dexscreener.com/{chain}/{ca}  OR  dextools.io/app/en/{chain}/pair-explorer/{ca}
# OR birdeye.so/token/{ca}  OR bullx.io with address={ca}  OR photon-sol.trac.so/{ca}
# Address patterns — covers SOL (base58, 32-44 chars), TON (EQ/UQ base64, 48 chars), EVM (0x hex, 42 chars)
_SOL_TON_ADDR = r'[1-9A-HJ-NP-Za-km-z]{32,50}'   # base58-like; covers both SOL (32-44) and TON EQ/UQ (48)
_EVM_ADDR     = r'0x[a-fA-F0-9]{40}'
_ANY_CA       = rf'({_SOL_TON_ADDR}|{_EVM_ADDR})'

_DEXSCREENER_RE = re.compile(
    r'dexscreener\.com/([a-z0-9_-]+)/(' + _SOL_TON_ADDR + r'|' + _EVM_ADDR + r')',
    re.IGNORECASE
)
_DEXTOOLS_RE = re.compile(
    r'dextools\.io/app(?:/[a-z]+)?/([a-z0-9_-]+)/pair-explorer/' + _ANY_CA,
    re.IGNORECASE
)
_BULLX_RE = re.compile(
    r'bullx\.io[^\s]*[?&]address=' + _ANY_CA,
    re.IGNORECASE
)
_PHOTON_RE = re.compile(
    r'photon-sol\.trac\.so/(' + _SOL_TON_ADDR + r')',
    re.IGNORECASE
)
_BIRDEYE_RE = re.compile(
    r'birdeye\.so/token/' + _ANY_CA,
    re.IGNORECASE
)
# Gmgn, ave.ai (also common chart links in KOL posts)
_GMGN_RE = re.compile(
    r'gmgn\.ai/[a-z0-9]*/token/(?:[a-z]*/)?(' + _SOL_TON_ADDR + r'|' + _EVM_ADDR + r')',
    re.IGNORECASE
)
_AVE_RE = re.compile(
    r'ave\.ai/token/' + _ANY_CA,
    re.IGNORECASE
)

def extract_ca_from_links(text):
    """Try to extract a CA from known DEX/chart links in the message text.
    Returns (chain_guess, ca) like extract_ca(), or None if nothing found."""
    if not text:
        return None

    def _valid_ca(ca, chain_guess="SOL"):
        """Validate and normalise a CA string. Returns (chain, ca) or None."""
        if not ca: return None
        if ca.startswith("0x") and len(ca) == 42:
            return ("EVM", ca.lower())
        # TON: EQ/UQ + 46 base64url chars = 48 total
        if re.match(r'^(EQ|UQ)[A-Za-z0-9_-]{46}$', ca):
            return ("TON", ca)
        # SOL: base58, 32-44 chars (never starts with 0x)
        if 32 <= len(ca) <= 44 and not ca.startswith("0x"):
            return (chain_guess, ca)
        return None

    # DexScreener: dexscreener.com/{chain}/{ca}
    for m in _DEXSCREENER_RE.finditer(text):
        chain_raw = m.group(1).lower()
        ca = m.group(2)
        chain_guess = _DEX_LINK_CHAIN_MAP.get(chain_raw, "EVM")
        r = _valid_ca(ca, chain_guess)
        if r: return r

    # DexTools
    for m in _DEXTOOLS_RE.finditer(text):
        chain_raw = m.group(1).lower()
        ca = m.group(2)
        chain_guess = _DEX_LINK_CHAIN_MAP.get(chain_raw, "EVM")
        r = _valid_ca(ca, chain_guess)
        if r: return r

    # BullX
    for m in _BULLX_RE.finditer(text):
        r = _valid_ca(m.group(1), "SOL")
        if r: return r

    # Photon (Solana only)
    for m in _PHOTON_RE.finditer(text):
        r = _valid_ca(m.group(1), "SOL")
        if r: return r

    # Birdeye
    for m in _BIRDEYE_RE.finditer(text):
        r = _valid_ca(m.group(1), "SOL")
        if r: return r

    # Gmgn
    for m in _GMGN_RE.finditer(text):
        r = _valid_ca(m.group(1), "SOL")
        if r: return r

    # Ave.ai
    for m in _AVE_RE.finditer(text):
        r = _valid_ca(m.group(1), "SOL")
        if r: return r

    return None

def is_call_message(text):
    if not text or len(text) < 10: return False
    tl  = text.lower()
    kw  = ["buy","long","entry","target","tp ","gem"," call","launch","listed","mcap",
           "market cap","ca:","contract","bullish","ape","snipe","early","presale",
           "stealth","kol","dexscreener","dextools","birdeye","pump.fun","bullx","photon",
           "ton","toncoin","dedust","stonfi","ston.fi","getgems","gmgn","ave.ai","defined.fi"]
    return any(k in tl for k in kw) or bool(ETH_CA_PATTERN.search(text)) or \
           bool(TON_CA_PATTERN.search(text)) or \
           any(32<=len(s)<=44 for s in SOL_CA_PATTERN.findall(text) if not s.startswith("0x"))

# ─── Alert building ───────────────────────────────────────────────────────────
# 🔮 placeholders in order:
#   ≤99x  : chain, crystal, teer, kol, bot      (5 emojis)
#   100-999x: chain, crystal, teer, kol, bot    (5 emojis)
#   1000x+: chain, crystal(champ), crystal(entry), teer, kol, bot  (6 emojis)
DEFAULT_TEMPLATE = (
    "<b>🔮 @{channel} KOL Hit {x}X+</b>\n"
    "<b>🔮 {entry}    🔮    {current}</b>\n\n"
    "Ca: <code>{ca}</code>\n\n"
    '🔮<a href="{mae_link}">MAE</a>\n'
    '🔮<a href="{kol_link}">KOL</a>\n'
    '🔮<a href="{bot_link}">BOT</a>'
)

DEFAULT_X_TEMPLATE = DEFAULT_TEMPLATE  # X features removed

def _migrate_remove_x_from_templates():
    """Fix stored templates to remove X/Twitter.
    Strategy:
      - x_alert_template: if it has X lines OR is missing {mae_link} → delete it
        entirely so DEFAULT_X_TEMPLATE (MAE/KOL/BOT order) is used automatically.
      - alert_template: strip X lines in-place (owner may have other customisations).
      - milestone_templates: strip X lines in-place.
    """
    import re as _re
    _x_link_pat  = _re.compile(r"\n🔮[^\n]*(?:twitter|x)\.com[^\n]*", _re.IGNORECASE)
    _x_plain_pat = _re.compile(r"\n🔮\s*X(?:[^a-zA-Z]|$)", _re.IGNORECASE)
    cfg     = load_config()
    changed = False

    # ── x_alert_template: reset entirely if broken ──────────────────────────
    x_tmpl = cfg.get("x_alert_template", "")
    if x_tmpl:
        has_x_line = bool(_x_link_pat.search(x_tmpl) or _x_plain_pat.search(x_tmpl))
        has_mae    = "mae_link" in x_tmpl
        if has_x_line or not has_mae:
            cfg.pop("x_alert_template", None)
            changed = True
            logger.info("Migration: deleted x_alert_template (had X line or missing MAE) "
                        "→ will use DEFAULT_X_TEMPLATE (MAE/KOL/BOT)")

    # ── alert_template: strip X lines only (keep other customisations) ──────
    a_tmpl = cfg.get("alert_template", "")
    if a_tmpl:
        cleaned = _x_link_pat.sub("", a_tmpl)
        cleaned = _x_plain_pat.sub("", cleaned)
        if cleaned != a_tmpl:
            cfg["alert_template"] = cleaned
            changed = True

    # ── milestone_templates: strip X lines ──────────────────────────────────
    for ms_key, tmpl in cfg.get("milestone_templates", {}).items():
        if not tmpl:
            continue
        cleaned = _x_link_pat.sub("", tmpl)
        cleaned = _x_plain_pat.sub("", cleaned)
        if cleaned != tmpl:
            cfg["milestone_templates"][ms_key] = cleaned
            changed = True

    if changed:
        save_config(cfg)
        logger.info("Migration: X/Twitter cleanup done")

async def _update_prices_for_chain_tokens(chain_tokens: dict) -> dict:
    """Fetch fresh MC prices for cached tokens without replacing the token list.
    Extracts CA from dex_url and queries DexScreener. Only mc_fmt is updated."""
    result = {}
    for chain_key, tokens in chain_tokens.items():
        if not tokens:
            result[chain_key] = tokens
            continue
        updated = [dict(t) for t in tokens]
        ca_index: dict = {}
        for i, t in enumerate(updated):
            dex_url = t.get("dex_url", "")
            ca = dex_url.rstrip("/").split("/")[-1] if dex_url else ""
            if ca and len(ca) >= 20:
                ca_index[ca] = i
        if not ca_index:
            result[chain_key] = updated
            continue
        try:
            cas = list(ca_index.keys())[:30]
            r = await asyncio.to_thread(
                requests.get,
                f"https://api.dexscreener.com/latest/dex/tokens/{','.join(cas)}",
                timeout=15,
                headers=HEADERS
            )
            if r.status_code == 200:
                pairs_data = r.json().get("pairs") or []
                best_mc: dict = {}
                for pair in pairs_data:
                    ca_key = pair.get("baseToken", {}).get("address", "")
                    mc = float(pair.get("marketCap") or pair.get("fdv") or 0)
                    if ca_key and mc > 0 and (ca_key not in best_mc or mc > best_mc[ca_key]):
                        best_mc[ca_key] = mc
                for ca, idx in ca_index.items():
                    if ca in best_mc:
                        updated[idx]["mc_fmt"] = fmt_mc(best_mc[ca])
        except Exception as _pe:
            logger.warning(f"Price update {chain_key}: {_pe}")
        result[chain_key] = updated
    return result

# ─── Tiered templates (100X–9999X) ────────────────────────────────────────────
TIERED_TEMPLATES = [
    (2, 99,
        "<b>🔮 @{channel} KOL Hit {x}X+</b>\n\n"
        "${symbol} {chain} play called at {entry} market cap. "
        "Current Market Cap stands at {current}. "
        "Clean execution. Tracking for the next move.\n\n"
        "<b>🔮 {entry}    🔮    {current}</b>\n\n"
        "Ca: <code>{ca}</code>\n\n"
        '🔮<a href="{mae_link}">MAE</a>\n'
        '🔮<a href="{kol_link}">KOL</a>\n'
        '🔮<a href="{bot_link}">BOT</a>'
    ),
    (100, 499,
        "<b>🔮 SOLID KOL @{channel}</b>\n\n"
        "@{channel} delivered {x}X. ${symbol} was called at a {entry} MC. Current MC stands at {current}. "
        "Massive move delivered. Eyes on the next milestone.\n\n"
        "<b>🔮 {entry}  🔮  {current}</b>\n\n"
        "CA: <code>{ca}</code>\n\n"
        '🔮<a href="{mae_link}">MAE</a>\n'
        '🔮<a href="{kol_link}">KOL</a>\n'
        '🔮<a href="{bot_link}">BOT</a>'
    ),
    (500, 999,
        "<b>🔮 Apex KOL @{channel}</b>\n\n"
        "@{channel} printed {x}X. ${symbol} continues to exceed expectations, climbing from {entry} MC to {current}. "
        "Another milestone secured. Based KOL of Wizard Scan.\n\n"
        "<b>🔮 {entry}  🔮  {current}</b>\n\n"
        "CA: <code>{ca}</code>\n\n"
        '🔮<a href="{mae_link}">MAE</a>\n'
        '🔮<a href="{kol_link}">KOL</a>\n'
        '🔮<a href="{bot_link}">BOT</a>'
    ),
    (1000, 1999,
        "<b>🔮 ELITE KOL @{channel}</b>\n\n"
        "@{channel} nailed {x}X. ${symbol} was called at a {entry} MC and has now climbed to {current}. "
        "A truly elite performance with exceptional returns.\n\n"
        "<b>🔮 {entry}  🔮  {current}</b>\n\n"
        "CA: <code>{ca}</code>\n\n"
        '🔮<a href="{mae_link}">MAE</a>\n'
        '🔮<a href="{kol_link}">KOL</a>\n'
        '🔮<a href="{bot_link}">BOT</a>'
    ),
    (2000, 2999,
        "<b>🔮 RARE KOL @{channel}</b>\n\n"
        "@{channel} crushed {x}X. ${symbol} was called at a {entry} MC and has now reached {current}. "
        "An extraordinary run that stands among the rarest performances.\n\n"
        "<b>🔮 {entry}  🔮  {current}</b>\n\n"
        "CA: <code>{ca}</code>\n\n"
        '🔮<a href="{mae_link}">MAE</a>\n'
        '🔮<a href="{kol_link}">KOL</a>\n'
        '🔮<a href="{bot_link}">BOT</a>'
    ),
    (3000, 4999,
        "<b>🔮 EPIC KOL @{channel}</b>\n\n"
        "@{channel} smashed {x}X. From {entry} MC to {current}, ${symbol} delivered a historic performance. "
        "One of the biggest moves ever tracked.\n\n"
        "<b>🔮 {entry}  🔮  {current}</b>\n\n"
        "CA: <code>{ca}</code>\n\n"
        '🔮<a href="{mae_link}">MAE</a>\n'
        '🔮<a href="{kol_link}">KOL</a>\n'
        '🔮<a href="{bot_link}">BOT</a>'
    ),
    (5000, 9999,
        "<b>🔮 LEGENDARY KOL @{channel}</b>\n\n"
        "@{channel} hit {x}X. The results speak for themselves. ${symbol} climbed from {entry} MC to {current}, "
        "once again delivering exceptional returns. Another historic call added to the record.\n\n"
        "<b>🔮 {entry}  🔮  {current}</b>\n\n"
        "CA: <code>{ca}</code>\n\n"
        '🔮<a href="{mae_link}">MAE</a>\n'
        '🔮<a href="{kol_link}">KOL</a>\n'
        '🔮<a href="{bot_link}">BOT</a>'
    ),
]

CHAMPION_TEMPLATE = (
    "<b>🔮 HALL OF FAME @{channel}</b>\n\n"
    "@{channel} printed {x}X. ${symbol} on {chain}, from {entry} to {current}. "
    "This is the rarest of rare calls.\n\n"
    "@{channel} didn't just call it. They owned it. A masterclass in execution.\n\n"
    "This is what legends are made of. Welcome to the Hall of Fame.\n\n"
    "<b>🔮 {entry}  🔮  {current}</b>\n\n"
    "CA: <code>{ca}</code>\n\n"
    '🔮<a href="{mae_link}">MAE</a>\n'
    '🔮<a href="{kol_link}">KOL</a>\n'
    '🔮<a href="{bot_link}">BOT</a>'
)

def _get_alert_pack():
    """Return current EMOJI_PACK.
    If the owner has locked a specific pack (via /setemojipack), always use that —
    this avoids the pack silently jumping around whenever channel_post_count
    changes (e.g. after a config reset). Otherwise falls back to auto-rotation
    every 10 posts based on post count."""
    config = load_config()
    locked = config.get("locked_emoji_pack")
    if locked:
        for pack in EMOJI_PACKS:
            if pack["name"] == locked:
                return pack
    count = config.get("channel_post_count", 0)
    return EMOJI_PACKS[(count // 10) % len(EMOJI_PACKS)]

def _get_alert_emoji_ids(x_val, chain, pack=None):
    """Build ordered emoji_ids list for _build_premium_entities injection.
    Order matches 🔮 placeholder positions in each template tier:
      ≤99x   : [crystal, teer, kol, bot]
      100-999x: [chain, crystal, teer, kol, bot]
      1000x+  : [chain, crystal(champ), crystal(entry), teer, kol, bot]
    Extra post links (if any) append their emoji IDs at the end.
    RH chain emoji is read from config (set via /setrobinemoji).
    """
    if pack is None:
        pack = _get_alert_pack()
    chain_key = (chain or "").upper()

    # ── Robinhood chain: config override first, then hardcoded pack emoji ─
    if chain_key == "RH":
        rh_emojis   = load_config().get("rh_chain_emojis", {})
        rh_emoji_id = rh_emojis.get(pack["name"], 0)
        # Priority: /setrobinemoji override → hardcoded pack["chain"]["RH"] → BASE fallback
        chain_emoji = (rh_emoji_id
                       or pack["chain"].get("RH")
                       or pack["chain"].get("BASE")
                       or pack["chain"].get("SOL"))
    elif chain_key == "EVM":
        # FIX: EVM (unknown EVM chain) → ETH emoji, not SOL
        chain_emoji = pack["chain"].get("ETH") or pack["chain"].get("SOL")
    else:
        chain_emoji = pack["chain"].get(chain_key) or pack["chain"].get("ETH") or pack["chain"].get("SOL")

    crystal    = pack["crystal"]
    teer       = TEER_EMOJI_ID
    # NOTE: kol and bot_em are intentionally excluded — _build_premium_entities
    # special-cases 🔮KOL / 🔮BOT and injects pack.kol / pack.bot directly.
    # Including them here would shift badge emoji IDs into the wrong positions.
    #
    # ALL tiers use exactly 3 regular 🔮 placeholders:
    #   🔮 (header) → chain_emoji
    #   🔮 (entry MC) → crystal
    #   🔮 (separator between MCs) → teer  ← always TEER_EMOJI_ID (5346105514575025401)
    #                                         even if template is edited by owner
    # Previously 1000x+ had [chain, crystal, crystal, teer] (4 items) which caused
    # the badge 🔮 to consume teer instead of lb_star — breaking LEADERBOARD KOL label.
    base = [chain_emoji, crystal, teer]
    # Append emoji IDs for extra post links (owner-configured via /addpostlink)
    extra_links = load_config().get("extra_post_links", [])
    for lnk in extra_links:
        eid = lnk.get("emoji_id")
        if eid:
            base.append(int(eid))
    return base

def _get_tiered_template(x_val):
    """Return tiered template string for x_val range, or None."""
    if x_val >= 10000:
        return CHAMPION_TEMPLATE
    for lo, hi, tmpl in TIERED_TEMPLATES:
        if lo <= x_val <= hi:
            return tmpl
    return None

def _get_range_template(x_val, config=None):
    """Return owner-defined custom range template for x_val, or None.
    Ranges are set via /setrangetemplate LOW HIGH and stored in config['range_templates']
    as a list of {"low":..,"high":..,"template":..}. Checked before the hardcoded
    TIERED_TEMPLATES so the owner's own per-range text always wins."""
    config = config or load_config()
    for r in config.get("range_templates", []):
        try:
            if int(r["low"]) <= x_val <= int(r["high"]):
                return r["template"]
        except (KeyError, ValueError, TypeError):
            continue
    return None

def build_alert(channel, msg_id, x_val, chain, entry_fmt, current_fmt, ca, symbol, badge=None):
    kol_link = f"https://t.me/{channel}/{msg_id}" if msg_id else f"https://t.me/{channel}"
    config   = load_config()
    # Priority: 1) specific milestone template  2) owner-defined range template
    #           3) global custom (owner set via /settemplate)
    #           4) hardcoded tiered range fallback (incl. champion at 10000X)  5) default
    # NOTE: global custom (alert_template) intentionally ranks ABOVE tiered so that
    # /settemplate always overrides the built-in 100x-9999x tiered texts.
    template = (config.get("milestone_templates",{}).get(str(x_val))
                or _get_range_template(x_val, config)
                or config.get("alert_template")
                or _get_tiered_template(x_val)
                or DEFAULT_TEMPLATE)
    mae_link = f"{MAESTRO_REFLINK_BASE}{ca}{MAESTRO_REF_SUFFIX}" if ca else f"{MAESTRO_REFLINK_BASE}r-wizard_scan"
    kwargs = dict(channel=channel, x=x_val, symbol=(symbol or "TOKEN").upper(), chain=chain,
                  entry=entry_fmt, current=current_fmt, ca=ca,
                  kol_link=kol_link, tg_link=TG_CHANNEL_LINK, bot_link=BOT_LINK,
                  mae_link=mae_link)
    try:
        text = safe_format(template, **kwargs)
    except Exception:
        text = safe_format(DEFAULT_TEMPLATE, **kwargs)

    # Append 12-hour promo link for 2x-50x alerts
    if 2 <= x_val <= 50:
        promo = config.get("promo_link")
        if promo and promo.get("url") and promo.get("text") and promo.get("set_at"):
            try:
                if datetime.utcnow() - datetime.fromisoformat(promo["set_at"]) < timedelta(hours=12):
                    text += f'\n\n<a href="{promo["url"]}">{html.escape(promo["text"])}</a>'
            except Exception:
                pass

    # Append Leaderboard / Champions badge
    if badge is None:
        badge = _get_kol_badge(channel)
    if badge:
        if badge["type"] == "leaderboard":
            text += f'\n\n🔮 <b><a href="https://t.me/WizardScan/136">LEADERBOARD KOL</a></b> 🔮'
        else:
            text += f'\n\n🔮 <b><a href="https://t.me/WizardScan/137">CHAMPION KOL</a></b> 🔮'

    # Append owner-configured extra post links
    extra_links = config.get("extra_post_links", [])
    for lnk in extra_links:
        lnk_text = html.escape(lnk.get("text", ""))
        lnk_url  = lnk.get("url", "")
        if lnk_text and lnk_url:
            text += f'\n🔮<a href="{lnk_url}">{lnk_text}</a>'

    return text

def build_x_alert(channel, msg_id, x_val, chain, entry_fmt, current_fmt, ca, symbol):
    """Build alert text for the X/Twitter channel (@WizardscanX)."""
    kol_link = f"https://t.me/{channel}/{msg_id}" if msg_id else f"https://t.me/{channel}"
    config   = load_config()
    template = config.get("x_alert_template") or DEFAULT_X_TEMPLATE
    mae_link = f"{MAESTRO_REFLINK_BASE}{ca}{MAESTRO_REF_SUFFIX}" if ca else f"{MAESTRO_REFLINK_BASE}r-wizard_scan"
    kwargs = dict(channel=channel, x=x_val, symbol=(symbol or "TOKEN").upper(), chain=chain,
                  entry=entry_fmt, current=current_fmt, ca=ca,
                  kol_link=kol_link, tg_link=TG_CHANNEL_LINK, bot_link=BOT_LINK,
                  mae_link=mae_link)
    try:
        return safe_format(template, **kwargs)
    except Exception:
        return safe_format(DEFAULT_X_TEMPLATE, **kwargs)

def build_milestone_keyboard(x_val):
    buttons = load_config().get("milestone_buttons",{}).get(str(x_val),[])
    if not buttons: return None
    rows = [[InlineKeyboardButton(b["text"], url=b["url"])] for b in buttons if b.get("text") and b.get("url")]
    return InlineKeyboardMarkup(rows) if rows else None

def _build_premium_entities(plain_text, base_entities, emoji_ids, forced_pack=None):
    """Replace each 🔮 in plain_text with the next emoji_id from the list.
    emoji_ids may be a single str/int or a list. Falls back to last id when list runs out.

    Special-cases (in priority order):
    1. 🔮KOL / 🔮BOT  → pack kol/bot emoji (always, regardless of position)
    2. 🔮X or 🔮 X    → pack x emoji (locked — works even if template edited)
    3. 🔮 LEADERBOARD KOL / 🔮 CHAMPION KOL → badge star emoji (auto-detected)
    4. badge closing 🔮 (follows badge marker) → badge rank emoji (auto-detected)
    5. MC separator 🔮 (between entry MC and current MC) → TEER_EMOJI_ID=5346105514575025401 (locked)
    6. all other 🔮s  → next item from non-badge portion of emoji_ids

    Badge emojis (star + rank, appended at end of emoji_ids by send_alert) are
    auto-detected from the text so they NEVER get consumed by template 🔮 placeholders,
    even when the owner edits the template with extra 🔮s.
    """
    from telethon.tl.types import MessageEntityCustomEmoji
    if not isinstance(emoji_ids, list):
        emoji_ids = [emoji_ids]
    emoji_ids = [e for e in emoji_ids if e]
    pack = forced_pack if forced_pack is not None else _get_alert_pack()
    kol_id = pack.get("kol")
    bot_id = pack.get("bot")
    mae_id = pack.get("mae") or 0
    if not emoji_ids and not kol_id and not bot_id and not mae_id:
        return base_entities or []

    # ── Badge auto-detection ───────────────────────────────────────────────────
    # Badge text (' LEADERBOARD KOL' / ' CHAMPION KOL') is always appended LAST.
    # Pre-scan to detect badge presence and split emoji_ids into:
    #   non_badge_ids — consumed by regular template 🔮s via pos_index
    #   badge_ids     — reserved for badge star + rank, never consumed by template 🔮s
    _badge_type = None
    if ' LEADERBOARD KOL' in plain_text and ' LEADERBOARD KOLS' not in plain_text:
        _badge_type = 'leaderboard'
    elif ' CHAMPION KOL' in plain_text and ' CHAMPION KOLS' not in plain_text:
        _badge_type = 'champion'
    badge_count = 2 if _badge_type else 0

    if badge_count and len(emoji_ids) >= badge_count:
        non_badge_ids = emoji_ids[:-badge_count]
        badge_ids     = emoji_ids[-badge_count:]
    else:
        non_badge_ids = emoji_ids
        badge_ids     = []

    custom_entities = []
    pos_index = 0
    utf16_off = 0
    i = 0
    PLACEHOLDER = '🔮'
    PH_LEN = len(PLACEHOLDER)
    emoji_u16 = len(PLACEHOLDER.encode('utf-16-le')) // 2
    _badge_rank_pending = False  # True after we emitted the badge star emoji

    while i < len(plain_text):
        if plain_text[i:i+PH_LEN] == PLACEHOLDER:
            rest = plain_text[i+PH_LEN:]
            eid  = None

            if rest.startswith('KOL') and kol_id:
                # 🔮KOL → pack kol emoji
                eid = kol_id

            elif rest.startswith('BOT') and bot_id:
                # 🔮BOT → pack bot emoji
                eid = bot_id

            elif mae_id and rest.startswith('MAE'):
                # 🔮MAE → pack mae (Maestro) emoji — replaces the old 🔮X slot
                eid = mae_id

            elif rest.startswith(' LEADERBOARD KOL') and not rest.startswith(' LEADERBOARD KOLS') and badge_ids:
                # Badge header star — always the first badge_id
                eid = badge_ids[0]
                _badge_rank_pending = True

            elif rest.startswith(' CHAMPION KOL') and not rest.startswith(' CHAMPION KOLS') and badge_ids:
                # Badge header star — always the first badge_id
                eid = badge_ids[0]
                _badge_rank_pending = True

            elif _badge_rank_pending:
                # Closing 🔮 of the badge line → rank emoji
                eid = badge_ids[1] if len(badge_ids) > 1 else None
                _badge_rank_pending = False

            else:
                # ── MC separator lock ─────────────────────────────────────────
                # The 🔮 between entry MC and current MC must ALWAYS be TEER_EMOJI_ID.
                # Detect by context: preceded by MC value (ends K/M/B/digit) and
                # followed (after spaces) by $ or digit.
                before_stripped = plain_text[:i].rstrip()
                after_stripped  = rest.lstrip()
                if (before_stripped
                        and before_stripped[-1] in 'KMBkmbkm0123456789'
                        and after_stripped
                        and after_stripped[0] in '$0123456789'):
                    eid = TEER_EMOJI_ID
                    # NOTE: pos_index NOT advanced — teer slot is not counted against
                    # the positional list, keeping badge emoji alignment correct.
                elif non_badge_ids:
                    eid = non_badge_ids[min(pos_index, len(non_badge_ids) - 1)]
                    pos_index += 1

            if eid:
                custom_entities.append(MessageEntityCustomEmoji(
                    offset=utf16_off, length=emoji_u16,
                    document_id=int(eid)
                ))
            utf16_off += emoji_u16
            i += PH_LEN
            continue
        char_u16 = len(plain_text[i].encode('utf-16-le')) // 2
        utf16_off += char_u16
        i += 1
    return (base_entities or []) + custom_entities

async def _userbot_send_with_premium_emoji(chat, text, emoji_id=None, link_preview=False, forced_pack=None):
    """Send via userbot. Returns sent Message object on success, None on failure."""
    if not userbot_client:
        return None
    try:
        if emoji_id:
            try:
                from telethon.extensions.html import parse as tl_html_parse
                plain_text, base_entities = tl_html_parse(text)
                all_entities = _build_premium_entities(plain_text, base_entities, emoji_id, forced_pack=forced_pack)
                msg = await userbot_client.send_message(
                    chat, plain_text,
                    formatting_entities=all_entities,
                    link_preview=link_preview
                )
                return msg
            except Exception as e:
                logger.warning(f"Custom emoji send failed, fallback: {e}")
        msg = await userbot_client.send_message(chat, text, parse_mode="html", link_preview=link_preview)
        return msg
    except Exception as e:
        logger.error(f"userbot send: {e}")
        return None

async def _userbot_edit_with_premium_emoji(chat, msg_id, text, emoji_ids_for_ranking=None, forced_pack=None):
    """Edit message via userbot. If emoji_ids_for_ranking given, replaces number emojis."""
    if not userbot_client:
        return False
    try:
        if emoji_ids_for_ranking:
            try:
                from telethon.tl.types import MessageEntityCustomEmoji
                from telethon.extensions.html import parse as tl_html_parse
                plain_text, base_entities = tl_html_parse(text)
                default_nums = ["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟"]
                custom_entities = []
                for idx, eid in enumerate(emoji_ids_for_ranking[:10]):
                    if not eid: continue
                    target = default_nums[idx] if idx < len(default_nums) else f"{idx+1}."
                    utf16_off = 0; i = 0
                    while i < len(plain_text):
                        seg = plain_text[i:i+len(target)]
                        if seg == target:
                            eid_u16 = len(target.encode('utf-16-le')) // 2
                            custom_entities.append(MessageEntityCustomEmoji(
                                offset=utf16_off, length=eid_u16,
                                document_id=int(eid)
                            ))
                            break
                        char_u16 = len(plain_text[i].encode('utf-16-le')) // 2
                        utf16_off += char_u16; i += 1
                all_entities = (base_entities or []) + custom_entities
                await userbot_client.edit_message(chat, msg_id, plain_text,
                                                   formatting_entities=all_entities,
                                                   link_preview=False)
                return True
            except Exception as e:
                logger.warning(f"Premium emoji edit failed, fallback: {e}")
        if forced_pack:
            try:
                from telethon.extensions.html import parse as tl_html_parse
                plain_text, base_entities = tl_html_parse(text)
                all_entities = _build_premium_entities(plain_text, base_entities, [], forced_pack=forced_pack)
                await userbot_client.edit_message(chat, msg_id, plain_text,
                                                   formatting_entities=all_entities,
                                                   link_preview=False)
                return True
            except Exception as e:
                logger.warning(f"forced_pack edit failed, fallback: {e}")
        await userbot_client.edit_message(chat, msg_id, text, parse_mode="html", link_preview=False)
        return True
    except Exception as e:
        logger.error(f"userbot edit {msg_id}: {e}")
        return False

async def _userbot_edit_caption_with_premium_emoji(chat, msg_id, text, emoji_id, forced_pack=None):
    """Edit a media message's caption via userbot. emoji_id = single id or list (one per 🔮)."""
    if not userbot_client or not emoji_id:
        logger.warning(f"Skipping emoji edit: userbot={userbot_client is not None}, emoji_id={emoji_id}")
        return False
    try:
        from telethon.extensions.html import parse as tl_html_parse
        plain_text, base_entities = tl_html_parse(text)
        all_entities = _build_premium_entities(plain_text, base_entities, emoji_id, forced_pack=forced_pack)
        logger.info(f"Userbot editing msg {msg_id} with emoji_id={emoji_id}, entities={len(all_entities)}")
        await userbot_client.edit_message(
            chat, msg_id, plain_text,
            formatting_entities=all_entities,
            link_preview=False
        )
        logger.info(f"✅ Userbot emoji edit SUCCESS for msg {msg_id}")
        return True
    except Exception as e:
        logger.warning(f"Caption premium emoji edit FAILED: {e}")
        return False

async def _userbot_send_media_with_emoji(bot_app, chat, file_id, file_type, text, emoji_id, keyboard=None, forced_pack=None):
    """Download file via bot API, then send via userbot with premium emoji — NO edit = NO pencil mark."""
    import tempfile, os
    tmp_path = None
    try:
        tg_file = await bot_app.get_file(file_id)
        suffix = '.mp4' if file_type == 'video' else '.jpg'
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as f:
            tmp_path = f.name
        await tg_file.download_to_drive(tmp_path)

        from telethon.extensions.html import parse as tl_html_parse
        plain_text, base_ents = tl_html_parse(text)
        all_entities = _build_premium_entities(plain_text, base_ents, emoji_id, forced_pack=forced_pack)

        # Convert PTB InlineKeyboardMarkup → Telethon buttons
        tl_buttons = None
        if keyboard:
            try:
                from telethon.tl.types import ReplyInlineMarkup, KeyboardButtonRow, KeyboardButtonUrl
                rows = []
                for row in keyboard.inline_keyboard:
                    btns = [KeyboardButtonUrl(text=b.text, url=b.url) for b in row if b.url]
                    if btns:
                        rows.append(KeyboardButtonRow(buttons=btns))
                if rows:
                    tl_buttons = ReplyInlineMarkup(rows=rows)
            except Exception:
                pass

        msg = await userbot_client.send_file(
            chat, tmp_path,
            caption=plain_text,
            formatting_entities=all_entities,
            buttons=tl_buttons,
            supports_streaming=True
        )
        logger.info(f"✅ Userbot media send SUCCESS (no pencil) file_type={file_type}")
        return msg
    except Exception as e:
        logger.error(f"Userbot media send failed: {e}")
        return None
    finally:
        if tmp_path and os.path.exists(tmp_path):
            try: os.unlink(tmp_path)
            except Exception: pass

def _get_chain_emoji(chain, config=None):
    """Return chain-specific premium emoji ID, or None."""
    if config is None:
        config = load_config()
    chain_emoji_ids = config.get("chain_emoji_ids", {})
    # Normalize chain key: SOL→sol, ETH→eth, BNB→bsc (user uses 'bsc'), BASE→base
    key_map = {"SOL": "sol", "ETH": "eth", "BNB": "bsc", "BSC": "bsc", "BASE": "base", "TON": "ton"}
    key = key_map.get(chain.upper(), chain.lower())
    return chain_emoji_ids.get(key)


def build_dropped_alert(channel, msg_id, ca, chain, entry_fmt, symbol):
    """Build the 'Dropped a Call' post text."""
    kol_link  = f"https://t.me/{channel}/{msg_id}" if msg_id else f"https://t.me/{channel}"
    dex_path  = CHAIN_TO_DEXPATH.get((chain or "").upper(), "ethereum")
    chart_url = f"https://dexscreener.com/{dex_path}/{ca}" if ca else "https://dexscreener.com"
    mae_link  = f"{MAESTRO_REFLINK_BASE}{ca}{MAESTRO_REF_SUFFIX}" if ca else f"{MAESTRO_REFLINK_BASE}r-wizard_scan"
    config    = load_config()
    template  = config.get("dropped_call_template") or DEFAULT_DROPPED_TEMPLATE
    kwargs    = dict(
        channel=html.escape(channel), symbol=(symbol or "TOKEN").upper(),
        chain=chain, entry=entry_fmt, ca=ca,
        kol_link=kol_link, bot_link=BOT_LINK,
        chart_url=chart_url, mae_link=mae_link,
    )
    try:
        return safe_format(template, **kwargs)
    except Exception:
        return safe_format(DEFAULT_DROPPED_TEMPLATE, **kwargs)


async def send_dropped_alert(bot, channel, msg_id, ca, chain, entry_fmt, symbol):
    """Post a 'Dropped a Call' alert to the main channel when a new call is first tracked.
    ALWAYS uses the WHITE emoji pack regardless of the active/locked pack setting.

    Flow: Bot sends (always reliable) → Userbot edits caption with premium emojis.
    No file download/re-upload — avoids silent fallback-to-no-emojis bug.
    """
    try:
        text = build_dropped_alert(channel, msg_id, ca, chain, entry_fmt, symbol)
        # Use chain-specific emoji for the two header 🔮 in dropped-call post
        _chain_key = (chain or "").upper()
        # FIX: EVM unknown chain defaults to ETH emoji, not SOL
        if _chain_key == "EVM":
            _drop_em = DROPPED_CHAIN_EMOJIS.get("ETH", DROPPED_CALL_EMOJI)
        else:
            _drop_em = DROPPED_CHAIN_EMOJIS.get(_chain_key, DROPPED_CALL_EMOJI)
        emoji_ids  = [_drop_em, _drop_em]

        # Rotating video (up to 20 — round robin)
        config = load_config()
        vids   = config.get("dropped_videos", [])
        media  = None
        if vids:
            idx   = config.get("dropped_video_index", 0) % len(vids)
            media = vids[idx]
            cfg_set("dropped_video_index", (idx + 1) % len(vids))

        posted   = False
        sent_id  = None

        # ── Step 1: Userbot sends directly (NO edit = NO pencil mark ✏️) ──────────
        if media and media.get("file_id"):
            fid, ftype = media["file_id"], media.get("type", "video")
            if userbot_client:
                try:
                    sm = await _userbot_send_media_with_emoji(
                        bot, TARGET_CHANNEL, fid, ftype, text, emoji_ids,
                        forced_pack=_DROPPED_CALL_PACK)
                    if sm:
                        posted = True
                        logger.info(f"Dropped alert media sent by userbot (no pencil): msg_id={sm.id}")
                except Exception as e:
                    logger.error(f"Userbot media send failed, trying bot fallback: {e}")

            # Fallback: bot sends (no premium emojis, no edit to avoid pencil)
            if not posted:
                try:
                    if ftype == "photo":
                        sm = await bot.send_photo(TARGET_CHANNEL, photo=fid,
                                                  caption=text, parse_mode="HTML")
                    else:
                        sm = await bot.send_video(TARGET_CHANNEL, video=fid,
                                                  caption=text, parse_mode="HTML")
                    posted  = True
                    sent_id = sm.message_id
                    logger.info(f"Dropped alert media sent by bot (fallback): msg_id={sent_id}")
                except Exception as e:
                    logger.error(f"Dropped alert media send failed: {e}")

        if not posted:
            # Text-only: userbot sends with emojis in one shot (no edit = no pencil)
            if userbot_client:
                sm = await _userbot_send_with_premium_emoji(
                    TARGET_CHANNEL, text, emoji_id=emoji_ids, forced_pack=_DROPPED_CALL_PACK)
                if sm:
                    posted = True
                    logger.info("Dropped alert text sent by userbot with premium emojis")
            if not posted:
                try:
                    sm = await bot.send_message(TARGET_CHANNEL, text,
                                                parse_mode="HTML", disable_web_page_preview=True)
                    posted  = True
                    sent_id = sm.message_id
                except Exception as e:
                    logger.error(f"Dropped alert text send failed: {e}")

        # ── Step 2: Edit only if bot-fallback sent (sent_id set) — pencil acceptable here ──
        if posted and sent_id and userbot_client and emoji_ids:
            await asyncio.sleep(0.4)
            if media and media.get("file_id"):
                ok = await _userbot_edit_caption_with_premium_emoji(
                    TARGET_CHANNEL, sent_id, text, emoji_ids,
                    forced_pack=_DROPPED_CALL_PACK)
            else:
                ok = await _userbot_edit_with_premium_emoji(
                    TARGET_CHANNEL, sent_id, text,
                    forced_pack=_DROPPED_CALL_PACK)
            if not ok:
                logger.warning(f"Dropped alert premium emoji edit failed for msg {sent_id}")

    except Exception as e:
        logger.error(f"send_dropped_alert crash: {e}")


async def send_alert(bot, channel, msg_id, x_val, chain, entry_fmt, current_fmt, ca, symbol):
    config   = load_config()
    # Only send alert if a video/photo is set for this specific X value (or global)
    media    = config.get("milestone_media",{}).get(str(x_val)) or config.get("milestone_media",{}).get("global")
    if not media:
        logger.info(f"⏭ Skip alert {x_val}x @{channel} — no media set for this X value")
        return
    # Compute badge once, pass to build_alert + emoji list
    badge    = _get_kol_badge(channel)
    text     = build_alert(channel, msg_id, x_val, chain, entry_fmt, current_fmt, ca, symbol, badge=badge)
    keyboard = build_milestone_keyboard(x_val)
    # Pack-based premium emojis (rotate every 10 posts, 5 packs total)
    pack     = _get_alert_pack()
    emoji_id = list(_get_alert_emoji_ids(x_val, chain, pack))
    # Append badge premium emoji IDs
    if badge:
        if badge["type"] == "leaderboard":
            rank_emoji_id = LEADERBOARD_PREMIUM_EMOJIS.get(badge["rank"], LEADERBOARD_PREMIUM_EMOJIS[1])
            emoji_id += [LEADERBOARD_PREMIUM_EMOJIS["star"], rank_emoji_id]
        else:
            rank_emoji_id = CHAMPIONS_PREMIUM_EMOJIS.get(badge["rank"], CHAMPIONS_PREMIUM_EMOJIS[1])
            emoji_id += [CHAMPIONS_PREMIUM_EMOJIS["star"], rank_emoji_id]
    logger.info(f"Alert emoji_id for {x_val}x chain={chain} pack={pack['name']}: {emoji_id} | userbot={userbot_client is not None}")

    # ── Send to main channel ─────────────────────────────────────────────────────
    # PATTERN: Single send — NO edit after posting.
    # Edit = Telegram shows pencil "edited" mark, which we do NOT want on alerts.
    # Priority:
    #   1. Userbot sends media directly with premium emojis (no edit, no pencil)
    #   2. Bot sends media without emojis  (no edit, no pencil)
    #   3. Userbot sends text with emojis  (no edit, no pencil)
    #   4. Bot sends text only             (no edit, no pencil)
    posted         = False
    wizard_post_id = None
    call_key       = f"{channel}_{ca}" if ca else None

    if media and media.get("file_id"):
        fid, ftype = media["file_id"], media.get("type", "photo")

        # Option 1: Userbot sends media + premium emojis in one shot (no edit needed)
        if userbot_client and emoji_id:
            sent_msg = await _userbot_send_media_with_emoji(
                bot, TARGET_CHANNEL, fid, ftype, text, emoji_id,
                keyboard=keyboard)
            if sent_msg:
                posted = True
                try: wizard_post_id = sent_msg.id
                except Exception: pass
                logger.info(f"✅ Alert {x_val}x sent by userbot (no pencil): msg_id={wizard_post_id}")

        # Option 2: Bot sends media without emojis (userbot unavailable or failed)
        if not posted:
            try:
                if ftype == "photo":
                    sent_msg = await bot.send_photo(
                        TARGET_CHANNEL, photo=fid, caption=text,
                        parse_mode="HTML", reply_markup=keyboard)
                else:
                    sent_msg = await bot.send_video(
                        TARGET_CHANNEL, video=fid, caption=text,
                        parse_mode="HTML", reply_markup=keyboard)
                posted         = True
                wizard_post_id = sent_msg.message_id
                logger.info(f"Alert {x_val}x media sent by bot (no emojis): msg_id={wizard_post_id}")
            except Exception as e:
                logger.error(f"Media alert send failed: {e}")

    if not posted:
        # Option 3: Text-only — userbot sends with premium emojis (single send, no edit)
        if userbot_client and emoji_id:
            sent_msg = await _userbot_send_with_premium_emoji(
                TARGET_CHANNEL, text, emoji_id=emoji_id)
            if sent_msg:
                posted = True
                try: wizard_post_id = sent_msg.id
                except Exception: pass
                logger.info(f"Alert {x_val}x text sent by userbot with premium emojis")

        # Option 4: Bot sends text (final fallback, no edit)
        if not posted:
            try:
                sent_msg = await bot.send_message(
                    chat_id=TARGET_CHANNEL, text=text,
                    parse_mode="HTML", disable_web_page_preview=True,
                    reply_markup=keyboard)
                posted = True
                try: wizard_post_id = sent_msg.message_id
                except Exception: pass
                logger.info(f"Alert {x_val}x text sent by bot (text fallback)")
            except Exception as e:
                logger.error(f"Text alert to channel failed: {e}")

    # Save WizardScan post ID for this milestone
    if wizard_post_id and call_key:
        if call_key not in milestone_posts:
            milestone_posts[call_key] = {}
        milestone_posts[call_key][str(x_val)] = wizard_post_id
        _save_milestone_posts()

    # Award points to channel for this milestone (champion kols points system)
    if call_key:
        awarded = await award_points_for_milestone(channel, call_key, x_val)
        if awarded > 0:
            logger.info(f"⭐ Points awarded: +{awarded} to @{channel} for {x_val}X milestone")

    # Track post count
    count = _inc_channel_post_count()
    # Hashtag every 100 alerts
    if count % 100 == 0:
        asyncio.create_task(_post_hashtag_to_channel(bot))
    # Promo post every 25 alerts (if enabled)
    if count % 25 == 0:
        promo_cfg = load_config()
        if promo_cfg.get("promo_enabled"):
            asyncio.create_task(_post_promo_to_channel(bot))

    # Resolve KOL owner ONCE here — used to deduplicate DM below
    kol_owners = load_kol_owners()
    owner_id   = kol_owners.get(channel.lower())

    # Forward WizardScan post to linked channel + DM KOL owner (preserves premium emojis)
    if wizard_post_id:
        for kol_ch, linked_ch in load_linked_channels().items():
            if kol_ch.lower() == channel.lower():
                try:
                    await bot.forward_message(
                        chat_id=linked_ch,
                        from_chat_id=TARGET_CHANNEL,
                        message_id=wizard_post_id)
                    logger.info(f"✅ Forwarded {x_val}X alert to linked channel {linked_ch}")
                except Exception as e:
                    logger.warning(f"Forward to linked ch {linked_ch} failed: {e}")
                    try: await _text_alert(bot, linked_ch, text, keyboard)
                    except Exception: pass
        # DM KOL owner — exactly ONCE (deduped from subscriber loops below)
        if owner_id:
            try:
                await bot.forward_message(
                    chat_id=owner_id,
                    from_chat_id=TARGET_CHANNEL,
                    message_id=wizard_post_id)
                logger.info(f"✅ DM sent to KOL owner {owner_id} for @{channel} {x_val}X")
            except Exception as e:
                logger.warning(f"Forward DM to KOL owner {owner_id} failed: {e}")
    else:
        # Fallback if wizard_post_id missing: text alert to linked channels only
        for kol_ch, linked_ch in load_linked_channels().items():
            if kol_ch.lower() == channel.lower():
                try: await _text_alert(bot, linked_ch, text, keyboard)
                except Exception as e: logger.warning(f"Text alert to linked ch failed ({linked_ch}): {e}")

    # DM channel-specific subscribers — skip KOL owner (already DM'd above) to prevent duplicates
    ch_subs = load_channel_subs().get(channel.lower(), [])
    for uid in ch_subs:
        if uid == owner_id:
            continue  # already received DM above — do not send twice
        try:
            if wizard_post_id:
                try:
                    await bot.forward_message(
                        chat_id=uid,
                        from_chat_id=TARGET_CHANNEL,
                        message_id=wizard_post_id)
                    continue
                except Exception:
                    pass
            # Fallback if forward fails
            await bot.send_message(uid, text, parse_mode="HTML", disable_web_page_preview=True)
        except Exception as e:
            logger.warning(f"DM subscriber {uid} failed: {e}")

    # Legacy global subscribers — skip KOL owner (already DM'd above) to prevent duplicates
    for uid in load_subscriptions():
        if uid == owner_id:
            continue  # already received DM above — do not send twice
        try:
            if wizard_post_id:
                try:
                    await bot.forward_message(
                        chat_id=uid,
                        from_chat_id=TARGET_CHANNEL,
                        message_id=wizard_post_id)
                    continue
                except Exception:
                    pass
            await bot.send_message(uid, text, parse_mode="HTML", disable_web_page_preview=True)
        except Exception: pass

async def _text_alert(bot, chat_id, text, keyboard):
    try:
        await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML",
                               disable_web_page_preview=True, reply_markup=keyboard)
    except Exception as e: logger.error(f"Text alert ({chat_id}): {e}")

# ─── History helpers ──────────────────────────────────────────────────────────
def get_call_history(channel, chain_filter=None, top=False):
    calls = []
    cutoff = datetime.utcnow() - timedelta(days=90)
    for call_key, call in tracked_calls.items():
        if call.get("channel","").lower() != channel.lower(): continue
        if chain_filter and call.get("chain","").upper() != chain_filter.upper(): continue
        if not top:
            ts = call.get("tracked_since","")
            if ts:
                try:
                    if datetime.fromisoformat(ts) < cutoff: continue
                except Exception: pass
        milestones = list(sent_milestones.get(call_key, set()))
        highest_x  = max(milestones) if milestones else 0
        entry_mc   = call.get("entry_mc", 0)
        # Use live ratio for decimal display; floor at highest milestone so crashes don't hide peaks
        last_ratio  = call.get("last_ratio", 0.0)
        # Safety cap: never display a ratio higher than MAX_MILESTONE × 2 to prevent phantom billions
        last_ratio  = min(last_ratio, MAX_MILESTONE * 2)
        # For display: only trust last_ratio if it's close to the confirmed milestone.
        # Phantom ratios from DexScreener glitches (e.g. 105K MC token showing billions)
        # must not inflate the displayed X or MC.
        if highest_x > 0 and last_ratio > highest_x * 3:
            current_x = float(highest_x)   # use confirmed milestone, ignore phantom ratio
        else:
            current_x = round(max(last_ratio, float(highest_x) if highest_x > 0 else 1.0), 2)
        if current_x < 1.0: current_x = 1.0
        # Cap display MC: if entry_mc × ratio produces an absurd number, use confirmed milestone MC
        current_mc  = entry_mc * current_x if entry_mc > 0 else entry_mc
        if current_mc > 1_000_000_000 and highest_x > 0:  # cap at $1B (tightened from $10B)
            current_mc = entry_mc * highest_x  # use confirmed milestone MC, not inflated ratio
        calls.append({
            "symbol":         call.get("symbol","TOKEN") or "TOKEN",
            "chain":          call.get("chain",""),
            "ca":             call.get("ca",""),
            "msg_id":         call.get("msg_id", 0),
            "entry_mc":       entry_mc,
            "entry_fmt":      call.get("entry_fmt","N/A"),
            "highest_x":      highest_x,       # integer milestone — used for sorting
            "current_x":      current_x,       # real decimal X — used for display
            "highest_mc_fmt": fmt_mc(current_mc) if current_mc > 0 else call.get("entry_fmt","N/A"),
            "tracked_since":  call.get("tracked_since",""),
        })
    if top:
        calls.sort(key=lambda x: x["highest_x"], reverse=True)
        return calls[:50]
    calls.sort(key=lambda x: x.get("tracked_since",""), reverse=True)
    return calls

def format_history(channel, calls, is_top=False):
    ch_safe = html.escape(channel)
    if not calls:
        return (
            f"<b>{PE_CRYSTAL} Calls History Of @{ch_safe}</b>\n\n"
            "<i>No calls found for this filter.</i>"
        )
    label = "Top 30 Calls" if is_top else "Calls History"
    lines = [f"<b>{PE_CRYSTAL} {label} Of @{ch_safe}</b>\n"]
    shown = 0
    for call in calls[:30]:
        sym    = html.escape((call["symbol"] or "TOKEN").upper())
        chain  = html.escape(call["chain"])
        ca     = call["ca"]
        ef     = html.escape(call["entry_fmt"])
        hf     = html.escape(call["highest_mc_fmt"])
        cx     = call.get("current_x", call["highest_x"])
        msg_id = call.get("msg_id", 0)
        # Build post link (t.me/{channel}/{msg_id}) or chart fallback
        if msg_id:
            post_link = f'<a href="https://t.me/{channel}/{msg_id}">{PE_WAND} View Post</a>'
        else:
            path = CHAIN_TO_DEXPATH.get(call["chain"], "ethereum")
            post_link = f'<a href="https://dexscreener.com/{path}/{ca}">📊 Chart</a>'
        # KOL TG override link (from addmissedcall)
        kol_tg = call.get("kol_tg_link", "")
        if kol_tg:
            post_link = f'<a href="{kol_tg}">{PE_WAND} View Post</a>'
        # X string — real decimal (e.g. 2.7x, 15.3x)
        x_label = f" {fmt_x(cx)}"
        # X/Twitter handle for this channel
        x_handle = _get_channel_x_handle(channel)
        x_link = f'  <a href="https://x.com/{html.escape(x_handle)}">𝕏</a>' if x_handle else ""
        lines.append(
            f'\n{PE_CRYSTAL} <b>${sym} ({chain}){x_label}</b>{x_link}\n'
            f'     {post_link}  |  {ef} to {hf}'
        )
        shown += 1
    if len(calls) > 30:
        lines.append(f"\n\n<i>Showing 30 of {len(calls)} calls.</i>")
    # Show channel points at the end
    ch_pts = get_channel_points(channel)
    lines.append(f"\n\n<i>This channel has {ch_pts}/{POINTS_FOR_CHAMPION} points</i>")
    return "\n".join(lines)


def _build_html_caption_for_video(channel, calls, limit=1024):
    """Build valid HTML caption matching format_history style, fitting within 1024-char limit."""
    ch_safe = html.escape(channel)
    header  = f"<b>{PE_CRYSTAL} Calls History Of @{ch_safe}</b>\n"
    body    = ""
    for call in calls[:30]:
        sym    = html.escape((call["symbol"] or "TOKEN").upper())
        chain  = html.escape(call["chain"])
        ca     = call["ca"]
        ef     = html.escape(call["entry_fmt"])
        hf     = html.escape(call["highest_mc_fmt"])
        cx     = call.get("current_x", call["highest_x"])
        msg_id = call.get("msg_id", 0)
        if msg_id:
            post_link = f'<a href="https://t.me/{channel}/{msg_id}">{PE_WAND} View Post</a>'
        else:
            path = CHAIN_TO_DEXPATH.get(call["chain"], "ethereum")
            post_link = f'<a href="https://dexscreener.com/{path}/{ca}">📊 Chart</a>'
        x_label = f" {fmt_x(cx)}"
        entry = (
            f'\n\n{PE_CRYSTAL} <b>${sym} ({chain}){x_label}</b>\n'
            f'     {post_link}  |  {ef} to {hf}'
        )
        if len(header) + len(body) + len(entry) > limit:
            break
        body += entry
    return header + body

# ─── Leaderboard / Champions / Trending generation ───────────────────────────
def _calc_leaderboard_scores():
    """Calculate top 10 leaderboard channels.
    Channels already in Champions list (>=100 points, top-10) are excluded
    so they don't appear in both lists.
    Returns list of (ch, best_x, wizard_post_id)."""
    channels = load_channels()
    pts_data = load_channel_points()

    # FIX: Build champion_set using the SAME sort key as build_champions_text()
    # i.e. sort by (best_x DESC, pts DESC) — not just pts.
    # Previously it sorted by pts only, so a KOL could land in champion_set
    # (excluded from leaderboard) but NOT appear in the champion post's top-10
    # (which uses best_x as primary sort). Result: KOL vanished from both lists.
    cfg_excl = load_config()
    _champ_snap_lb   = cfg_excl.get("champion_milestone_snapshot", {})
    _champ_excl_keys = set(cfg_excl.get("champion_excluded_call_keys", []))

    champ_candidates_bx = []
    for ch in channels:
        pts = pts_data.get(ch.lower(), {}).get("points", 0)
        if pts < POINTS_FOR_CHAMPION:
            continue
        # Compute best_x using same snapshot filter as build_champions_text
        ch_bx = 1
        for ck, call in tracked_calls.items():
            if call.get("channel", "").lower() != ch.lower(): continue
            if ck in _champ_snap_lb:
                ms = [m for m in sent_milestones.get(ck, set()) if m > _champ_snap_lb[ck]]
            elif ck in _champ_excl_keys:
                continue
            else:
                ms = list(sent_milestones.get(ck, set()))
            if ms:
                mx = max(ms)
                if mx > ch_bx: ch_bx = mx
        champ_candidates_bx.append((ch, pts, ch_bx))

    # Sort by (best_x desc, pts desc) — exact same key as build_champions_text()
    champ_candidates_bx.sort(key=lambda t: (t[2], t[1]), reverse=True)
    champion_set = {ch.lower() for ch, _, _ in champ_candidates_bx[:10]}

    cfg_now = load_config()
    # Primary exclusion: call_keys snapshot at reset time (most reliable)
    excluded_keys = set(cfg_now.get("lb_excluded_call_keys", []))
    # Secondary: date-based filter
    lb_reset_since = cfg_now.get("leaderboard_reset_since", "")
    lb_reset_dt = None
    if lb_reset_since:
        try: lb_reset_dt = datetime.fromisoformat(lb_reset_since)
        except Exception: lb_reset_dt = None

    # Snapshot-based reset: only milestones ABOVE what existed at reset time count.
    lb_snap = cfg_now.get("lb_milestone_snapshot", {})

    all_scores = {}
    for ch in channels:
        if ch.lower() in champion_set:
            continue   # already a Champion — skip from Leaderboard
        best_x = 1
        best_call_key = None
        for call_key, call in tracked_calls.items():
            if call.get("channel","").lower() != ch.lower(): continue

            if call_key in lb_snap:
                # Snapshot-based exclusion: only count milestones ABOVE snap value
                snap_max = lb_snap[call_key]
                ms = [m for m in sent_milestones.get(call_key, set()) if m > snap_max]
            elif call_key in excluded_keys:
                # Legacy blanket exclusion (pre-snapshot resets)
                continue
            else:
                # New call added after reset — count all milestones
                ms = list(sent_milestones.get(call_key, set()))
                # Secondary date filter for calls not in snapshot and not in excluded_keys
                if lb_reset_dt:
                    ts_str = call.get("tracked_since", "")
                    if not ts_str:
                        continue
                    try:
                        ts = datetime.fromisoformat(ts_str)
                        if ts < lb_reset_dt: continue
                    except Exception:
                        continue

            if ms:
                mx = max(ms)
                if mx > best_x:
                    best_x = mx
                    best_call_key = call_key
        wizard_post_id = None
        if best_call_key:
            posts = milestone_posts.get(best_call_key, {})
            wizard_post_id = posts.get(str(best_x))
            # Fallback: find closest available WizardScan post for this channel
            if wizard_post_id is None and posts:
                _valid = {str(k): v for k, v in posts.items() if v and str(k).lstrip('-').isdigit()}
                if _valid:
                    _nearest = sorted(_valid.items(), key=lambda kv: abs(int(kv[0]) - best_x))
                    wizard_post_id = _nearest[0][1]
        # Only include channels that have reached at least 2x milestone
        if best_x < 2:
            continue
        all_scores[ch] = (best_x, wizard_post_id)

    lb_scores = [(ch, x, wpost) for ch, (x, wpost) in all_scores.items()]
    lb_scores.sort(key=lambda t: t[1], reverse=True)
    return lb_scores[:10]

def _num_emoji(n):
    """Return unicode number emoji for rank 1-10."""
    _e = {1:"1️⃣",2:"2️⃣",3:"3️⃣",4:"4️⃣",5:"5️⃣",6:"6️⃣",7:"7️⃣",8:"8️⃣",9:"9️⃣",10:"🔟"}
    return _e.get(n, str(n))

def _get_kol_badge(channel):
    """Check if KOL is in champions (>=100 points, top10) or leaderboard (top10 by highest X).
    Returns dict {type, rank, entry, peak} or None."""
    try:
        # Check champions first — based on points system
        # Sort by (best_x, pts) to match build_champions_text() display order exactly
        pts_data = load_channel_points()
        channels = load_channels()
        # FIX: Apply same champion reset snapshot filter as build_champions_text()
        # so badge rank matches actual champion post rank exactly
        _badge_cfg = load_config()
        _champ_snap = _badge_cfg.get("champion_milestone_snapshot", {})
        _champ_excl = set(_badge_cfg.get("champion_excluded_call_keys", []))
        champ_list_with_x = []
        for ch in channels:
            pts = pts_data.get(ch.lower(), {}).get("points", 0)
            if pts >= POINTS_FOR_CHAMPION:
                ch_best_x = 1
                for ck, call in tracked_calls.items():
                    if call.get("channel","").lower() != ch.lower(): continue
                    # Apply same reset filter as build_champions_text
                    if ck in _champ_snap:
                        snap_max = _champ_snap[ck]
                        ms = [m for m in sent_milestones.get(ck, set()) if m > snap_max]
                    elif ck in _champ_excl:
                        continue  # legacy blanket exclusion
                    else:
                        ms = list(sent_milestones.get(ck, set()))
                    if ms:
                        mx = max(ms)
                        if mx > ch_best_x: ch_best_x = mx
                champ_list_with_x.append((ch, pts, ch_best_x))
        # Sort by (best_x desc, pts desc) — same order as build_champions_text
        champ_list_with_x.sort(key=lambda t: (t[2], t[1]), reverse=True)
        for i, (ch, pts, ch_bx) in enumerate(champ_list_with_x[:10]):
            if ch.lower() == channel.lower():
                bx = ch_bx; bck = None
                for ck, call in tracked_calls.items():
                    if call.get("channel","").lower() != ch.lower(): continue
                    ms = list(sent_milestones.get(ck, set()))
                    if ms and max(ms) == bx:
                        bck = ck; break
                if bck is None:
                    for ck, call in tracked_calls.items():
                        if call.get("channel","").lower() != ch.lower(): continue
                        ms = list(sent_milestones.get(ck, set()))
                        if ms and max(ms) >= bx:
                            bck = ck
                call_d = tracked_calls.get(bck, {}) if bck else {}
                em = call_d.get("entry_mc", 0)
                ef = call_d.get("entry_fmt", "N/A")
                pf = fmt_mc(em * bx) if em > 0 else f"{bx}X"
                return {"type": "champions", "rank": i+1, "entry": ef, "peak": pf}
        # Check leaderboard (top 10 by highest X)
        top10 = _calc_leaderboard_scores()
        for i, (ch, bx, wpost) in enumerate(top10):
            if ch.lower() == channel.lower():
                bck2 = None; bx2 = 1
                for ck, call in tracked_calls.items():
                    if call.get("channel","").lower() != ch.lower(): continue
                    ms = list(sent_milestones.get(ck, set()))
                    if ms:
                        mx = max(ms)
                        if mx > bx2: bx2 = mx; bck2 = ck
                call_d = tracked_calls.get(bck2, {}) if bck2 else {}
                em = call_d.get("entry_mc", 0); ef = call_d.get("entry_fmt", "N/A")
                pf = fmt_mc(em * bx2) if em > 0 else f"{bx2}X"
                return {"type": "leaderboard", "rank": i+1, "entry": ef, "peak": pf}
    except Exception as e:
        logger.warning(f"_get_kol_badge error: {e}")
    return None

def build_leaderboard_text():
    """Build top 10 leaderboard with 🔮 placeholders for premium emojis.
    Order: star(header), then per row: num+arrow, then star(footer)."""
    top10 = _calc_leaderboard_scores()

    # User-set custom template support
    tmpl = cfg_get("leaderboard_template","")
    if tmpl:
        kwargs = {}
        for i in range(10):
            idx = i + 1
            if i < len(top10):
                ch, x, wpost = top10[i]
                kwargs[f"rank{idx}_link"]    = f"@{html.escape(ch)}"
                kwargs[f"rank{idx}_channel"] = f"@{html.escape(ch)}"
                kwargs[f"rank{idx}_x"]       = fmt_x(x)
            else:
                kwargs[f"rank{idx}_link"]    = "—"
                kwargs[f"rank{idx}_channel"] = "—"
                kwargs[f"rank{idx}_x"]       = "—"
        return safe_format(tmpl, **kwargs)

    # Default: 🔮 placeholders — star header, (num + arrow) per row, star footer
    lines = []
    for i, (ch, x, wpost) in enumerate(top10):
        x_str  = fmt_x(x)
        # Link X value to the WizardScan post when available
        x_part = (f'<a href="https://t.me/WizardScan/{wpost}">{x_str}</a>'
                  if wpost else x_str)
        x_handle = _get_channel_x_handle(ch)
        x_link = f'  <a href="https://x.com/{html.escape(x_handle)}">𝕏</a>' if x_handle else ""
        lines.append(f"🔮 <b>@{html.escape(ch)}</b> 🔮 {x_part}{x_link}")

    if not lines:
        return ("🔮 <b>LEADERBOARD KOLS:</b>\n\n"
                "<i>No data yet. Tracking in progress...</i>\n\n"
                "🔮 <b>New List in 3 Days</b>")

    # Pad to 10 slots with dashes for empty ranks
    for i in range(len(lines), 10):
        lines.append(f"🔮 <b>—</b> 🔮 —")

    return ("🔮 <b>LEADERBOARD KOLS:</b>\n\n"
            + "\n".join(lines)
            + "\n\n🔮 <b>New List in 3 Days</b>")

def build_champions_text():
    """Build champion kols list for post 137.
    Only channels with >= POINTS_FOR_CHAMPION (100) points qualify.
    Sorted by points descending. Uses 🔮 placeholders for premium emojis."""
    channels = load_channels()
    pts_data = load_channel_points()

    # Exclude milestones that existed before the last champion reset
    cfg_now      = load_config()
    excluded_keys = set(cfg_now.get("champion_excluded_call_keys", []))  # legacy blanket list
    champ_snap    = cfg_now.get("champion_milestone_snapshot", {})       # snapshot-based (preferred)

    champions = []
    for ch in channels:
        pts = pts_data.get(ch.lower(), {}).get("points", 0)
        if pts >= POINTS_FOR_CHAMPION:
            # Find best milestone AFTER reset
            best_x = 1
            best_call_key = None
            for call_key, call in tracked_calls.items():
                if call.get("channel","").lower() != ch.lower(): continue

                if call_key in champ_snap:
                    # Snapshot-based: only count milestones ABOVE snap value (new records after reset)
                    snap_max = champ_snap[call_key]
                    ms = [m for m in sent_milestones.get(call_key, set()) if m > snap_max]
                elif call_key in excluded_keys:
                    continue  # legacy blanket exclusion
                else:
                    ms = list(sent_milestones.get(call_key, set()))

                if ms:
                    mx = max(ms)
                    if mx > best_x:
                        best_x = mx
                        best_call_key = call_key
            wizard_post_id = None
            if best_call_key:
                posts = milestone_posts.get(best_call_key, {})
                wizard_post_id = posts.get(str(best_x))
                # Fallback: find closest available WizardScan post for this channel
                if wizard_post_id is None and posts:
                    _valid = {str(k): v for k, v in posts.items() if v and str(k).lstrip('-').isdigit()}
                    if _valid:
                        _nearest = sorted(_valid.items(), key=lambda kv: abs(int(kv[0]) - best_x))
                        wizard_post_id = _nearest[0][1]
            champions.append((ch, pts, best_x, wizard_post_id))
    # Sort by best_x descending, then by points as tiebreaker
    champions.sort(key=lambda x: (x[2], x[1]), reverse=True)

    lines = []
    for i, (ch, pts, best_x, wpost) in enumerate(champions[:10]):
        x_str  = fmt_x(best_x)
        x_part = (f'<a href="https://t.me/WizardScan/{wpost}">{x_str}</a>'
                  if wpost else x_str)
        x_handle = _get_channel_x_handle(ch)
        x_link = f'  <a href="https://x.com/{html.escape(x_handle)}">𝕏</a>' if x_handle else ""
        lines.append(f"🔮 <b>@{html.escape(ch)}</b> 🔮 {x_part}{x_link}")

    # Pad to 10 slots with dashes for empty ranks
    for i in range(len(lines), 10):
        lines.append(f"🔮 <b>—</b> 🔮 —")

    footer = ("\n\n🔮 KOLs need 100 points to appear here.")

    if not lines:
        return ("🔮 <b>CHAMPION KOLS</b>\n\n"
                "<i>No channels have reached 100 points yet.</i>"
                + footer)

    return "🔮 <b>CHAMPION KOLS</b>\n\n" + "\n".join(lines) + footer

def build_trending_text_and_emojis(chain_tokens):
    """Build trending post text with 🔮 placeholders + ordered emoji_ids list.
    Returns (text, emoji_ids). Each 🔮 in text maps to next emoji in list."""
    parts      = []
    emoji_ids  = []
    num_ctr    = 1  # global counter for numbered tokens (1-20)

    for chain in ["SOL", "ETH", "BNB", "BASE"]:
        chain_label = {"ETH":"ETH","BNB":"BSC","SOL":"SOL","BASE":"BASE"}[chain]
        parts.append(f"<b>🔮 {chain_label} TRENDING</b>")
        emoji_ids.append(TRENDING_PREMIUM_EMOJIS.get(chain, TRENDING_PREMIUM_EMOJIS["SOL"]))
        parts.append("")
        tokens = chain_tokens.get(chain, [])
        if tokens:
            for t in tokens:
                sym     = html.escape(t.get("symbol","TOKEN"))
                mc_raw  = html.escape(t.get("mc_fmt","N/A"))
                tg_url  = html.escape(t.get("tg_url",""), quote=True)
                dex_url = html.escape(t.get("dex_url",""), quote=True)
                sym_part = f'<b><a href="{dex_url}">{sym}</a></b>' if dex_url else f"<b>{sym}</b>"
                # MC becomes a TG link if token has a Telegram; otherwise plain text
                mc_part = f'<a href="{tg_url}">{mc_raw}</a>' if tg_url else mc_raw
                # Row: 🔮(number) SYM 🔮(arrow) MC
                parts.append(f"🔮 {sym_part} 🔮 {mc_part}")
                emoji_ids.append(TRENDING_PREMIUM_EMOJIS.get(num_ctr, TRENDING_PREMIUM_EMOJIS[20]))
                emoji_ids.append(TRENDING_PREMIUM_EMOJIS["arrow"])
                num_ctr += 1
        else:
            parts.append("<i>No data available</i>")
        parts.append("")

    return "\n".join(parts), emoji_ids

def build_trending_text(chain_tokens):
    """Build trending tokens post text for post 135 (returns text only)."""
    text, _ = build_trending_text_and_emojis(chain_tokens)
    return text

# ─── New Trending Posts (3560 and 3562) ──────────────────────────────────────
def _fetch_trending2_sync():
    """Fetch trending tokens for the two new posts.
    Post 3560: SOL (1-5) + ETH (6-10) + BSC (11-15)
    Post 3562: Robinhood (16-20) + BASE (21-25) + TON (26-30)
    Returns dict: {chain: [tokens...]}
    """
    blacklist = load_trending_blacklist()
    chain_tokens = {"SOL": [], "ETH": [], "BSC": [], "RH": [], "BASE": [], "TON": []}

    # SOL — DexScreener boosts
    try:
        resp = requests.get("https://api.dexscreener.com/token-boosts/top/v1", timeout=20, headers=HEADERS)
        if resp.status_code == 200:
            raw = resp.json()
            if isinstance(raw, list):
                sol_candidates = []
                seen = set()
                for token in raw:
                    if token.get("chainId","").lower() != "solana": continue
                    ca = token.get("tokenAddress","")
                    if not ca or ca in seen or ca.lower() in blacklist: continue
                    seen.add(ca)
                    tg = _extract_tg_link(token.get("links") or [])
                    sol_candidates.append((ca, tg))
                sol_results = []
                for batch_start in range(0, min(len(sol_candidates), 60), 10):
                    batch = sol_candidates[batch_start: batch_start + 10]
                    cas   = [ca for ca, _ in batch]
                    tg_map = {ca: tg for ca, tg in batch}
                    try:
                        r = requests.get(
                            f"https://api.dexscreener.com/latest/dex/tokens/{','.join(cas)}",
                            timeout=15, headers=HEADERS)
                        if r.status_code != 200: continue
                        pairs_data = r.json().get("pairs") or []
                    except Exception: continue
                    best_per_ca = {}
                    for pair in pairs_data:
                        ca_key = pair.get("baseToken",{}).get("address","")
                        if ca_key not in best_per_ca:
                            best_per_ca[ca_key] = pair
                        else:
                            liq_new = pair.get("liquidity",{}).get("usd",0) or 0
                            liq_old = best_per_ca[ca_key].get("liquidity",{}).get("usd",0) or 0
                            if liq_new > liq_old:
                                best_per_ca[ca_key] = pair
                    for ca in cas:
                        pair = best_per_ca.get(ca)
                        if not pair: continue
                        mc = float(pair.get("marketCap") or pair.get("fdv") or 0)
                        if mc <= 0: continue
                        tg = tg_map.get(ca,"")
                        if not tg:
                            info = pair.get("info") or {}
                            for s in (info.get("socials") or []):
                                u = s.get("url",""); t = s.get("type","").lower()
                                if "t.me" in u or "telegram" in t: tg = u; break
                        sol_results.append({
                            "symbol":  pair.get("baseToken",{}).get("symbol","TOKEN"),
                            "mc_fmt":  fmt_mc(mc),
                            "tg_url":  tg,
                            "dex_url": f"https://dexscreener.com/solana/{ca}",
                            "has_tg":  bool(tg),
                        })
                    time.sleep(0.2)
                sol_results.sort(key=lambda x: (0 if x["has_tg"] else 1))
                chain_tokens["SOL"] = sol_results[:5]
    except Exception as e:
        logger.warning(f"T2 SOL trending fetch failed: {e}")

    # ETH, BSC, BASE, RH via GeckoTerminal
    gecko_map2 = [("eth", "ETH"), ("bsc", "BSC"), ("base", "BASE"), ("robinhood", "RH")]
    for gecko_net, chain_key in gecko_map2:
        try:
            chain_tokens[chain_key] = _fetch_gecko_chain(gecko_net, chain_key, blacklist)
        except Exception as e:
            logger.warning(f"T2 GeckoTerminal {gecko_net} failed: {e}")
        time.sleep(0.3)

    # TON — try DexScreener first, then GeckoTerminal as fallback
    try:
        ton_results = []
        seen_t = set()

        # --- DexScreener TON trending (token-boosts endpoint) ---
        try:
            resp_ton = requests.get("https://api.dexscreener.com/token-boosts/top/v1", timeout=15, headers=HEADERS)
            if resp_ton.status_code == 200:
                raw_ton = resp_ton.json()
                if isinstance(raw_ton, list):
                    ton_candidates = []
                    for token in raw_ton:
                        if token.get("chainId","").lower() not in ("ton", "the-open-network"): continue
                        ca = token.get("tokenAddress","")
                        if not ca or ca in seen_t or ca.lower() in blacklist: continue
                        seen_t.add(ca)
                        tg = _extract_tg_link(token.get("links") or [])
                        ton_candidates.append((ca, tg))
                    for batch_start in range(0, min(len(ton_candidates), 30), 10):
                        batch = ton_candidates[batch_start: batch_start + 10]
                        cas   = [ca for ca, _ in batch]
                        tg_map = {ca: tg for ca, tg in batch}
                        try:
                            r2 = requests.get(
                                f"https://api.dexscreener.com/latest/dex/tokens/{','.join(cas)}",
                                timeout=12, headers=HEADERS)
                            if r2.status_code != 200: continue
                            for pair in (r2.json().get("pairs") or []):
                                if pair.get("chainId","").lower() not in ("ton","the-open-network"): continue
                                ca_key = pair.get("baseToken",{}).get("address","")
                                if not ca_key or ca_key in seen_t: continue
                                mc = float(pair.get("marketCap") or pair.get("fdv") or 0)
                                if mc <= 0: continue
                                seen_t.add(ca_key)
                                sym = pair.get("baseToken",{}).get("symbol","TOKEN")
                                tg  = tg_map.get(ca_key,"")
                                if not tg:
                                    for s in ((pair.get("info") or {}).get("socials") or []):
                                        if "t.me" in s.get("url","") or "telegram" in s.get("type","").lower():
                                            tg = s["url"]; break
                                dex = f"https://dexscreener.com/ton/{ca_key}"
                                ton_results.append({"symbol": sym, "mc_fmt": fmt_mc(mc),
                                                    "tg_url": tg, "dex_url": dex, "has_tg": bool(tg)})
                        except Exception: pass
                        if len(ton_results) >= 10: break
        except Exception as e_dex_ton:
            logger.debug(f"DexScreener TON trending skipped: {e_dex_ton}")

        # --- GeckoTerminal TON fallback ---
        if len(ton_results) < 5:
            try:
                GECKO_HEADERS = {"Accept": "application/json"}
                r = requests.get(
                    "https://api.geckoterminal.com/api/v2/networks/ton/trending_pools?page=1&include=base_token",
                    headers=GECKO_HEADERS, timeout=15)
                if r.status_code == 200:
                    data = r.json()
                    included_map = {}
                    for item in (data.get("included") or []):
                        attr = item.get("attributes",{})
                        iid  = item.get("id","")
                        if iid:
                            included_map[iid] = {
                                "symbol":   attr.get("symbol",""),
                                "address":  attr.get("address","") or attr.get("pool_address",""),
                                "telegram": attr.get("telegram_chat_url") or "",
                            }
                    for pool in (data.get("data") or []):
                        attr = pool.get("attributes",{})
                        mc_raw = attr.get("market_cap_usd") or attr.get("fdv_usd") or attr.get("reserve_in_usd") or 0
                        try: mc = float(mc_raw)
                        except Exception: mc = 0.0
                        if mc <= 0:
                            try: mc = float(attr.get("volume_usd",{}).get("h24") or 0)
                            except Exception: mc = 0.0
                        # Accept pools even if MC is low — some TON pools report reserve not fdv
                        rel_id = pool.get("relationships",{}).get("base_token",{}).get("data",{}).get("id","")
                        tok = included_map.get(rel_id,{})
                        # Try multiple ways to get a usable address
                        ca = (tok.get("address","")
                              or (rel_id.split("_",1)[1] if "_" in rel_id else ""))
                        # For GeckoTerminal TON, the pool address itself is usable as chart URL
                        pool_id = pool.get("id","")
                        pool_addr = pool_id.split("_",1)[1] if "_" in pool_id else pool_id
                        sym = tok.get("symbol","") or attr.get("name","TOKEN").split(" / ")[0]
                        if not sym or sym == "TOKEN": continue
                        # Use pool address for dex link if token CA not available
                        chart_addr = ca if (ca and len(ca) > 20) else pool_addr
                        if not chart_addr or chart_addr.lower() in blacklist: continue
                        if chart_addr in seen_t: continue
                        seen_t.add(chart_addr)
                        tg = tok.get("telegram","")
                        dex = f"https://dexscreener.com/ton/{chart_addr}"
                        mc_display = mc if mc > 0 else 1  # show something rather than nothing
                        ton_results.append({
                            "symbol": sym, "mc_fmt": fmt_mc(mc_display),
                            "tg_url": tg,  "dex_url": dex, "has_tg": bool(tg),
                        })
                        if len(ton_results) >= 10: break
            except Exception as e_gecko_ton:
                logger.warning(f"T2 TON GeckoTerminal fallback failed: {e_gecko_ton}")

        ton_results.sort(key=lambda x: (0 if x["has_tg"] else 1))
        chain_tokens["TON"] = ton_results[:5]
        if ton_results:
            logger.info(f"T2 TON trending: found {len(chain_tokens['TON'])} tokens")
        else:
            logger.warning("T2 TON trending: no tokens found from DexScreener or GeckoTerminal")
    except Exception as e:
        logger.warning(f"T2 TON trending outer error: {e}")

    # ── Inject pinned tokens at position 0 for their chain ─────────────────────
    _inject_pinned_tokens(chain_tokens)
    return chain_tokens

async def fetch_trending2():
    return await asyncio.to_thread(_fetch_trending2_sync)


def _build_new_trending_row(pos, token, emoji_ids_out):
    """Build one token row for the new trending post format.
    Appends position emoji + mc emoji to emoji_ids_out.
    Returns row text string."""
    sym     = html.escape(token.get("symbol","TOKEN"))
    mc_raw  = html.escape(token.get("mc_fmt","N/A"))
    tg_url  = token.get("tg_url","")
    dex_url = token.get("dex_url","")
    sym_part = (f'<b><a href="{html.escape(dex_url, quote=True)}">${sym}</a></b>'
                if dex_url else f"<b>${sym}</b>")
    mc_part  = (f'<a href="{html.escape(tg_url, quote=True)}">{mc_raw}</a>'
                if tg_url else mc_raw)
    # Number emoji placeholder  +  MC emoji placeholder
    emoji_ids_out.append(TRENDING2_EMOJIS_POS.get(pos, TRENDING2_EMOJIS_POS.get(1, 0)))
    emoji_ids_out.append(TRENDING2_MC_EMOJI)
    return f"🔮 {sym_part} 🔮 {mc_part}"


def build_trending2_post1_text_and_emojis(chain_tokens2):
    """Build post 3560: SOL (1-5) + ETH (6-10) + BSC (11-15).
    Returns (text, emoji_ids)."""
    parts = []
    emoji_ids = []

    sections = [
        ("SOL",  "SOL TRENDING",  range(1, 6)),
        ("ETH",  "ETH TRENDING",  range(6, 11)),
        ("BSC",  "BSC TRENDING",  range(11, 16)),
    ]
    for chain_key, label, pos_range in sections:
        # Chain header with emoji placeholder
        parts.append(f"<b>🔮 {label}</b>")
        emoji_ids.append(TRENDING2_CHAIN_EMOJIS.get(chain_key, TRENDING2_CHAIN_EMOJIS["SOL"]))
        parts.append("")
        tokens = chain_tokens2.get(chain_key, [])
        for i, pos in enumerate(pos_range):
            if i < len(tokens):
                row = _build_new_trending_row(pos, tokens[i], emoji_ids)
                parts.append(row)
            else:
                parts.append(f"🔮 <b>—</b> 🔮 —")
                emoji_ids.append(TRENDING2_EMOJIS_POS.get(pos, 0))
                emoji_ids.append(TRENDING2_MC_EMOJI)
        parts.append("")

    parts.append("These are the trending projects on DexScreener. \nThis is not financial advice, DYOR.")
    return "\n".join(parts), emoji_ids


def build_trending2_post2_text_and_emojis(chain_tokens2):
    """Build post 3562: Robinhood (16-20) + BASE (21-25) + TON (26-30).
    Returns (text, emoji_ids)."""
    parts = []
    emoji_ids = []

    sections = [
        ("RH",   "ROBINHOOD TRENDING", range(16, 21)),
        ("BASE", "BASE TRENDING",      range(21, 26)),
        ("TON",  "TON TRENDING",       range(26, 31)),
    ]
    for chain_key, label, pos_range in sections:
        parts.append(f"<b>🔮 {label}</b>")
        emoji_ids.append(TRENDING2_CHAIN_EMOJIS.get(chain_key, TRENDING2_CHAIN_EMOJIS["SOL"]))
        parts.append("")
        tokens = chain_tokens2.get(chain_key, [])
        for i, pos in enumerate(pos_range):
            if i < len(tokens):
                row = _build_new_trending_row(pos, tokens[i], emoji_ids)
                parts.append(row)
            else:
                parts.append(f"🔮 <b>—</b> 🔮 —")
                emoji_ids.append(TRENDING2_EMOJIS_POS.get(pos, 0))
                emoji_ids.append(TRENDING2_MC_EMOJI)
        parts.append("")

    parts.append("These are the trending projects on DexScreener. \nThis is not financial advice, DYOR.")
    return "\n".join(parts), emoji_ids


async def _update_trending2_posts(bot, chain_tokens2=None):
    """Fetch trending2 data and update posts 3560 + 3562 via userbot with premium emojis."""
    if chain_tokens2 is None:
        chain_tokens2 = await fetch_trending2()
        save_trending2_cache(chain_tokens2)  # persist for price-only updates next run

    text1, eids1 = build_trending2_post1_text_and_emojis(chain_tokens2)
    text2, eids2 = build_trending2_post2_text_and_emojis(chain_tokens2)

    results = {}
    for post_id, text, emoji_ids in [
        (POST_TRENDING_1, text1, eids1),
        (POST_TRENDING_2, text2, eids2),
    ]:
        ok = False
        if userbot_client:
            try:
                from telethon.extensions.html import parse as tl_html_parse
                plain_text, base_entities = tl_html_parse(text)
                all_entities = _build_new_trending_entities(plain_text, base_entities, emoji_ids)
                await userbot_client.edit_message(
                    TARGET_CHANNEL, post_id, plain_text,
                    formatting_entities=all_entities, link_preview=False
                )
                logger.info(f"✅ New trending post {post_id} updated with premium emojis")
                ok = True
            except Exception as e:
                logger.error(f"New trending post {post_id} premium edit failed: {e}")
        if not ok:
            try:
                await bot.edit_message_text(
                    chat_id=TARGET_CHANNEL, message_id=post_id,
                    text=text, parse_mode="HTML", disable_web_page_preview=True)
                ok = True
                logger.info(f"✅ New trending post {post_id} updated via bot API")
            except Exception:
                try:
                    await bot.edit_message_caption(
                        chat_id=TARGET_CHANNEL, message_id=post_id,
                        caption=text[:1024], parse_mode="HTML")
                    ok = True
                except Exception as e2:
                    logger.error(f"New trending post {post_id} bot fallback failed: {e2}")
        results[post_id] = ok

    return results


def _build_new_trending_entities(plain_text, base_entities, emoji_ids):
    """Build MessageEntityCustomEmoji for the new trending posts.
    Unlike the alert builder, these posts use simple sequential emoji replacement
    (no special-casing for KOL/BOT/badge — just positional).
    """
    try:
        from telethon.tl.types import MessageEntityCustomEmoji
    except ImportError:
        return base_entities or []
    if not emoji_ids:
        return base_entities or []

    custom_entities = []
    PLACEHOLDER = '🔮'
    PH_LEN = len(PLACEHOLDER)
    emoji_u16 = len(PLACEHOLDER.encode('utf-16-le')) // 2
    pos_index = 0
    utf16_off = 0
    i = 0
    while i < len(plain_text):
        if plain_text[i:i+PH_LEN] == PLACEHOLDER:
            if pos_index < len(emoji_ids):
                eid = emoji_ids[pos_index]
                if eid:
                    custom_entities.append(MessageEntityCustomEmoji(
                        offset=utf16_off, length=emoji_u16,
                        document_id=int(eid)
                    ))
                pos_index += 1
            utf16_off += emoji_u16
            i += PH_LEN
            continue
        char_u16 = len(plain_text[i].encode('utf-16-le')) // 2
        utf16_off += char_u16
        i += 1
    return (base_entities or []) + custom_entities


async def _post_hashtag_to_channel(bot):
    """Post the hashtag image to the channel."""
    try:
        with open(IMG_HASHTAG, "rb") as f:
            await bot.send_photo(TARGET_CHANNEL, photo=f, caption=HASHTAG_CAPTION)
        logger.info("✅ Hashtag post sent to channel")
    except Exception as e:
        logger.error(f"Hashtag post failed: {e}")

async def _post_promo_to_channel(bot):
    """Post the owner's promo template to @WizardScan (every 25 alerts)."""
    try:
        config   = load_config()
        template = config.get("promo_template","")
        if not template: return
        media    = config.get("promo_video")
        if media and media.get("file_id"):
            fid, ftype = media["file_id"], media.get("type","video")
            try:
                if ftype == "photo":
                    await bot.send_photo(TARGET_CHANNEL, photo=fid, caption=template, parse_mode="HTML")
                else:
                    await bot.send_video(TARGET_CHANNEL, video=fid, caption=template, parse_mode="HTML")
                logger.info("✅ Promo post sent")
                return
            except Exception: pass
        await bot.send_message(TARGET_CHANNEL, template, parse_mode="HTML", disable_web_page_preview=True)
        logger.info("✅ Promo post (text) sent")
    except Exception as e:
        logger.error(f"Promo post failed: {e}")

async def update_channel_post(bot, message_id, text, use_ranking_emojis=False):
    """Edit a post in @WizardScan — prefers userbot (premium account for emojis)."""
    ranking_emoji_ids = cfg_get("ranking_emojis", []) if use_ranking_emojis else None
    # Try userbot first (premium account, supports custom emojis)
    if userbot_client:
        ok = await _userbot_edit_with_premium_emoji(
            TARGET_CHANNEL, message_id, text,
            emoji_ids_for_ranking=ranking_emoji_ids
        )
        if ok:
            logger.info(f"✅ Userbot updated post {message_id}")
            return True
    # Fallback: bot API — try text edit first, then caption (for media posts)
    try:
        await bot.edit_message_text(
            chat_id=TARGET_CHANNEL, message_id=message_id,
            text=text, parse_mode="HTML", disable_web_page_preview=True
        )
        logger.info(f"✅ Bot updated post {message_id} (text)")
        return True
    except Exception as e:
        err = str(e)
        if "no text" in err.lower() or "message is not modified" in err.lower() or "there is no text" in err.lower():
            # Post has media — edit caption instead
            try:
                await bot.edit_message_caption(
                    chat_id=TARGET_CHANNEL, message_id=message_id,
                    caption=text[:1024], parse_mode="HTML"
                )
                logger.info(f"✅ Bot updated post {message_id} (caption)")
                return True
            except Exception as e2:
                logger.error(f"Bot edit caption post {message_id} failed: {e2}")
        else:
            logger.error(f"Bot edit post {message_id} failed: {e}")
    return False


async def _process_new_call(bot, channel: str, msg_id, text: str):
    """Process a single new message for a tracked channel.
    Zero blocking — track instantly, dex filled later by milestone_job.
    Returns True if a new call was registered."""
    try:
        channel = channel.lower()   # normalise — prevents same token tracked twice if casing differs
        msg_id_str = str(msg_id)

        # Mark as seen immediately — no re-processing on next poll
        if msg_id_str in seen_message_ids[channel]:
            return False
        seen_message_ids[channel].add(msg_id_str)

        if not is_call_message(text):
            return False
        result = extract_ca(text)
        # If no CA found directly, try to extract from chart/DEX links
        if not result:
            result = extract_ca_from_links(text)
        if not result:
            return False

        chain_guess, ca = result
        call_key = f"{channel}_{ca}"
        if call_key in tracked_calls:
            return False

        # ── Track immediately — NO dex wait ──────────────────────────────────
        # entry data filled in by milestone_job once token appears on Dexscreener
        tracked_calls[call_key] = {
            "channel":      channel,
            "msg_id":       msg_id_str,
            "ca":           ca,
            "chain":        chain_guess,   # "SOL" or "EVM"
            "entry_mc":     0,
            "entry_price":  0,
            "entry_fmt":    "N/A",
            "symbol":       "",
            "tracked_since": datetime.utcnow().isoformat(),
            "dex_pending":  True,          # milestone_job will fill this in
        }
        logger.info(f"📌 NEW CALL (instant) @{channel} chain={chain_guess} ca={ca[:12]}...")
        _save_tracked()
        _save_seen()

        # Background task: retry dex until we get data, THEN send dropped alert
        async def _fetch_and_alert():
            call_key_inner = f"{channel}_{ca}"
            dex = None

            # ── Graduated retry schedule ────────────────────────────────────────
            # Phase 1: 5 attempts × 3 s  = 15 s   (token may already be live)
            # Phase 2: 9 attempts × 10 s = 90 s   (new tokens can take 1-2 min)
            # Phase 3: 6 attempts × 20 s = 120 s  (FIX: slow/RH/BSC tokens take 3-5 min)
            # Total coverage: ~225 seconds ≈ 3.75 minutes
            retry_schedule = [(8, 2), (9, 10), (9, 20)]

            for phase_count, phase_sleep in retry_schedule:
                if dex and (dex.get("mcap") or dex.get("price")):
                    break  # good data already found in previous phase
                for _attempt in range(phase_count):
                    try:
                        fetched = await asyncio.wait_for(
                            asyncio.to_thread(_fetch_dex_sync, ca, 1, 0),  # min_liquidity=0
                            timeout=15)
                        if fetched:
                            # Accept if we have real price/mc data (not just partial symbol)
                            if fetched.get("mcap") or fetched.get("price"):
                                dex = fetched
                                break
                            # Accept partial result (symbol present but mc=0) — keep retrying
                            # but save the symbol so we have it if full data never arrives
                            if fetched.get("symbol") and not dex:
                                dex = fetched  # store partial; may be overwritten by better data
                    except Exception:
                        pass
                    await asyncio.sleep(phase_sleep)
                    # Stop early if we have full data
                    if dex and (dex.get("mcap") or dex.get("price")):
                        break

            # ── Fallback: use Jupiter / Pump.fun / GeckoTerminal ───────────────
            # Run fallback when ANY of these is missing:
            #   • no data at all (token not on DexScreener yet)
            #   • no symbol (token name missing)
            #   • no market cap (EVM tokens often have price but mc=null on DexScreener)
            has_symbol  = bool(dex and dex.get("symbol"))
            has_mc      = bool(dex and dex.get("mcap", 0) > 0)
            has_price   = bool(dex and dex.get("price", 0) > 0)
            # Pass the already-resolved chain (e.g. "ETH","BNB","BASE") if available,
            # so the fallback targets the right network immediately.
            resolved_chain = (dex.get("chain") if dex and dex.get("chain") else chain_guess)
            if not has_symbol or not has_mc:
                try:
                    fallback = await asyncio.to_thread(
                        _fetch_token_info_fallback_sync, ca, resolved_chain)
                    if fallback:
                        if dex is None:
                            dex = {"chain": resolved_chain, "mcap": 0, "mcap_fmt": "N/A",
                                   "price": 0, "symbol": ""}
                        # Fill ONLY what is missing — never overwrite good existing data
                        if fallback.get("symbol") and not dex.get("symbol"):
                            dex["symbol"] = fallback["symbol"]
                        if fallback.get("mcap", 0) > 0 and not dex.get("mcap", 0) > 0:
                            dex["mcap"]     = fallback["mcap"]
                            dex["mcap_fmt"] = fallback.get("mcap_fmt") or fmt_mc(fallback["mcap"])
                        if fallback.get("chain") and dex.get("chain") in (chain_guess, "EVM", None):
                            dex["chain"] = fallback["chain"]
                        logger.info(
                            f"🔍 Fallback applied: sym={dex.get('symbol')} "
                            f"mc={dex.get('mcap_fmt')} chain={dex.get('chain')} @{channel}")
                except Exception as fe:
                    logger.warning(f"Fallback apply error: {fe}")

            # ── Determine final values ──────────────────────────────────────────
            if dex and (dex.get("mcap") or dex.get("price")):
                # Full data: update tracked call and alert
                if call_key_inner in tracked_calls:
                    tracked_calls[call_key_inner].update({
                        "entry_mc":    dex.get("mcap", 0),
                        "entry_price": dex.get("price", 0),
                        "entry_fmt":   dex.get("mcap_fmt", "N/A"),
                        "symbol":      dex.get("symbol", ""),
                        "chain":       dex.get("chain", chain_guess),
                        "dex_pending": False,
                    })
                _save_tracked()
                final_chain  = dex.get("chain", chain_guess)
                final_fmt    = dex.get("mcap_fmt", "N/A")
                final_symbol = dex.get("symbol", "")
                logger.info(f"📊 dex filled: {final_symbol} {final_fmt} @{channel}")
            elif dex and dex.get("symbol"):
                # Partial data: token is on DEX but price/mc not indexed yet.
                # Still update the symbol so it shows correctly in the alert.
                if call_key_inner in tracked_calls:
                    tracked_calls[call_key_inner].update({
                        "symbol": dex.get("symbol", ""),
                        "chain":  dex.get("chain", chain_guess),
                    })
                _save_tracked()
                final_chain  = dex.get("chain", chain_guess)
                final_fmt    = "N/A"
                final_symbol = dex.get("symbol", "")
                logger.info(f"📊 partial dex: sym={final_symbol} (mc N/A) @{channel}")
            else:
                final_chain  = chain_guess
                final_fmt    = "N/A"
                final_symbol = ""
                logger.warning(f"⚠️ dex still N/A after all retries+fallback: {ca[:12]}...")

            # Never publish an alert with N/A data — defer it. monitoring_job fires
            # it automatically the moment DexScreener starts indexing the token.
            if final_fmt == "N/A" or not final_symbol:
                if call_key_inner in tracked_calls:
                    tracked_calls[call_key_inner]["alert_pending"] = True
                    tracked_calls[call_key_inner]["dex_pending"]   = True
                    _save_tracked()
                logger.info(f"⏳ alert deferred (incomplete data) {ca[:12]}... @{channel}")
                return

            await send_dropped_alert(
                bot, channel, msg_id_str, ca, final_chain, final_fmt, final_symbol)

        asyncio.create_task(_fetch_and_alert())
        return True
    except Exception as e:
        logger.error(f"_process_new_call @{channel}: {e}")
        return False


async def setup_realtime_monitoring(bot):
    """Register a Telethon event handler so new KOL posts are tracked instantly (< 2 sec).
    Falls back to the 15s polling loop if userbot is not connected.

    Crash-safe: all Telethon calls wrapped so any Telethon internal error (v1.44.0 bugs,
    RuntimeError: Event loop is closed, NoneType await etc.) only logs a warning and
    returns — it never propagates and crashes the Railway process.
    """
    global _bot_ref, userbot_client
    _bot_ref = bot
    if not userbot_client:
        logger.info("Realtime monitoring: no userbot — using polling fallback only")
        return

    # Guard: if userbot is connected but not authorized, skip silently
    try:
        if not await asyncio.wait_for(userbot_client.is_user_authorized(), timeout=10):
            logger.warning("Realtime monitoring: userbot not authorized — skipping")
            return
    except Exception as e:
        logger.warning(f"Realtime monitoring: auth check failed ({e}) — skipping")
        return

    try:
        from telethon import events

        channels = load_channels()
        if not channels:
            logger.info("Realtime monitoring: no channels tracked yet")
            return

        # ── Auto-join + resolve channel entities ─────────────────────────────
        # Telethon only fires NewMessage events for channels the userbot HAS JOINED.
        # get_entity() resolves but does NOT join. JoinChannelRequest joins.
        resolved = []
        for ch in channels:
            try:
                try:
                    from telethon.tl.functions.channels import JoinChannelRequest
                    await asyncio.wait_for(userbot_client(JoinChannelRequest(ch)), timeout=15)
                except Exception:
                    pass  # already joined or public access — get_entity still works
                ent = await asyncio.wait_for(userbot_client.get_entity(ch), timeout=10)
                resolved.append(ent)
            except Exception as e:
                logger.warning(f"Realtime: could not resolve/join @{ch}: {e}")

        if not resolved:
            logger.warning("Realtime monitoring: could not resolve any channels")
            return

        # Remove any existing handlers to avoid double-firing after reconnect
        userbot_client.remove_event_handler(None)  # clears all handlers safely

        @userbot_client.on(events.NewMessage(chats=resolved))
        async def _realtime_handler(event):
            global _bot_ref
            try:
                if _bot_ref is None:
                    return
                chat = await event.get_chat()
                # Never react to groups / lounges — only broadcast KOL channels
                if getattr(chat, 'megagroup', False) or not getattr(chat, 'broadcast', False):
                    return
                username = (getattr(chat, 'username', None) or "").lower()
                channels_now = [c.lower() for c in load_channels()]
                if username not in channels_now:
                    return
                try:
                    ev_ts = event.message.date.timestamp() if event.message.date else 0
                except Exception:
                    ev_ts = 0
                if ev_ts and (time.time() - ev_ts) > FRESH_POST_WINDOW:
                    seen_message_ids[username].add(str(event.id))
                    return
                text   = event.text or event.caption or ""
                msg_id = str(event.id)
                if msg_id in seen_message_ids[username]:
                    return
                # NOTE: do NOT add to seen here — _process_new_call owns that state
                await _process_new_call(_bot_ref, username, msg_id, text)
            except (RuntimeError, TypeError) as e:
                # Telethon v1.44.0 internal errors — log only, don't re-raise
                logger.debug(f"Realtime handler Telethon noise: {e}")
            except Exception as e:
                logger.error(f"Realtime handler: {e}")

        logger.info(f"✅ Realtime monitoring active for {len(resolved)} channels")
    except (RuntimeError, TypeError) as e:
        # Suppress Telethon v1.44.0 internal errors (Event loop is closed etc.)
        logger.warning(f"setup_realtime_monitoring Telethon error (suppressed): {e}")
    except Exception as e:
        logger.error(f"setup_realtime_monitoring failed: {e}")


async def baseline_safety_job(context: ContextTypes.DEFAULT_TYPE):
    """Fail-safe: if startup baseline never completed (userbot hang etc.), enable
    scanning anyway after a few minutes. Stale posts are still filtered by
    FRESH_POST_WINDOW, so no old calls can be replayed."""
    global _BASELINE_READY
    if not _BASELINE_READY:
        _BASELINE_READY = True
        logger.warning("⚠️ Baseline safety timer fired — scanning enabled")


async def userbot_watchdog_job(context: ContextTypes.DEFAULT_TYPE):
    """Runs every 5 minutes. Detects userbot disconnection and auto-recovers.

    Why needed: Telethon v1.44.0 has a known bug where connection drops cause
    RuntimeError crashes. Even with auto_reconnect=True, the internal event loop
    can get into a bad state. This watchdog detects that and re-initialises the
    entire client from scratch, then re-registers realtime monitoring.
    """
    global userbot_client
    try:
        if not userbot_client:
            # No session configured — nothing to watch
            return

        is_ok = False
        try:
            is_ok = (
                userbot_client.is_connected()
                and await asyncio.wait_for(userbot_client.is_user_authorized(), timeout=10)
            )
        except Exception:
            is_ok = False

        if is_ok:
            return  # All good — nothing to do

        logger.warning("🔄 Userbot watchdog: connection lost — reinitialising...")
        await init_userbot()
        if userbot_client:
            await setup_realtime_monitoring(context.bot)
            logger.info("✅ Userbot watchdog: reconnected and realtime monitoring restored")
        else:
            logger.warning("⚠️ Userbot watchdog: reconnect failed — will retry next cycle")
    except Exception as e:
        logger.error(f"userbot_watchdog_job crash: {e}")


async def cmd_joinkols(update, context):
    """Make userbot join all tracked KOL channels (needed for realtime monitoring)."""
    if update.effective_user.id not in OWNER_IDS:
        return
    if not userbot_client:
        await update.message.reply_text("⚠️ Userbot connected nahi hai. /userbotcheck karo."); return
    channels = load_channels()
    if not channels:
        await update.message.reply_text("⚠️ Koi channels track nahi hain."); return
    msg = await update.message.reply_text(
        f"⏳ {len(channels)} channels join kar raha hoon...", parse_mode="HTML")
    joined=0; failed=[]
    for ch in channels:
        try:
            await userbot_client.get_entity(ch)
            # If entity resolves, try to join
            try:
                from telethon.tl.functions.channels import JoinChannelRequest
                await userbot_client(JoinChannelRequest(ch))
                joined+=1
            except Exception:
                joined+=1  # already member or public access
        except Exception as e:
            failed.append(ch)
        await asyncio.sleep(1)
    txt = f"✅ <b>Done!</b>\n\nJoined/accessed: <b>{joined}</b> channels"
    if failed:
        txt += "\n\n❌ Failed (" + str(len(failed)) + "): " + ", ".join(f"@{c}" for c in failed[:10])
    txt += "\n\n<i>Ab realtime monitoring kaam kare gi — redeploy nahi chahiye.</i>"
    await msg.edit_text(txt, parse_mode="HTML")


# ─── Scan job (fast — new call detection only, no dex) ───────────────────────
async def scan_job(context: ContextTypes.DEFAULT_TYPE):
    """Runs every 3 s. Only detects new calls — zero dex waits, completes in < 1 s."""
    try:
        if not _BASELINE_READY:
            return   # startup baseline not finished — never replay old posts
        bot      = context.bot
        channels = load_channels()
        if not channels:
            return

        sem = asyncio.Semaphore(8)  # up to 8 channels fetched in parallel

        async def _scan_one(channel):
            async with sem:
                try:
                    posts = await fetch_channel_posts(channel)
                    now_ts = time.time()
                    for post in posts:
                        mid = str(post["id"])
                        if mid in seen_message_ids[channel]:
                            continue
                        ts = post.get("ts") or 0
                        if ts and (now_ts - ts) > FRESH_POST_WINDOW:
                            # Old post (redeploy / backfill) — mark seen, never alert
                            seen_message_ids[channel].add(mid)
                            continue
                        await _process_new_call(bot, channel, mid, post["text"])
                except Exception as e:
                    logger.error(f"scan_job @{channel}: {e}")

        await asyncio.gather(*[_scan_one(ch) for ch in channels])

    except Exception as e:
        logger.error(f"scan_job crash: {e}")


# ─── Milestone job (slower — dex checks + alerts) ────────────────────────────
async def monitoring_job(context: ContextTypes.DEFAULT_TYPE):
    """Runs every 5 s (real-time). Fills dex_pending entry data and fires milestone alerts.

    Market caps come from DexScreener only, refreshed in bulk on every tick."""
    try:
        bot   = context.bot
        items = list(tracked_calls.items())
        if not items:
            return

        # Skip calls for channels that have been delisted
        active_channels_lower = {c.lower() for c in load_channels()}
        items = [(k, v) for k, v in items if v.get("channel", "").lower() in active_channels_lower]

        # ── Real-time bulk refresh: one DexScreener request per 30 tokens ─────
        try:
            await asyncio.to_thread(
                _bulk_refresh_dex_sync,
                [v.get("ca") for _, v in items if v.get("ca") and not v.get("frozen")])
        except Exception as e_bulk:
            logger.warning(f"bulk dex refresh failed: {e_bulk}")

        async def check_one(call_key, call):
            try:
                if call.get("frozen"): return []
                try:
                    dex = await asyncio.wait_for(fetch_dexscreener(call["ca"]), timeout=15)
                except asyncio.TimeoutError:
                    logger.warning(f"DexScreener timeout: {call['ca'][:12]}...")
                    return []
                if dex is None: return []

                cur_price = dex.get("price", 0)
                cur_mc    = dex.get("mcap", 0)

                # Sanity check: DexScreener sometimes returns garbage/inflated data.
                # If MC is > $1T it's almost certainly wrong — skip to avoid phantom billion alerts.
                if cur_mc > 1_000_000_000_000:
                    logger.warning(f"Skipping unrealistic MC ${cur_mc:.0f} for {call['ca'][:12]}...")
                    return []

                # Fill in entry data for calls tracked before token was on dex
                if call.get("dex_pending") and (cur_price > 0 or cur_mc > 0):
                    call["entry_price"] = cur_price
                    call["entry_mc"]    = cur_mc
                    call["entry_fmt"]   = dex.get("mcap_fmt", "N/A")
                    call["symbol"]      = dex.get("symbol", "")
                    call["chain"]       = dex.get("chain", call.get("chain", "SOL"))
                    call["dex_pending"] = False
                    logger.info(f"📊 entry filled: {call['symbol']} @{call['channel']} {call['entry_fmt']}")
                    # Deferred "new call" alert — send it now that data is real
                    if call.get("alert_pending") and call.get("entry_fmt", "N/A") != "N/A":
                        call["alert_pending"] = False
                        try:
                            await send_dropped_alert(
                                bot, call["channel"], call["msg_id"], call["ca"],
                                call.get("chain", "SOL"), call.get("entry_fmt", "N/A"),
                                call.get("symbol", ""))
                        except Exception as _ed:
                            logger.warning(f"deferred alert failed: {_ed}")
                # Also fill missing symbol for calls that were tracked but have empty symbol
                elif not call.get("dex_pending") and not call.get("symbol") and dex.get("symbol"):
                    call["symbol"] = dex.get("symbol", "")
                    logger.info(f"📊 symbol filled late: {call['symbol']} @{call['channel']}")

                entry_price = call.get("entry_price", 0)
                entry_mc    = call.get("entry_mc", 0)

                if entry_price > 0 and cur_price > 0:
                    ratio = cur_price / entry_price
                elif entry_mc > 0 and cur_mc > 0:
                    ratio = cur_mc / entry_mc
                else:
                    return []

                # Safety cap: ratio cannot exceed MAX_MILESTONE × 2 to prevent phantom billions
                # If a token rugged, DexScreener returns None → this code won't run, so no inflated ratio
                ratio = min(ratio, MAX_MILESTONE * 2)
                call["last_ratio"] = round(ratio, 4)

                # ── Milestone MC fix ────────────────────────────────────────
                # Every milestone must show the market cap AT that multiple.
                # Previously all pending milestones reused the same live MC, so a
                # 4X call showed identical MC in the 2X, 3X and 4X posts.
                pending = [ms for ms in get_milestones()
                           if ms <= MAX_MILESTONE and ratio >= ms
                           and ms not in sent_milestones[call_key]]
                pending.sort()
                top_ms = pending[-1] if pending else None
                triggered = []
                for ms in pending:
                    ms_mc_fmt = None
                    if entry_mc > 0:
                        # Exact MC for this multiple, derived from the entry MC
                        ms_mc_fmt = fmt_mc(entry_mc * ms)
                    # Only the highest milestone just reached may use the live MC,
                    # and only when the live value is close to that multiple.
                    if (ms == top_ms and cur_mc > 0 and cur_mc < 1_000_000_000_000
                            and (entry_mc <= 0 or cur_mc <= entry_mc * ms * 1.5)):
                        ms_mc_fmt = fmt_mc(cur_mc)
                    if not ms_mc_fmt:
                        ms_mc_fmt = dex.get("mcap_fmt", "N/A")
                    triggered.append((call_key, call, ms, ms_mc_fmt))
                return triggered
            except Exception:
                return []

        all_hits = []
        for i in range(0, len(items), 10):
            batch = await asyncio.gather(*[check_one(k, v) for k, v in items[i:i+10]])
            for hits in batch:
                all_hits.extend(hits)
            if i + 10 < len(items):
                await asyncio.sleep(0.05)

        _save_tracked()

        for call_key, call, ms, cur_fmt in all_hits:
            sent_milestones[call_key].add(ms); _save_milestones()
            logger.info(f"🚀 {call.get('symbol','?')} @{call['channel']} {ms}X!")
            await send_alert(bot, call["channel"], call["msg_id"], ms,
                             call["chain"], call["entry_fmt"], cur_fmt, call["ca"], call["symbol"])
            await asyncio.sleep(0.5)

        # Failed-call deduction: tracked > CALL_FAIL_DAYS without hitting 2X
        cutoff_fail = datetime.utcnow() - timedelta(days=CALL_FAIL_DAYS)
        for call_key, call in list(tracked_calls.items()):
            if 2 in sent_milestones.get(call_key, set()):
                continue
            ts_str = call.get("tracked_since", "")
            if not ts_str:
                continue
            try:
                if datetime.fromisoformat(ts_str) < cutoff_fail:
                    await deduct_points_for_failed_call(call["channel"], call_key)
            except Exception:
                pass

    except Exception as e:
        logger.error(f"monitoring_job crash: {e}")

# ─── Leaderboard auto-update job ─────────────────────────────────────────────
async def _update_leaderboard_with_premium_emojis(bot):
    """Edit post 136 with leaderboard data + all premium emojis via userbot."""
    global userbot_client
    text    = build_leaderboard_text()
    top10   = _calc_leaderboard_scores()
    n       = len(top10)

    # Ordered emoji list: [star(header), num1, arrow, num2, arrow, ... numN, arrow, star(footer)]
    emoji_ids = [LEADERBOARD_PREMIUM_EMOJIS["star"]]
    for i in range(1, n + 1):
        emoji_ids.append(LEADERBOARD_PREMIUM_EMOJIS.get(i, LEADERBOARD_PREMIUM_EMOJIS[1]))
        emoji_ids.append(LEADERBOARD_PREMIUM_EMOJIS["arrow"])
    emoji_ids.append(LEADERBOARD_PREMIUM_EMOJIS["star"])  # footer star

    # Try to reconnect userbot if disconnected
    if userbot_client and not userbot_client.is_connected():
        try:
            await userbot_client.connect()
            logger.info("✅ Userbot reconnected for leaderboard update")
        except Exception as e_rc:
            logger.warning(f"Userbot reconnect failed: {e_rc}")
            userbot_client = None

    if userbot_client:
        try:
            from telethon.extensions.html import parse as tl_html_parse
            plain_text, base_entities = tl_html_parse(text)
            all_entities = _build_premium_entities(plain_text, base_entities, emoji_ids, forced_pack=None)
            await userbot_client.edit_message(
                TARGET_CHANNEL, POST_LEADERBOARD, plain_text,
                formatting_entities=all_entities,
                link_preview=False
            )
            logger.info("✅ Leaderboard post 136 updated with premium emojis")
            return True
        except Exception as e:
            logger.error(f"Leaderboard premium emoji edit failed: {e}")
            # Do NOT fall back to bot API — it would strip premium emojis from the post.
            # Better to keep the old premium-emoji post than overwrite with plain text.
            return False

    # Userbot unavailable — skip update to preserve existing premium emojis on the post.
    logger.warning("Leaderboard update skipped: userbot unavailable (preserving premium emojis).")
    return False

async def leaderboard_job(context: ContextTypes.DEFAULT_TYPE):
    """Update post 136 (leaderboard) every 1-2 minutes. Auto-resets scores every 3 days."""
    config = load_config()
    now    = datetime.utcnow()

    # ── regular update cooldown (2 min) ──────────────────────────────────────
    last_upd = config.get("last_leaderboard_update","")
    try:
        if last_upd:
            last_dt = datetime.fromisoformat(last_upd)
            if now - last_dt < timedelta(minutes=2): return
    except Exception: pass
    try:
        ok = await _update_leaderboard_with_premium_emojis(context.bot)
        if ok:
            cfg_set("last_leaderboard_update", now.isoformat())
    except Exception as e:
        logger.error(f"Leaderboard update failed: {e}")

async def _update_champions_with_premium_emojis(bot):
    """Edit post 137 with champions data + all premium emojis via userbot."""
    global userbot_client
    text     = build_champions_text()
    # Build emoji_ids to match EXACTLY the 🔮 placeholders in build_champions_text().
    # build_champions_text() always pads to 10 rows (real champions + dash rows),
    # so the text always has: 1 header 🔮 + 10 rows × 2 🔮 + 1 footer 🔮 = 22 total 🔮.
    # emoji_ids must have exactly 22 entries — otherwise the userbot edit fails
    # and falls back to plain bot API (no premium emojis).
    pts_data = load_channel_points()
    channels = load_channels()
    excluded_keys = set(load_config().get("champion_excluded_call_keys", []))
    champ_count = sum(
        1 for ch in channels
        if pts_data.get(ch.lower(), {}).get("points", 0) >= POINTS_FOR_CHAMPION
    )
    n = min(champ_count, 10)  # real champion rows (0–10)

    emoji_ids = [CHAMPIONS_PREMIUM_EMOJIS["star"]]  # header star (row 0 🔮)
    for i in range(1, 11):   # always exactly 10 rows
        if i <= n:
            # Real champion row — use the rank-specific emoji
            emoji_ids.append(CHAMPIONS_PREMIUM_EMOJIS.get(i, CHAMPIONS_PREMIUM_EMOJIS[1]))
        else:
            # Dash / empty row — use rank-1 emoji as neutral placeholder
            emoji_ids.append(CHAMPIONS_PREMIUM_EMOJIS[1])
        emoji_ids.append(CHAMPIONS_PREMIUM_EMOJIS["arrow"])  # second 🔮 in every row
    emoji_ids.append(CHAMPIONS_PREMIUM_EMOJIS["star"])  # footer star (last 🔮)

    # Try to reconnect userbot if disconnected
    if userbot_client and not userbot_client.is_connected():
        try:
            await userbot_client.connect()
            logger.info("✅ Userbot reconnected for champions update")
        except Exception as e_rc:
            logger.warning(f"Userbot reconnect failed: {e_rc}")
            userbot_client = None

    if userbot_client:
        try:
            from telethon.extensions.html import parse as tl_html_parse
            plain_text, base_entities = tl_html_parse(text)
            all_entities = _build_premium_entities(plain_text, base_entities, emoji_ids, forced_pack=None)
            await userbot_client.edit_message(
                TARGET_CHANNEL, POST_CHAMPIONS, plain_text,
                formatting_entities=all_entities, link_preview=False
            )
            logger.info("✅ Champions post 137 updated with premium emojis")
            return True
        except Exception as e:
            logger.error(f"Champions premium emoji edit failed: {e}")

    # Userbot was configured but failed — do NOT fall back to bot API.
    # Falling back strips premium emojis permanently from the post.
    # The champions_job runs every 2 min and will retry via userbot automatically.
    if userbot_client is not None:
        logger.warning("Champions userbot edit failed — skipping bot API fallback to preserve premium emojis. Will retry next cycle.")
        return False

    # Userbot never configured — use bot API as the only option
    try:
        await bot.edit_message_caption(
            chat_id=TARGET_CHANNEL, message_id=POST_CHAMPIONS,
            caption=text, parse_mode="HTML"
        )
        logger.info("✅ Champions post 137 updated via bot API (userbot not configured)")
        return True
    except Exception:
        pass
    try:
        await bot.edit_message_text(
            chat_id=TARGET_CHANNEL, message_id=POST_CHAMPIONS,
            text=text, parse_mode="HTML", disable_web_page_preview=True
        )
        logger.info("✅ Champions post 137 updated via bot API text fallback")
        return True
    except Exception as e2:
        logger.error(f"Champions bot API fallback also failed: {e2}")
        return False

async def champions_job(context: ContextTypes.DEFAULT_TYPE):
    """Update post 137 (champions) every 1-2 minutes. Resets all points every 7 days."""
    config   = load_config()
    now      = datetime.utcnow()

    # ── regular update cooldown (2 min) ──────────────────────────────────────
    last_upd = config.get("last_champions_update", "")
    try:
        if last_upd:
            last_dt = datetime.fromisoformat(last_upd)
            if now - last_dt < timedelta(minutes=2): return
    except Exception: pass
    try:
        ok = await _update_champions_with_premium_emojis(context.bot)
        if ok:
            cfg_set("last_champions_update", now.isoformat())
    except Exception as e:
        logger.error(f"Champions update failed: {e}")

async def _update_trending_with_premium_emojis(bot, chain_tokens=None):
    """Fetch trending and edit post 135 with premium emojis via userbot.
    If chain_tokens is provided, skips the fetch (used by /refreshtrending to avoid double-fetch).
    """
    if chain_tokens is None:
        chain_tokens = await fetch_trending()
        save_trending_cache(chain_tokens)  # persist so next run uses price-only update
    text, emoji_ids     = build_trending_text_and_emojis(chain_tokens)

    if userbot_client:
        try:
            from telethon.extensions.html import parse as tl_html_parse
            plain_text, base_entities = tl_html_parse(text)
            all_entities = _build_premium_entities(plain_text, base_entities, emoji_ids, forced_pack=None)
            await userbot_client.edit_message(
                TARGET_CHANNEL, POST_TRENDING, plain_text,
                formatting_entities=all_entities, link_preview=False
            )
            logger.info("✅ Trending post 135 updated with premium emojis")
            return True
        except Exception as e:
            logger.error(f"Trending premium emoji edit failed: {e}")
    try:
        await bot.edit_message_caption(
            chat_id=TARGET_CHANNEL, message_id=POST_TRENDING,
            caption=text, parse_mode="HTML"
        )
        logger.info("✅ Trending post 135 updated via bot API caption")
        return True
    except Exception:
        pass
    try:
        await bot.edit_message_text(
            chat_id=TARGET_CHANNEL, message_id=POST_TRENDING,
            text=text, parse_mode="HTML", disable_web_page_preview=True
        )
        return True
    except Exception as e:
        logger.error(f"Trending bot fallback edit failed: {e}")
        return False

TRENDING_AUTO_RESET_HOURS = 24  # auto-refresh token list every 24 hours

async def trending_job(context: ContextTypes.DEFAULT_TYPE):
    """Update post 135 (trending) every 2 minutes.
    If a trending cache exists, only refresh MC prices (tokens stay fixed).
    Token list auto-resets every 24 hours OR after a manual /resetXXXtrend command."""
    try:
        now = datetime.utcnow()
        # Auto-reset check: if last full fetch was more than 24h ago, force re-fetch
        last_upd = cfg_get("last_trending_update", "")
        auto_reset = False
        if last_upd:
            try:
                age_h = (now - datetime.fromisoformat(last_upd)).total_seconds() / 3600
                if age_h >= TRENDING_AUTO_RESET_HOURS:
                    auto_reset = True
                    logger.info(f"Trending auto-reset triggered (age={age_h:.1f}h)")
            except Exception:
                pass

        cache = load_trending_cache()
        if cache and any(len(v) > 0 for v in cache.values()) and not auto_reset:
            updated = await _update_prices_for_chain_tokens(cache)
            _inject_pinned_tokens(updated)
            save_trending_cache(updated)
            ok = await _update_trending_with_premium_emojis(context.bot, chain_tokens=updated)
        else:
            if auto_reset:
                save_trending_cache({})  # clear stale cache
            chain_tokens = await fetch_trending()
            save_trending_cache(chain_tokens)
            ok = await _update_trending_with_premium_emojis(context.bot, chain_tokens=chain_tokens)
        if ok:
            cfg_set("last_trending_update", now.isoformat())
    except Exception as e:
        logger.error(f"Trending post 135 update failed: {e}")

async def trending2_job(context: ContextTypes.DEFAULT_TYPE):
    """Update posts 3560 + 3562 (new trending) every 2 minutes.
    If a trending2 cache exists, only refresh MC prices (tokens stay fixed).
    Token list auto-resets every 24 hours."""
    try:
        now = datetime.utcnow()
        # Auto-reset check
        last_upd2 = cfg_get("last_trending2_update", "")
        auto_reset2 = False
        if last_upd2:
            try:
                age_h = (now - datetime.fromisoformat(last_upd2)).total_seconds() / 3600
                if age_h >= TRENDING_AUTO_RESET_HOURS:
                    auto_reset2 = True
                    logger.info(f"Trending2 auto-reset triggered (age={age_h:.1f}h)")
            except Exception:
                pass

        cache2 = load_trending2_cache()
        if cache2 and any(len(v) > 0 for v in cache2.values()) and not auto_reset2:
            updated2 = await _update_prices_for_chain_tokens(cache2)
            _inject_pinned_tokens(updated2)
            save_trending2_cache(updated2)
            res = await _update_trending2_posts(context.bot, chain_tokens2=updated2)
        else:
            if auto_reset2:
                save_trending2_cache({})
            chain_tokens2 = await fetch_trending2()
            save_trending2_cache(chain_tokens2)
            res = await _update_trending2_posts(context.bot, chain_tokens2=chain_tokens2)
        if any(res.values()):
            cfg_set("last_trending2_update", now.isoformat())
    except Exception as e:
        logger.error(f"Trending posts 3560/3562 update failed: {e}")

async def momentum_check_job(context: ContextTypes.DEFAULT_TYPE):
    """Daily check: if any KOL channel delivered 2+ calls to same X in last 7 days, post MOMENTUM ACTIVE."""
    try:
        channels      = load_channels()
        now           = datetime.utcnow()
        week_ago      = now - timedelta(days=7)
        momentum_sent = load_momentum_sent()

        for ch in channels:
            # Collect calls from this channel tracked within the last 7 days
            weekly_calls = []
            for call_key, call in tracked_calls.items():
                if call.get("channel","").lower() != ch.lower(): continue
                ts_str = call.get("tracked_since","")
                try:
                    if datetime.fromisoformat(ts_str) >= week_ago:
                        weekly_calls.append((call_key, call))
                except Exception: pass

            if len(weekly_calls) < 5:
                continue

            # Group calls by which X milestones they hit
            from collections import defaultdict as _dd
            x_calls = _dd(list)
            for call_key, call in weekly_calls:
                for x in sent_milestones.get(call_key, set()):
                    x_calls[x].append((call_key, call))

            for x_val, calls in x_calls.items():
                if len(calls) < 5: continue
                if x_val < 10: continue  # Only post MOMENTUM ACTIVE for 10x+ calls
                # Skip if already posted this combo within 7 days
                ch_sent = momentum_sent.get(ch, {})
                last_sent = ch_sent.get(str(x_val), "")
                if last_sent:
                    try:
                        if now - datetime.fromisoformat(last_sent) < timedelta(days=7): continue
                    except Exception: pass

                # Build MOMENTUM ACTIVE post
                bot_username = (await context.bot.get_me()).username
                xray_url     = f"https://t.me/{bot_username}?start=xray_{ch}_{x_val}"

                text = (
                    f"<b>🔮 MOMENTUM ACTIVE 🔮</b>\n\n"
                    f"<b>@{ch}</b> has delivered <b>{len(calls)}</b> calls above <b>{x_val}X</b> in the last 7 days.\n\n"
                    f"Consistent edge. Consistent results. Track the pattern."
                )
                momentum_emoji_ids = [MOMENTUM_ACTIVE_EMOJI_ID, MOMENTUM_ACTIVE_EMOJI_ID]
                # Append leaderboard/champions badge to momentum post
                m_badge = _get_kol_badge(ch)
                if m_badge:
                    if m_badge["type"] == "leaderboard":
                        m_rank_id = LEADERBOARD_PREMIUM_EMOJIS.get(m_badge["rank"], LEADERBOARD_PREMIUM_EMOJIS[1])
                        text += f'\n\n🔮 <b><a href="https://t.me/WizardScan/136">LEADERBOARD KOL</a></b> 🔮'
                        momentum_emoji_ids = momentum_emoji_ids + [LEADERBOARD_PREMIUM_EMOJIS["star"], m_rank_id]
                    else:
                        m_rank_id = CHAMPIONS_PREMIUM_EMOJIS.get(m_badge["rank"], CHAMPIONS_PREMIUM_EMOJIS[1])
                        text += f'\n\n🔮 <b><a href="https://t.me/WizardScan/137">CHAMPION KOL</a></b> 🔮'
                        momentum_emoji_ids = momentum_emoji_ids + [CHAMPIONS_PREMIUM_EMOJIS["star"], m_rank_id]

                # KOL Signal buttons — 2 per row
                signal_buttons = []
                row = []
                for ck, _ in calls[:10]:
                    # Try exact x_val post first, then any available post for this call
                    post_id = milestone_posts.get(ck, {}).get(str(x_val))
                    if not post_id:
                        # Fallback: find closest available milestone post for this call
                        _ck_posts = milestone_posts.get(ck, {})
                        if _ck_posts:
                            _valid_keys = [v for v in _ck_posts.keys() if v.lstrip('-').isdigit()]
                            if _valid_keys:
                                _sorted_x = sorted(_valid_keys, key=lambda v: abs(int(v) - x_val))
                                post_id = _ck_posts.get(_sorted_x[0])
                    btn_url = (f"https://t.me/WizardScan/{post_id}" if post_id
                               else f"https://t.me/WizardScan")
                    row.append(InlineKeyboardButton("🔮 KOL Signal", url=btn_url))
                    if len(row) == 2:
                        signal_buttons.append(row); row = []
                if row:
                    signal_buttons.append(row)
                # X-Ray button last row
                signal_buttons.append([InlineKeyboardButton("🔮 X-Ray Report", url=xray_url)])
                kb = InlineKeyboardMarkup(signal_buttons)

                # Rotating momentum video — config-stored file_ids first, else VID_MOMENTUM_LIST
                _mcfg = load_config()
                momentum_idx = _mcfg.get("momentum_video_index", 0)
                _mom_vids = _mcfg.get("momentum_videos", [])
                if _mom_vids:
                    _mv = _mom_vids[momentum_idx % len(_mom_vids)]
                    cfg_set("momentum_video_index", (momentum_idx + 1) % len(_mom_vids))
                    vid_file_id = _mv.get("file_id"); vid_ftype = _mv.get("type", "video")
                    vid_path = None
                else:
                    vid_file_id = None; vid_ftype = None
                    vid_path = VID_MOMENTUM_LIST[momentum_idx % len(VID_MOMENTUM_LIST)]
                    cfg_set("momentum_video_index", (momentum_idx + 1) % len(VID_MOMENTUM_LIST))

                try:
                    posted_momentum = False
                    momentum_msg_id = None
                    if vid_file_id:
                        if userbot_client and momentum_emoji_ids:
                            try:
                                # Send emoji via userbot (no buttons — will add via bot edit below)
                                sent = await _userbot_send_media_with_emoji(
                                    context.bot, TARGET_CHANNEL, vid_file_id, vid_ftype,
                                    text, momentum_emoji_ids, None)
                                if sent:
                                    posted_momentum = True
                                    try: momentum_msg_id = sent.id
                                    except Exception: pass
                                    logger.info(f"✅ MOMENTUM ACTIVE (userbot+emoji+fileid) @{ch} {x_val}X")
                            except Exception as e_fid:
                                logger.warning(f"Momentum userbot file_id send failed: {e_fid}")
                        if not posted_momentum:
                            _sent_b = await context.bot.send_video(chat_id=TARGET_CHANNEL, video=vid_file_id,
                                caption=text, parse_mode="HTML", reply_markup=kb)
                            posted_momentum = True
                            try: momentum_msg_id = _sent_b.message_id
                            except Exception: pass
                    elif userbot_client and vid_path and os.path.exists(vid_path):
                        try:
                            from telethon.extensions.html import parse as tl_html_parse
                            plain_text, base_ents = tl_html_parse(text)
                            all_ents = _build_premium_entities(plain_text, base_ents, momentum_emoji_ids)
                            with open(vid_path, "rb") as vf_data:
                                vid_bytes = vf_data.read()
                            import tempfile as _tf, os as _os
                            tmp_m = _tf.NamedTemporaryFile(delete=False, suffix='.mp4')
                            tmp_m.write(vid_bytes); tmp_m.close()
                            # Send emoji via userbot (no buttons — will add via bot edit below)
                            _sent_ub = await userbot_client.send_file(
                                TARGET_CHANNEL, tmp_m.name,
                                caption=plain_text, formatting_entities=all_ents,
                                supports_streaming=True
                            )
                            try: _os.unlink(tmp_m.name)
                            except Exception: pass
                            try: momentum_msg_id = _sent_ub.id
                            except Exception: pass
                            posted_momentum = True
                            logger.info(f"✅ MOMENTUM ACTIVE (userbot+emoji) posted for @{ch} {x_val}X")
                        except Exception as e_m:
                            logger.warning(f"Momentum userbot send failed: {e_m}")
                    if not posted_momentum:
                        if vid_path and os.path.exists(vid_path):
                            with open(vid_path, "rb") as vf:
                                _sent_fb = await context.bot.send_video(
                                    chat_id=TARGET_CHANNEL, video=vf,
                                    caption=text, parse_mode="HTML",
                                    reply_markup=kb
                                )
                            try: momentum_msg_id = _sent_fb.message_id
                            except Exception: pass
                        else:
                            _sent_tb = await context.bot.send_message(
                                chat_id=TARGET_CHANNEL, text=text,
                                parse_mode="HTML", reply_markup=kb,
                                disable_web_page_preview=True
                            )
                            try: momentum_msg_id = _sent_tb.message_id
                            except Exception: pass
                    # Add buttons via bot edit (works reliably; userbot can't add inline buttons)
                    if momentum_msg_id:
                        try:
                            await context.bot.edit_message_reply_markup(
                                chat_id=TARGET_CHANNEL,
                                message_id=momentum_msg_id,
                                reply_markup=kb
                            )
                            logger.info(f"✅ Buttons added to momentum post {momentum_msg_id}")
                        except Exception as e_kb:
                            logger.warning(f"Momentum button edit failed: {e_kb}")
                    if ch not in momentum_sent: momentum_sent[ch] = {}
                    momentum_sent[ch][str(x_val)] = now.isoformat()
                    save_momentum_sent(momentum_sent)
                    logger.info(f"✅ MOMENTUM ACTIVE posted for @{ch} {x_val}X")
                except Exception as e:
                    logger.error(f"MOMENTUM post failed {ch} {x_val}x: {e}")
    except Exception as e:
        logger.error(f"momentum_check_job crash: {e}")

# ─── Owner only ───────────────────────────────────────────────────────────────
def owner_only(func):
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        uid = update.effective_user.id if update.effective_user else None
        if uid is None or uid not in OWNER_IDS:
            logger.warning(f"owner_only blocked uid={uid} for /{func.__name__} (OWNER_IDS={OWNER_IDS})")
            if update.message:
                await update.message.reply_text("⛔ Owner only.")
            return
        return await func(update, context)
    return wrapper

# ═══════════════════════════════════════════════════════════════════════════════
# PUBLIC COMMANDS
# ═══════════════════════════════════════════════════════════════════════════════

async def _show_xray_report(update: Update, channel: str, x_val: int):
    """Send X-Ray Report for a channel's x_val milestone — called from deep link."""

    # ── Demo / test mode: return fake data for TestKOL so owner can verify UI ──
    if channel.lower() in ("testkol", "test_kol", "demokol"):
        DEMO_RESULTS = [
            {"symbol":"WIZTEST","chain":"SOL","entry":"$45K","ms_mc":"$450K","ca":"DemoSo1ABC123xyz456789","post_id":None},
            {"symbol":"MOONCAT","chain":"ETH","entry":"$80K","ms_mc":"$800K","ca":"0xDemoEth123abc456def789","post_id":None},
            {"symbol":"APEKING","chain":"BNB","entry":"$120K","ms_mc":"$1.2M","ca":"DemoBNB0xabc123","post_id":None},
        ]
        lines = [f"<b>{PE_CRYSTAL} X-Ray Report of @{html.escape(channel)}</b> <i>(Demo)</i>\n"]
        for r in DEMO_RESULTS:
            sym_safe   = html.escape(str(r.get("symbol","TOKEN")))
            chain_safe = html.escape(str(r.get("chain","")))
            entry_safe = html.escape(str(r.get("entry","?")))
            ms_mc_safe = html.escape(str(r.get("ms_mc","?")))
            lines.append(
                f"<b>{PE_CRYSTAL} ${sym_safe} ({chain_safe}) {x_val}X</b>\n"
                f"     {PE_WAND} View Post  |  {entry_safe} {PE_ARROW} {ms_mc_safe}"
            )
        XRAY_FOOTER = (
            f"\n\n\n{PE_CRYSTAL} Early calls. Real results. The track record keeps growing with every successful pick. "
            "Stay early, stay informed. DYOR • NFA"
        )
        caption = "\n\n".join(lines) + XRAY_FOOTER
        CAPTION_LIMIT = 1024
        xray_vids = load_config().get("xray_videos", [])
        if xray_vids:
            ctr = load_config().get("xray_video_counter", 0)
            vid = xray_vids[ctr % len(xray_vids)]
            vid_caption = caption if len(caption) <= CAPTION_LIMIT else caption[:CAPTION_LIMIT-3]+"..."
            try:
                await update.message.reply_video(video=vid["file_id"], caption=vid_caption, parse_mode="HTML")
                return
            except Exception: pass
        if len(caption) <= CAPTION_LIMIT and os.path.exists(VID_XRAY):
            try:
                with open(VID_XRAY, "rb") as vf:
                    await update.message.reply_video(video=vf, caption=caption, parse_mode="HTML")
                return
            except Exception: pass
        await update.message.reply_text(caption, parse_mode="HTML", disable_web_page_preview=True)
        return
    # ── End demo mode ──────────────────────────────────────────────────────────

    results  = []
    seen_cas = set()  # de-duplicate by CA
    for call_key, call in tracked_calls.items():
        if call.get("channel","").lower() != channel.lower(): continue
        # PRIMARY: check sent_milestones (normal path)
        # SECONDARY: check milestone_posts — covers cases where sent_milestones was
        # lost after a /restorenow from an older backup, but WizardScan post IDs survived.
        in_milestones   = x_val in sent_milestones.get(call_key, set())
        post_id         = milestone_posts.get(call_key, {}).get(str(x_val))
        has_post        = bool(post_id)
        if not in_milestones and not has_post:
            continue
        ca = call.get("ca","")
        if ca and ca in seen_cas:
            continue
        if ca:
            seen_cas.add(ca)
        try:
            entry_mc = float(call.get("entry_mc", 0) or 0)
        except (TypeError, ValueError):
            entry_mc = 0.0
        # Compute milestone MC; if entry_mc unknown show "?" not entry price
        ms_mc_fmt = fmt_mc(entry_mc * x_val) if entry_mc > 0 else "?"
        results.append({
            "symbol":  call.get("symbol","TOKEN"),
            "chain":   call.get("chain",""),
            "entry":   call.get("entry_fmt","?"),
            "ms_mc":   ms_mc_fmt,
            "ca":      ca,
            "post_id": post_id,
        })

    # Tertiary fallback: if results still empty, include calls that have ANY recorded
    # milestone >= x_val OR have a milestone_posts entry >= x_val.
    # Covers partial data loss where sent_milestones was lost but WizardScan post IDs survived.
    if not results:
        for call_key, call in tracked_calls.items():
            if call.get("channel","").lower() != channel.lower(): continue
            ca = call.get("ca","")
            if ca and ca in seen_cas: continue
            # Check sent_milestones
            ms_set = sent_milestones.get(call_key, set())
            has_via_milestones = ms_set and max(ms_set) >= x_val
            # ALSO check milestone_posts — works even if sent_milestones is empty after restore
            _ck_posts = milestone_posts.get(call_key, {})
            _valid_posts = {int(k): v for k, v in _ck_posts.items()
                            if v and str(k).lstrip('-').isdigit()}
            has_via_posts = bool(_valid_posts) and max(_valid_posts.keys()) >= x_val
            if not has_via_milestones and not has_via_posts:
                continue
            # Call has a milestone at or above x_val — it definitely passed x_val
            if ca: seen_cas.add(ca)
            try:
                entry_mc = float(call.get("entry_mc", 0) or 0)
            except (TypeError, ValueError):
                entry_mc = 0.0
            ms_mc_fmt = fmt_mc(entry_mc * x_val) if entry_mc > 0 else "?"
            # Find nearest post_id from milestone_posts for this call
            post_id = _valid_posts.get(x_val)
            if not post_id and _valid_posts:
                _nearest = sorted(_valid_posts.items(), key=lambda kv: abs(kv[0] - x_val))
                post_id = _nearest[0][1]
            results.append({
                "symbol":  call.get("symbol","TOKEN"),
                "chain":   call.get("chain",""),
                "entry":   call.get("entry_fmt","?"),
                "ms_mc":   ms_mc_fmt,
                "ca":      ca,
                "post_id": post_id,
            })

    # Quaternary fallback: use last_ratio from any call of this channel that reached x_val
    # This covers cases where sent_milestones AND milestone_posts are both empty (e.g. after
    # a full data wipe) but the call's last_ratio shows it actually hit that level.
    if not results:
        for call_key, call in tracked_calls.items():
            if call.get("channel","").lower() != channel.lower(): continue
            ca = call.get("ca","")
            if ca and ca in seen_cas: continue
            last_r = call.get("last_ratio", 0.0)
            if last_r < x_val:
                continue
            if ca: seen_cas.add(ca)
            try:
                entry_mc = float(call.get("entry_mc", 0) or 0)
            except (TypeError, ValueError):
                entry_mc = 0.0
            ms_mc_fmt = fmt_mc(entry_mc * x_val) if entry_mc > 0 else "?"
            results.append({
                "symbol":  call.get("symbol","TOKEN") or "TOKEN",
                "chain":   call.get("chain",""),
                "entry":   call.get("entry_fmt","?"),
                "ms_mc":   ms_mc_fmt,
                "ca":      ca,
                "post_id": None,
            })

    if not results:
        await update.message.reply_text(
            f"<b>{PE_CRYSTAL} X-Ray Report of @{html.escape(channel)}</b>\n\n"
            f"No {x_val}X calls found for @{html.escape(channel)}.\n\n"
            f"<i>Milestone data may still be building. New {x_val}X calls will appear here automatically.</i>",
            parse_mode="HTML"
        )
        return

    lines = [f"<b>{PE_CRYSTAL} X-Ray Report of @{html.escape(channel)}</b>\n"]
    for r in results:
        view_link  = (f'<a href="https://t.me/WizardScan/{r["post_id"]}">View Post</a>'
                      if r["post_id"] else "View Post")
        ms_mc      = r.get("ms_mc") or r["entry"]
        sym_safe   = html.escape(str(r.get("symbol") or "TOKEN").upper())
        chain_safe = html.escape(str(r.get("chain") or ""))
        entry_safe = html.escape(str(r.get("entry") or "?"))
        ms_mc_safe = html.escape(str(ms_mc or "?"))
        lines.append(
            f"<b>{PE_CRYSTAL} ${sym_safe} ({chain_safe}) {x_val}X</b>\n"
            f"     {PE_WAND} {view_link}  |  {entry_safe} {PE_ARROW} {ms_mc_safe}"
        )
    # Footer added at the end of every X-Ray Report
    XRAY_FOOTER = (
        f"\n\n\n{PE_CRYSTAL} Early calls. Real results. The track record keeps growing with every successful pick. "
        "Stay early, stay informed. DYOR • NFA"
    )
    caption = "\n\n".join(lines) + XRAY_FOOTER
    # Telegram video caption limit = 1024 chars; text message limit = 4096
    CAPTION_LIMIT = 1024
    sent_with_media = False

    # 1) Always try owner-uploaded X-Ray rotating videos first (even if caption is long).
    #    Truncate caption to fit the video limit rather than skipping the video entirely.
    xray_vids = load_config().get("xray_videos", [])
    if xray_vids:
        ctr      = load_config().get("xray_video_counter", 0)
        vid      = xray_vids[ctr % len(xray_vids)]
        next_ctr = (ctr + 1) % len(xray_vids)
        cfg_set("xray_video_counter", next_ctr)
        vid_caption = caption if len(caption) <= CAPTION_LIMIT else caption[:CAPTION_LIMIT - 3] + "..."
        try:
            await update.message.reply_video(
                video=vid["file_id"], caption=vid_caption, parse_mode="HTML"
            )
            sent_with_media = True
        except Exception as e:
            logger.warning(f"xray_video send failed: {e}")

    # 2) Fall back to built-in file if caption fits and no custom video succeeded
    if not sent_with_media and len(caption) <= CAPTION_LIMIT and os.path.exists(VID_XRAY):
        try:
            with open(VID_XRAY, "rb") as vf:
                await update.message.reply_video(video=vf, caption=caption, parse_mode="HTML")
            sent_with_media = True
        except Exception as e:
            logger.warning(f"VID_XRAY send failed: {e}")

    if not sent_with_media:
        # No video available or all video attempts failed — send as text (4096 limit)
        await update.message.reply_text(
            caption, parse_mode="HTML", disable_web_page_preview=True
        )

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user; add_user(user.id, user.username, user.first_name)

    # Handle deep links (e.g. /start xray_channel_100)
    if context.args:
        arg = context.args[0]
        if arg.startswith("xray_"):
            # Safe parser: channel names may contain underscores (e.g. xray_some_kol_100)
            # Scan from the right to find the first all-digit segment → that is the x_val
            raw = arg[5:]  # strip "xray_"
            all_parts = raw.split("_")
            ch_name = ""
            x_str   = ""
            for split_at in range(len(all_parts) - 1, 0, -1):
                candidate_x  = all_parts[split_at]
                candidate_ch = "_".join(all_parts[:split_at])
                if candidate_x.isdigit() and candidate_ch:
                    ch_name, x_str = candidate_ch, candidate_x
                    break
            if ch_name and x_str:
                try:
                    x_val = int(float(x_str))  # handles both "10" and "10.0"
                    await _show_xray_report(update, ch_name, x_val)
                except Exception as e:
                    import traceback
                    tb = traceback.format_exc()
                    logger.error(f"X-Ray deep link error: {e!r} | arg={arg!r}\n{tb}")
                    uid = update.effective_user.id if update.effective_user else 0
                    if uid == OWNER_ID:
                        # Owner: show actual error for debugging
                        await update.message.reply_text(
                            f"⚠️ <b>X-Ray error (owner debug):</b>\n"
                            f"<code>{html.escape(str(e))}</code>\n\n"
                            f"<code>{html.escape(tb[-800:])}</code>",
                            parse_mode="HTML"
                        )
                    else:
                        await update.message.reply_text(
                            f"⚠️ Could not load X-Ray report for @{html.escape(ch_name)}.\n\n"
                            f"Please try again in a moment.",
                            parse_mode="HTML"
                        )
            else:
                await update.message.reply_text(
                    "⚠️ Invalid X-Ray link. Please try again.",
                    parse_mode="HTML"
                )
            return  # Always return after xray_ deep link — never show welcome

    welcome = cfg_get("start_text", DEFAULT_START_TEXT)
    kb      = InlineKeyboardMarkup([[InlineKeyboardButton("🔮 Command 🔮", callback_data="command_menu")]])
    media   = cfg_get("start_media")
    if media and media.get("file_id"):
        fid, ftype = media["file_id"], media.get("type","video")
        try:
            if ftype == "photo": await update.message.reply_photo(photo=fid, caption=welcome, parse_mode="HTML", reply_markup=kb)
            else:                await update.message.reply_video(video=fid, caption=welcome, parse_mode="HTML", reply_markup=kb)
            return
        except Exception as e: logger.error(f"Start media: {e}")
    msg = await send_video_safe(update.message, VID_START, welcome, reply_markup=kb)
    if not msg:
        await update.message.reply_text(welcome, parse_mode="HTML", reply_markup=kb)

async def _send_command_menu(message, context):
    caption  = cfg_get("command_text", DEFAULT_COMMAND_TEXT)
    keyboard = build_command_keyboard()
    media    = cfg_get("command_media")
    sent     = None
    if media and media.get("file_id"):
        fid, ftype = media["file_id"], media.get("type","photo")
        try:
            if ftype == "photo": sent = await message.reply_photo(photo=fid, caption=caption, parse_mode="HTML", reply_markup=keyboard)
            else:                sent = await message.reply_video(video=fid, caption=caption, parse_mode="HTML", reply_markup=keyboard)
        except Exception: pass
    if not sent:
        sent = await message.reply_text(caption, parse_mode="HTML", reply_markup=keyboard)

async def cmd_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user; add_user(u.id, u.username, u.first_name)
    await _send_command_menu(update.message, context)

async def cmd_xcommand(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("ℹ️ X feature hataya gaya hai.")

async def cmd_xlist(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("ℹ️ X feature hataya gaya hai.")

async def cmd_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Dedicated /history @channel command."""
    u = update.effective_user; add_user(u.id, u.username, u.first_name)
    if not context.args:
        msg = await send_photo_safe(update.message, IMG_HISTORY, DEFAULT_HISTORY_INFO)
        if not msg:
            await update.message.reply_text(DEFAULT_HISTORY_INFO, parse_mode="HTML")
        return
    channel  = context.args[0].lstrip("@").strip()
    channels = [c.lower() for c in load_channels()]
    if channel.lower() in channels:
        calls = get_call_history(channel)
        hist  = format_history(channel, calls)
        kb    = history_keyboard(channel)
        cap   = _build_html_caption_for_video(channel, calls)
        hist_media = cfg_get("history_media")
        sent_media = False
        # 1) Try owner-configured history media (file_id — fast, no file I/O)
        if hist_media and hist_media.get("file_id") and len(cap) <= 1024:
            fid   = hist_media["file_id"]
            ftype = hist_media.get("type", "video")
            try:
                if ftype == "photo":
                    await update.message.reply_photo(photo=fid, caption=cap, parse_mode="HTML", reply_markup=kb)
                else:
                    await update.message.reply_video(video=fid, caption=cap, parse_mode="HTML", reply_markup=kb)
                sent_media = True
            except Exception as e:
                logger.warning(f"history_media send failed: {e}")
        # 2) Fall back to built-in VID_HISTORY file
        if not sent_media and os.path.exists(VID_HISTORY) and len(cap) <= 1024:
            try:
                with open(VID_HISTORY, "rb") as vf:
                    await update.message.reply_video(video=vf, caption=cap, parse_mode="HTML", reply_markup=kb)
                sent_media = True
            except Exception:
                pass
        if not sent_media:
            await update.message.reply_text(hist, parse_mode="HTML", reply_markup=kb, disable_web_page_preview=True)
    else:
        await update.message.reply_text(
            f"<b>{PE_CRYSTAL} @{channel}</b>\n\n"
            f"❌ This channel is not currently tracked by Wizard Scan.\n\n"
            f"To request tracking, use: <code>/submit @{channel}</code>\n\n"
            f"For priority review, contact our team below.",
            parse_mode="HTML", reply_markup=CHAT_US_BUTTON)

async def cmd_linkinfo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show /linkme usage explanation."""
    u = update.effective_user; add_user(u.id, u.username, u.first_name)
    msg = await send_photo_safe(update.message, IMG_LINKME, DEFAULT_LINKME_INFO)
    if not msg:
        await update.message.reply_text(DEFAULT_LINKME_INFO, parse_mode="HTML")

async def cmd_submit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user; add_user(user.id, user.username, user.first_name)
    if not context.args:
        btexts = cfg_get("button_texts", {})
        text = btexts.get("kol_request", DEFAULT_KOL_REQUEST)
        kb   = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔮 Fast Track 🔮", callback_data="fast_track")],
            [InlineKeyboardButton("💬 Chat Us",       callback_data="chat_us")],
        ])
        cm   = cfg_get("command_media", {}).get("submit")
        sent = False
        if cm and cm.get("file_id"):
            try:
                fn = update.message.reply_photo if cm.get("type") == "photo" else update.message.reply_video
                await fn(**{("photo" if cm.get("type")=="photo" else "video"): cm["file_id"]},
                         caption=text, parse_mode="HTML", reply_markup=kb)
                sent = True
            except Exception: pass
        if not sent:
            msg = await send_photo_safe(update.message, IMG_KOLREQUEST, text, reply_markup=kb)
            if not msg:
                await update.message.reply_text(text, parse_mode="HTML", reply_markup=kb)
        return
    channel = context.args[0].lstrip("@").strip()
    if not channel: await update.message.reply_text("⚠️ Please provide a valid channel username."); return

    channels = load_channels()
    if channel.lower() in [c.lower() for c in channels]:
        await update.message.reply_text(
            f"✅ <b>@{channel} is already tracked</b> by Wizard Scan!\n\nType <code>@{channel}</code> in the bot to view call history.",
            parse_mode="HTML"); return

    pending = load_pending()
    for req in pending.values():
        if req["channel"].lower() == channel.lower() and req["user_id"] == user.id:
            await update.message.reply_text(
                f"⏳ You already have a pending request for <b>@{channel}</b>.\nPlease wait for our team to review it.",
                parse_mode="HTML"); return

    req_id  = str(uuid.uuid4())[:8]
    username = user.username or f"User#{user.id}"
    pending[req_id] = {"user_id": user.id, "username": username,
                       "channel": channel, "ts": datetime.utcnow().isoformat()}
    save_pending(pending)

    owner_kb = InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ Accept", callback_data=f"kreq|{user.id}|{channel[:28]}"),
        InlineKeyboardButton("❌ Reject",  callback_data=f"krej|{user.id}|{channel[:28]}"),
    ]])
    try:
        await context.bot.send_message(OWNER_ID,
            f"{PE_CRYSTAL} <b>New KOL Tracking Request</b>\n\n"
            f"👤 From: @{username} (ID: <code>{user.id}</code>)\n"
            f"📡 Channel: <b>@{channel}</b>\n"
            f"🕐 Time: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}",
            parse_mode="HTML", reply_markup=owner_kb)
    except Exception as e: logger.error(f"Owner notify: {e}")

    await update.message.reply_text(
        f"📨 <b>Request Submitted!</b>\n\n"
        f"Your request to track <b>@{channel}</b> has been sent to our team.\n\n"
        f"⏳ Review may take 1 day to 1 month depending on the queue.\n\n"
        f"🪄 Want faster approval? Use <b>Fast Track</b> — priority review.\n\nUse /command → Fast Track for details.",
        parse_mode="HTML")

async def cmd_subscribe(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id; add_user(uid, update.effective_user.username, update.effective_user.first_name)
    if not context.args:
        text = (
            "If you want alerts from a specific KOL channel to appear here, send:\n\n"
            "<code>/subscribe @channelname</code>\n\n"
            "Example: <code>/subscribe @SomeCryptoKOL</code>\n\n"
            "Send the same command again to unsubscribe."
        )
        cm   = cfg_get("command_media", {}).get("subscribe")
        sent = False
        if cm and cm.get("file_id"):
            try:
                fn = update.message.reply_photo if cm.get("type") == "photo" else update.message.reply_video
                await fn(**{("photo" if cm.get("type")=="photo" else "video"): cm["file_id"]},
                         caption=text, parse_mode="HTML")
                sent = True
            except Exception: pass
        if not sent:
            await update.message.reply_text(text, parse_mode="HTML")
        return
    channel = context.args[0].lstrip("@").lower()
    subs    = load_channel_subs()
    ch_list = subs.get(channel, [])
    if uid in ch_list:
        ch_list.remove(uid)
        subs[channel] = ch_list
        save_channel_subs(subs)
        await update.message.reply_text(
            f"🔕 <b>Unsubscribed from @{channel}</b>\n\nYou will no longer receive DM alerts for this channel.",
            parse_mode="HTML"
        )
    else:
        ch_list.append(uid)
        subs[channel] = ch_list
        save_channel_subs(subs)
        await update.message.reply_text(
            f"🔔 <b>Subscribed to @{channel}!</b>\n\n"
            f"Every time this KOL hits a milestone, you'll get the alert here in DM.\n\n"
            f"Send <code>/subscribe @{channel}</code> again to disable.",
            parse_mode="HTML"
        )

async def cmd_linkme(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user; add_user(u.id, u.username, u.first_name)
    if not context.args:
        cm   = cfg_get("command_media", {}).get("linkme")
        sent = False
        if cm and cm.get("file_id"):
            try:
                fn = update.message.reply_photo if cm.get("type") == "photo" else update.message.reply_video
                await fn(**{("photo" if cm.get("type")=="photo" else "video"): cm["file_id"]},
                         caption=DEFAULT_LINKME_INFO, parse_mode="HTML")
                sent = True
            except Exception: pass
        if not sent:
            msg = await send_photo_safe(update.message, IMG_LINKME, DEFAULT_LINKME_INFO)
            if not msg:
                await update.message.reply_text(DEFAULT_LINKME_INFO, parse_mode="HTML")
        return

    kol_ch = context.args[0].lstrip("@").lower()
    channels = [c.lower() for c in load_channels()]
    if kol_ch not in channels:
        await update.message.reply_text(
            f"⚠️ <b>@{kol_ch}</b> is not currently tracked by Wizard Scan.\n\n"
            f"Only owners of tracked KOL channels can use /linkme.\n\n"
            f"If you'd like your channel tracked, use: <code>/submit @{kol_ch}</code>",
            parse_mode="HTML"); return

    # Verify the user is actually an admin in the specified channel
    is_admin = False
    try:
        member = await context.bot.get_chat_member(f"@{kol_ch}", u.id)
        if member.status in ("administrator", "creator"):
            is_admin = True
    except Exception:
        pass  # Channel may be private — skip admin check, trust the user

    if not is_admin:
        await update.message.reply_text(
            f"⚠️ You don't appear to be an admin of @{kol_ch}.\n\n"
            f"Please make sure:\n"
            f"1. You are an admin of @{kol_ch}\n"
            f"2. @WIZARD_SCAN_BOT is also added as admin with post permission\n\n"
            f"Then try <code>/linkme @{kol_ch}</code> again.",
            parse_mode="HTML"); return

    # Link: alerts for this KOL channel will also be forwarded INTO the same channel
    linked = load_linked_channels()
    linked[kol_ch] = f"@{kol_ch}"
    save_linked_channels(linked)
    # Store KOL owner for forward DMs on milestones
    kol_owners = load_kol_owners()
    kol_owners[kol_ch] = u.id
    save_kol_owners(kol_owners)

    await update.message.reply_text(
        f"✅ <b>Channel Linked!</b>\n\n"
        f"📡 KOL Channel: @{kol_ch}\n"
        f"📬 Milestone Alerts → @{kol_ch}\n\n"
        f"Whenever a call from @{kol_ch} hits 2X, 5X, 10X, 50X, 100X, the Wizard Scan alert "
        f"will automatically be forwarded to @{kol_ch} so your community sees it instantly.\n\n"
        f"⚠️ Make sure @WIZARD_SCAN_BOT stays as admin in @{kol_ch} with post permission.",
        parse_mode="HTML")
    try:
        await context.bot.send_message(OWNER_ID,
            f"🔗 <b>Channel Linked</b>\n\nKOL: @{kol_ch} (self-forward)\nBy: {u.id} @{u.username or ''}",
            parse_mode="HTML")
    except Exception: pass

# ─── Lookup ───────────────────────────────────────────────────────────────────
async def handle_lookup(update: Update, text: str):
    msg = update.message
    # Twitter/X lookup removed

    tg_match = TG_MENTION_RE.match(text.strip())
    if tg_match:
        channel  = tg_match.group(1)
        channels = [c.lower() for c in load_channels()]
        if channel.lower() in channels:
            calls = get_call_history(channel)
            hist  = format_history(channel, calls)
            kb    = history_keyboard(channel)
            cap   = _build_html_caption_for_video(channel, calls)
            sent_media = False
            # 1) Owner-set history media (same as /history command)
            hist_media = cfg_get("history_media")
            if hist_media and hist_media.get("file_id") and len(cap) <= 1024:
                fid   = hist_media["file_id"]
                ftype = hist_media.get("type", "video")
                try:
                    if ftype == "photo":
                        await msg.reply_photo(photo=fid, caption=cap, parse_mode="HTML", reply_markup=kb)
                    else:
                        await msg.reply_video(video=fid, caption=cap, parse_mode="HTML", reply_markup=kb)
                    sent_media = True
                except Exception as e:
                    logger.warning(f"handle_lookup history_media failed: {e}")
            # 2) Built-in VID_HISTORY fallback
            if not sent_media and os.path.exists(VID_HISTORY) and len(cap) <= 1024:
                try:
                    with open(VID_HISTORY, "rb") as vf:
                        await msg.reply_video(video=vf, caption=cap, parse_mode="HTML", reply_markup=kb)
                    sent_media = True
                except Exception:
                    pass
            if not sent_media:
                await msg.reply_text(hist, parse_mode="HTML", reply_markup=kb, disable_web_page_preview=True)
        else:
            await msg.reply_text(
                f"<b>{PE_CRYSTAL} @{channel}</b>\n\n❌ This channel is not tracked by Wizard Scan.\n\n"
                f"To request tracking: <code>/submit @{channel}</code>\n\nFor priority review, contact our team.",
                parse_mode="HTML", reply_markup=CHAT_US_BUTTON)
        return True
    return False

# ─── Button callbacks ─────────────────────────────────────────────────────────
async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query; await query.answer()
    data  = query.data
    btexts = cfg_get("button_texts", {})

    if data == "command_menu":
        await _send_command_menu(query.message, context)

    elif data == "kol_request":
        text = btexts.get("kol_request", DEFAULT_KOL_REQUEST)
        kb   = InlineKeyboardMarkup([[InlineKeyboardButton("🔮 Fast Track 🔮", callback_data="fast_track")]])
        bm   = cfg_get("button_media", {}).get("kol_request")
        sent = False
        if bm and bm.get("file_id"):
            try:
                fn = query.message.reply_photo if bm.get("type") == "photo" else query.message.reply_video
                await fn(**{("photo" if bm.get("type")=="photo" else "video"): bm["file_id"]},
                         caption=text, parse_mode="HTML", reply_markup=kb)
                sent = True
            except Exception: pass
        if not sent:
            msg = await send_photo_safe(query.message, IMG_KOLREQUEST, text, reply_markup=kb)
            if not msg: await query.message.reply_text(text, parse_mode="HTML", reply_markup=kb)

    elif data == "promo_hub":
        cap = btexts.get("promo_hub", DEFAULT_PROMO_HUB)
        bm  = cfg_get("button_media", {}).get("promo_hub")
        sent = False
        if bm and bm.get("file_id"):
            try:
                fn = query.message.reply_photo if bm.get("type") == "photo" else query.message.reply_video
                await fn(**{("photo" if bm.get("type")=="photo" else "video"): bm["file_id"]},
                         caption=cap, parse_mode="HTML", reply_markup=CONTACT_BUTTONS)
                sent = True
            except Exception: pass
        if not sent:
            msg = await send_photo_safe(query.message, IMG_PROMO, cap, reply_markup=CONTACT_BUTTONS)
            if not msg: await query.message.reply_text(cap, parse_mode="HTML", reply_markup=CONTACT_BUTTONS)

    elif data == "tracked_kols":
        channels = load_channels()
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🔮 MAIN CHANNEL 🔮", url="https://t.me/WizardScan")]])
        bm = cfg_get("button_media", {}).get("tracked_kols")
        if not channels:
            cap_txt = f"<b>{PE_CRYSTAL} TRACKED KOLs (0)</b>\n\nNo channels tracked yet.\n\n<i>Type /history @channelname to see their call history</i>"
            sent = False
            if bm and bm.get("file_id"):
                try:
                    fn = query.message.reply_photo if bm.get("type") == "photo" else query.message.reply_video
                    await fn(**{("photo" if bm.get("type")=="photo" else "video"): bm["file_id"]},
                             caption=cap_txt, parse_mode="HTML", reply_markup=kb)
                    sent = True
                except Exception: pass
            if not sent:
                msg = await send_photo_safe(query.message, IMG_TRACKED, cap_txt, reply_markup=kb)
                if not msg: await query.message.reply_text("No channels tracked yet.", parse_mode="HTML", reply_markup=kb)
        else:
            all_lines = [
                f"{i+1}. <a href='https://t.me/{c}'>@{html.escape(c)}</a>"
                for i, c in enumerate(channels)
            ]
            header1 = f"<b>{PE_CRYSTAL} TRACKED KOLs ({len(channels)})</b>\n\nHall of Tracked KOLs:\n\n"
            footer1 = f"\n\n<i>Type /history @channelname to see their call history</i>"
            # --- first message: photo + caption (max 1024 chars) ---
            first_lines = []
            for line in all_lines:
                if len(header1 + "\n".join(first_lines + [line]) + footer1) <= 1024:
                    first_lines.append(line)
                else:
                    break
            first_caption = header1 + "\n".join(first_lines) + footer1
            sent = False
            if bm and bm.get("file_id"):
                try:
                    fn = query.message.reply_photo if bm.get("type") == "photo" else query.message.reply_video
                    await fn(**{("photo" if bm.get("type")=="photo" else "video"): bm["file_id"]},
                             caption=first_caption, parse_mode="HTML", reply_markup=kb)
                    sent = True
                except Exception: pass
            if not sent:
                msg = await send_photo_safe(query.message, IMG_TRACKED, first_caption, reply_markup=kb)
                if not msg:
                    await query.message.reply_text(first_caption, parse_mode="HTML", reply_markup=kb)
            # --- subsequent messages: text chunks (max 4096 chars) ---
            remaining = all_lines[len(first_lines):]
            chunk_hdr  = "<b>🔮 TRACKED KOLs (continued)</b>\n\n"
            chunk: list = []
            for line in remaining:
                if len(chunk_hdr + "\n".join(chunk + [line])) <= 4096:
                    chunk.append(line)
                else:
                    await query.message.reply_text(
                        chunk_hdr + "\n".join(chunk),
                        parse_mode="HTML", disable_web_page_preview=True)
                    chunk = [line]
            if chunk:
                await query.message.reply_text(
                    chunk_hdr + "\n".join(chunk),
                    parse_mode="HTML", disable_web_page_preview=True)

    elif data == "leaderboard":
        text = btexts.get("leaderboard", DEFAULT_LEADERBOARD)
        kb   = InlineKeyboardMarkup([
            [InlineKeyboardButton("View Leaderboard", url="https://t.me/WizardScan/136")],
            [InlineKeyboardButton("View Champions",   url="https://t.me/WizardScan/137")],
        ])
        bm   = cfg_get("button_media", {}).get("leaderboard")
        sent = False
        if bm and bm.get("file_id"):
            try:
                fn = query.message.reply_photo if bm.get("type") == "photo" else query.message.reply_video
                await fn(**{("photo" if bm.get("type")=="photo" else "video"): bm["file_id"]},
                         caption=text, parse_mode="HTML", reply_markup=kb)
                sent = True
            except Exception: pass
        if not sent:
            msg  = await send_photo_safe(query.message, IMG_LEADERBOARD, text, reply_markup=kb)
            if not msg: await query.message.reply_text(text, parse_mode="HTML", reply_markup=kb)

    elif data == "alert_rules":
        text = btexts.get("alert_rules", DEFAULT_ALERT_RULES)
        msg  = await send_photo_safe(query.message, IMG_ALERT, text)
        if not msg: await query.message.reply_text(text, parse_mode="HTML")

    elif data == "fast_track":
        cap = btexts.get("fast_track", DEFAULT_FAST_TRACK)
        bm  = cfg_get("button_media", {}).get("fast_track")
        sent = False
        if bm and bm.get("file_id"):
            try:
                fn = query.message.reply_photo if bm.get("type") == "photo" else query.message.reply_video
                await fn(**{("photo" if bm.get("type")=="photo" else "video"): bm["file_id"]},
                         caption=cap, parse_mode="HTML", reply_markup=CONTACT_BUTTONS)
                sent = True
            except Exception: pass
        if not sent:
            msg = await send_photo_safe(query.message, IMG_FASTTRACK, cap, reply_markup=CONTACT_BUTTONS)
            if not msg: await query.message.reply_text(cap, parse_mode="HTML", reply_markup=CONTACT_BUTTONS)

    elif data == "chat_us":
        cap = btexts.get("chat_us", DEFAULT_CHAT_US)
        bm  = cfg_get("button_media", {}).get("chat_us")
        sent = False
        if bm and bm.get("file_id"):
            try:
                fn = query.message.reply_photo if bm.get("type") == "photo" else query.message.reply_video
                await fn(**{("photo" if bm.get("type")=="photo" else "video"): bm["file_id"]},
                         caption=cap, parse_mode="HTML", reply_markup=CONTACT_BUTTONS)
                sent = True
            except Exception: pass
        if not sent:
            msg = await send_video_safe(query.message, VID_CHAT_US, cap, reply_markup=CONTACT_BUTTONS)
            if not msg: await query.message.reply_text(cap, parse_mode="HTML", reply_markup=CONTACT_BUTTONS)

    # ── KOL request approve ───────────────────────────────────────────────────
    elif data.startswith("kreq|"):
        _, uid_str, channel = data.split("|", 2)
        uid = int(uid_str)
        channels = load_channels()
        if channel.lower() not in [c.lower() for c in channels]:
            channels.append(channel); save_channels(channels)
        # Store KOL owner for forward DMs on milestones
        kol_owners = load_kol_owners()
        kol_owners[channel.lower()] = uid
        save_kol_owners(kol_owners)
        # Remove from pending so it doesn't show in /pendingkols anymore
        _pending_acc = load_pending()
        _to_del_acc = [k for k, v in _pending_acc.items()
                       if v.get("channel","").lower() == channel.lower() and str(v.get("user_id","")) == uid_str]
        for k in _to_del_acc: del _pending_acc[k]
        if _to_del_acc: save_pending(_pending_acc)
        try:
            await context.bot.send_message(uid,
                f"🎉 <b>Congratulations!</b>\n\n"
                f"Your KOL channel <b>@{channel}</b> has been successfully listed by Wizard Scan.\n\n"
                f"{PE_CRYSTAL} Our system will now monitor all calls from your channel 24/7.\n"
                f"{PE_CRYSTAL} Whenever a call hits a milestone, an alert will be posted in @WizardScan.\n\n"
                f"Welcome to the Wizard Scan family!", parse_mode="HTML")
        except Exception as e: logger.warning(f"DM to {uid} failed: {e}")
        try: await query.message.edit_reply_markup(reply_markup=None)
        except Exception: pass
        await query.message.reply_text(f"✅ <b>@{channel}</b> confirmed and added to tracking!", parse_mode="HTML")

    # ── KOL request reject — show confirm first (prevent accidental rejects) ──
    elif data.startswith("krej|"):
        _, uid_str, channel = data.split("|", 2)
        confirm_kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ Haan, Reject Karo",  callback_data=f"krej_confirm|{uid_str}|{channel}"),
            InlineKeyboardButton("🔙 Cancel",             callback_data="krej_cancel"),
        ]])
        await query.message.reply_text(
            f"⚠️ <b>Confirm Rejection</b>\n\n"
            f"Kya aap sure hain ke <b>@{channel}</b> ko reject karna chahte hain?\n\n"
            f"Yeh action KOL ko DM bheji jaegi.",
            parse_mode="HTML", reply_markup=confirm_kb)

    elif data.startswith("krej_confirm|"):
        _, uid_str, channel = data.split("|", 2)
        uid = int(uid_str)
        fast_kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔮 Fast Track 🔮",      callback_data="fast_track")],
            [InlineKeyboardButton("🔮  Chat With Us  🔮", callback_data="chat_us")],
        ])
        try:
            await context.bot.send_message(uid,
                f"📋 <b>Channel Review Update</b>\n\n"
                f"Your channel <b>@{channel}</b> has been rejected by our team.\n\n"
                f"Please try again. For priority review, contact our team for Fast Track.\n\n"
                f"Thank you.",
                parse_mode="HTML", reply_markup=fast_kb)
        except Exception as e: logger.warning(f"DM to {uid} failed: {e}")
        # Remove from pending so user can re-submit
        _pending = load_pending()
        _to_del = [k for k, v in _pending.items()
                   if v.get("channel","").lower() == channel.lower() and str(v.get("user_id","")) == uid_str]
        for k in _to_del: del _pending[k]
        if _to_del: save_pending(_pending)
        try: await query.message.edit_reply_markup(reply_markup=None)
        except Exception: pass
        await query.message.reply_text(f"❌ <b>@{channel}</b> request rejected.", parse_mode="HTML")

    elif data == "krej_cancel":
        try: await query.message.delete()
        except Exception: pass

    # ── History filter ────────────────────────────────────────────────────────
    elif data.startswith("h|"):
        parts = data.split("|")
        if len(parts) == 3:
            _, channel, filt = parts
            chain_map = {"bnb":"BNB","eth":"ETH","sol":"SOL","base":"BASE","rh":"RH","ton":"TON"}
            is_top = (filt == "top")
            if is_top:         calls = get_call_history(channel, top=True)
            elif filt in chain_map: calls = get_call_history(channel, chain_filter=chain_map[filt])
            else:              calls = get_call_history(channel)
            text = format_history(channel, calls, is_top=is_top)
            kb   = history_keyboard(channel)
            try: await query.message.edit_text(text, parse_mode="HTML", reply_markup=kb, disable_web_page_preview=True)
            except Exception: await query.message.reply_text(text, parse_mode="HTML", reply_markup=kb, disable_web_page_preview=True)

# ═══════════════════════════════════════════════════════════════════════════════
# OWNER COMMANDS
# ═══════════════════════════════════════════════════════════════════════════════

@owner_only
async def cmd_ownerhelp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Part 1 — sent first
    await update.message.reply_text(
        f"{PE_CRYSTAL} <b>OWNER COMMANDS (1/2)</b>\n\n"

        "✏️ <b>Alert Templates</b>\n"
        "/settemplate — template + premium emojis set\n"
        "/edittemplate — sirf text template edit\n"
        "/showtemplate — templates preview\n"
        "/editmilestone 2 — 2X ke liye template\n"
        "/clearmilestone 2 — milestone template remove\n"
        "/listmilestones — milestone status\n"
        "/setmilestones 2,5,10,50 — list change\n\n"

        "🔍 <b>Preview</b>\n"
        "/previewtemplate 100 — 100X alert preview\n"
        "/previewmomentum — MOMENTUM post preview\n\n"

        "🖼️ <b>Milestone Media</b>\n"
        "/setmedia 2 | /clearmedia 2 | /listmedia\n\n"

        "📡 <b>Channels</b>\n"
        "/mychannels | /addchannel @name | /removechannel @name\n\n"

        "🔗 <b>X (Twitter) Handles</b>\n"
        "/addx @channel xhandle — KOL ka X handle set karo\n"
        "/removex @channel — X handle hata do\n\n"

        "👤 <b>Admins</b>\n"
        "/addadmin USER_ID | /removeadmin USER_ID | /listadmins\n\n"

        "🤖 <b>Userbot</b>\n"
        "/userbotlogin | /userbotcheck | /userbotlogout\n\n"

        "👥 <b>Users & Stats</b>\n"
        "/myusers | /mystats | /broadcast\n\n"

        "🔗 <b>Promo Link (12h)</b>\n"
        "/setpromolink | /clearpromolink\n\n"

        "🎬 <b>Momentum Videos</b>\n"
        "/addmomentumvideo | /listmomentumvideos\n"
        "/removemomentumvideo N | /clearmomentumvideos\n\n"

        "🔄 <b>Lists Force Refresh</b>\n"
        "/refreshleaderboard — Leaderboard (136)\n"
        "/refreshchampions — Champions (137)\n"
        "/refreshtrending2 — Trending (3560+3562)\n\n"

        "📌 Aage ke commands: /ownerhelp2",
        parse_mode="HTML"
    )
    # Part 2 — sent immediately after
    await update.message.reply_text(
        f"{PE_CRYSTAL} <b>OWNER COMMANDS (2/2)</b>\n\n"

        "🚫 <b>Trending Blacklist</b>\n"
        "/blocktrending CA | /unblocktrending CA | /listblockedtrending\n\n"

        "🏆 <b>Points (Champion KOL)</b>\n"
        "/givepoints @channel 50 — points do ya kato (-20)\n"
        "/checkpoints @channel | /checkpoints (top 20)\n"
        "/zerocolpoints @channel — sab points zero\n\n"

        "⛔ <b>Call Freeze</b>\n"
        "/freezecall CA | /freezecall @ch CA | /unfreezecall CA\n\n"

        "📡 <b>Missed Call Tracking</b>\n"
        "/addmissedcall @ch CA x [entry_mc] [sym] [tg_link]\n"
        "Example: /addmissedcall @KOL SoABC 100 5K PEPE https://t.me/KOL\n\n"

        "🔧 <b>Call MC Fix</b>\n"
        "/adjustcall @channel CA entry_mc\n\n"

        "📊 <b>Token Check</b>\n"
        "/xcheck @channel CA\n\n"

        "🔔 <b>KOL Owner DM</b>\n"
        "/setkolowner | /setkolownerid @ch ID\n"
        "/removekolowner @ch | /listkolowners\n\n"

        "🔧 <b>Other</b>\n"
        "/testalert | /ownerhelp | /premiumguide\n\n"

        "📌 /ownerhelp2 — aur commands",
        parse_mode="HTML"
    )

@owner_only

@owner_only
async def cmd_setdroppedtemplate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set the 'Dropped a Call' post template."""
    uid = update.effective_user.id
    cur = load_config().get("dropped_call_template", "")
    owner_edit_state[uid] = {"state": ST_DROPPED_TMPL}
    await update.message.reply_text(
        "📋 <b>Dropped a Call Template Setup</b>\n\n"
        "Jab koi KOL pehli baar call kare to jo post channel mein jaye us ka template set karo.\n\n"
        "<b>Available variables:</b>\n"
        "• <code>{channel}</code> → KOL channel name\n"
        "• <code>{symbol}</code> → token symbol\n"
        "• <code>{chain}</code> → blockchain (SOL/ETH/BNB/BASE)\n"
        "• <code>{entry}</code> → entry market cap\n"
        "• <code>{ca}</code> → contract address\n"
        "• <code>{chart_url}</code> → DexScreener chart link\n"
        "• <code>{kol_link}</code> → link to KOL post\n"
        "• <code>{bot_link}</code> → bot link\n\n"
        f"<b>Current template:</b>\n<pre>{html.escape(cur) if cur else '(default)'}</pre>\n\n"
        "New template bhejo ya /cancel karo:",
        parse_mode="HTML"
    )

@owner_only
async def cmd_showdroppedtemplate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show current 'Dropped a Call' template."""
    cur = load_config().get("dropped_call_template", "")
    tmpl = cur if cur else DEFAULT_DROPPED_TEMPLATE
    await update.message.reply_text(
        f"📋 <b>Current Dropped-Call Template:</b>\n\n<pre>{html.escape(tmpl)}</pre>",
        parse_mode="HTML"
    )

@owner_only
async def cmd_cleardroppedtemplate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Reset 'Dropped a Call' template to default."""
    cfg_set("dropped_call_template", "")
    await update.message.reply_text("✅ Dropped-Call template reset — default use hoga.")

@owner_only
async def cmd_adddroppedvideo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Add a video to the Dropped-Call post rotation (up to 20)."""
    vids = load_config().get("dropped_videos", [])
    if len(vids) >= 20:
        await update.message.reply_text(
            "⚠️ Maximum 20 Dropped-Call videos already stored.\n"
            "Use /removedroppedvideo N to remove one first."
        ); return
    owner_edit_state[update.effective_user.id] = {"state": ST_ADD_DROPPED_VID}
    await update.message.reply_text(
        f"🎬 <b>Add Dropped-Call Video</b>\n\n"
        f"Stored: <b>{len(vids)}/20</b>\n\n"
        f"Video bhejo — har 'Dropped a Call' post mein rotate hogi (ya bina video k bhi chale gi).\n"
        f"(/cancel se cancel karo)",
        parse_mode="HTML"
    )

@owner_only
async def cmd_listdroppedvideos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all Dropped-Call rotating videos."""
    vids = load_config().get("dropped_videos", [])
    if not vids:
        await update.message.reply_text(
            "📭 Koi Dropped-Call video store nahi hai.\n\n"
            "Posts abhi text-only hain. /adddroppedvideo se video add karo."
        ); return
    lines = [f"🎬 <b>Dropped-Call Videos ({len(vids)}/20)</b>\n"]
    for i, v in enumerate(vids, 1):
        lines.append(f"<b>{i}.</b> {v.get('type','video')} — <code>{v.get('file_id','?')[:30]}...</code>")
    idx = load_config().get("dropped_video_index", 0)
    lines.append(f"\n⏩ Next video: #{(idx % len(vids)) + 1}")
    lines.append("Use /removedroppedvideo N to remove.")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")

@owner_only
async def cmd_removedroppedvideo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove a Dropped-Call video by number."""
    if not context.args:
        await update.message.reply_text("Usage: /removedroppedvideo <number>"); return
    try: n = int(context.args[0])
    except ValueError:
        await update.message.reply_text("Valid number bhejo."); return
    vids = load_config().get("dropped_videos", [])
    if n < 1 or n > len(vids):
        await update.message.reply_text(f"❌ Invalid. {len(vids)} videos hain."); return
    vids.pop(n - 1)
    cfg_set("dropped_videos", vids)
    await update.message.reply_text(f"✅ Video #{n} hata di. {len(vids)} remaining.")

@owner_only
async def cmd_cleardroppedvideos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Clear all Dropped-Call videos (posts will be text-only)."""
    cfg_set("dropped_videos", [])
    cfg_set("dropped_video_index", 0)
    await update.message.reply_text("✅ Sab Dropped-Call videos hata diye. Posts ab text-only hongi.")

@owner_only
async def cmd_debugscan(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Full pipeline diagnostic — shows exactly where tracking breaks."""
    if update.effective_user.id not in OWNER_IDS:
        return
    uid = update.effective_user.id
    bot = context.bot

    await bot.send_message(uid, "🔍 <b>DEBUG SCAN starting...</b>", parse_mode="HTML")

    # 1. Channels
    channels = load_channels()
    await bot.send_message(uid,
        f"<b>1. Channels tracked:</b> {len(channels)}\n" +
        ("\n".join(f"  • @{c}" for c in channels[:15]) or "  (none)"),
        parse_mode="HTML")

    if not channels:
        await bot.send_message(uid, "❌ No channels — /addchannel karo pehle."); return

    # 2. Fetch posts from first channel
    ch = channels[0]
    await bot.send_message(uid, f"<b>2. Fetching posts from @{ch}...</b>", parse_mode="HTML")
    try:
        posts = await fetch_channel_posts(ch)
    except Exception as e:
        await bot.send_message(uid, f"❌ fetch_channel_posts crashed: {e}"); return

    await bot.send_message(uid,
        f"<b>Posts fetched from @{ch}:</b> {len(posts)}\n"
        f"Seen IDs stored: {len(seen_message_ids.get(ch, set()))}\n"
        f"Sample IDs: {[p['id'] for p in posts[-3:]]}",
        parse_mode="HTML")

    if not posts:
        await bot.send_message(uid,
            "❌ No posts returned — t.me/s scraping fail.\n"
            "Channel private hai ya Telegram ne block kiya?"); return

    # 3. Check last 5 posts for is_call_message / extract_ca
    await bot.send_message(uid, "<b>3. Last 5 posts analysis:</b>", parse_mode="HTML")
    for post in posts[-5:]:
        pid  = post["id"]
        txt  = post["text"][:200].replace("<","&lt;").replace(">","&gt;")
        seen = pid in seen_message_ids.get(ch, set())
        icm  = is_call_message(post["text"])
        ca   = extract_ca(post["text"])
        ck   = f"{ch}_{ca[1]}" if ca else None
        tracked = ck in tracked_calls if ck else False
        await bot.send_message(uid,
            f"<b>Post {pid}</b> {'✅seen' if seen else '🆕new'}\n"
            f"is_call_message: {'✅' if icm else '❌'}\n"
            f"extract_ca: {ca or '❌ none'}\n"
            f"already tracked: {'yes' if tracked else 'no'}\n"
            f"Text: <code>{txt}</code>",
            parse_mode="HTML")

    # 4. Try live dexscreener on first untracked CA we find
    await bot.send_message(uid, "<b>4. Dexscreener test on first new CA...</b>", parse_mode="HTML")
    tested = False
    for post in reversed(posts):
        if not is_call_message(post["text"]): continue
        ca_res = extract_ca(post["text"])
        if not ca_res: continue
        _, ca_addr = ca_res
        ck = f"{ch}_{ca_addr}"
        if ck in tracked_calls: continue
        try:
            dex = await asyncio.wait_for(fetch_dexscreener(ca_addr), timeout=15)
        except asyncio.TimeoutError:
            await bot.send_message(uid, f"❌ Dexscreener TIMEOUT for {ca_addr[:12]}..."); tested=True; break
        except Exception as e:
            await bot.send_message(uid, f"❌ Dexscreener ERROR: {e}"); tested=True; break
        if dex:
            await bot.send_message(uid,
                f"✅ Dexscreener OK: {dex.get('symbol','?')} {dex.get('chain','?')} mcap={dex.get('mcap_fmt','?')}\n"
                f"CA: <code>{ca_addr}</code>",
                parse_mode="HTML")
        else:
            await bot.send_message(uid, f"❌ Dexscreener returned None for <code>{ca_addr}</code>", parse_mode="HTML")
        tested = True; break
    if not tested:
        await bot.send_message(uid, "⚠️ No untracked CAs found in last posts to test dex.")

    # 5. tracked_calls & milestone check
    await bot.send_message(uid,
        f"<b>5. tracked_calls:</b> {len(tracked_calls)} total\n"
        f"<b>sent_milestones:</b> {sum(len(v) for v in sent_milestones.values())} total\n"
        f"<b>userbot connected:</b> {'✅ yes' if userbot_client else '❌ no'}",
        parse_mode="HTML")

    # 6. Config: milestone_media
    cfg = load_config()
    mm = cfg.get("milestone_media", {})
    await bot.send_message(uid,
        f"<b>6. milestone_media keys:</b> {list(mm.keys()) or '(empty — NO ALERTS WILL FIRE)'}\n"
        f"global media: {'✅ set' if mm.get('global') else '❌ not set'}",
        parse_mode="HTML")

    await bot.send_message(uid, "✅ <b>Debug scan complete.</b>", parse_mode="HTML")


@owner_only
async def cmd_testdropped(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Test the Dropped-Call post format."""
    await update.message.reply_text("⏳ Dropped-Call test post bhej raha hoon...")
    try:
        await send_dropped_alert(
            context.bot, "TestKOL", 0,
            "So11111111111111111111111111111111111111111",
            "SOL", "$500K", "TESTTOKEN"
        )
        await update.message.reply_text("✅ Test Dropped-Call post channel mein bhej diya!")
    except Exception as e:
        await update.message.reply_text(f"⚠️ Error: {e}")


@owner_only
async def cmd_backupnow(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manually trigger Telegram backup — sab JSON data Telegram pe bhejo."""
    await update.message.reply_text("⏳ Backup ho raha hai...")
    await backup_data_to_telegram(context.bot)
    await update.message.reply_text(
        "✅ <b>Backup Telegram pe bhej diya!</b>\n\n"
        "<i>Har 5 min mein auto-backup bhi hoti hai. "
        "Bot restart ke baad userbot se data wapas restore ho jaata hai.</i>",
        parse_mode="HTML"
    )

@owner_only
async def _silent_catchup_milestones():
    """After restore, silently mark all already-passed milestones as sent WITHOUT posting alerts.

    Why needed: backup is max 30 min old. Tokens that crossed X milestones in the last
    30 min will NOT be in the restored sent_milestones. On next monitoring_job tick,
    they would fire again — spamming the channel with duplicate/old alerts.

    This function fetches live prices, computes which milestones are already passed,
    and quietly adds them to sent_milestones. No alerts are sent.
    """
    try:
        items = list(tracked_calls.items())
        if not items:
            return
        pre_marked = 0
        milestones_list = get_milestones()
        for call_key, call in items:
            try:
                if call.get("frozen"):
                    continue
                # Use last_ratio if available (from a recent monitoring_job run in memory)
                # Otherwise fetch live from DexScreener
                ratio = call.get("last_ratio", 0)
                if ratio <= 0:
                    # Try DexScreener; skip if unavailable (don't block restore for one token)
                    try:
                        _invalidate_dex_cache(call["ca"])
                        dex = await asyncio.wait_for(fetch_dexscreener(call["ca"]), timeout=10)
                    except Exception:
                        dex = None
                    if dex:
                        entry_price = call.get("entry_price", 0)
                        entry_mc    = call.get("entry_mc", 0)
                        cur_price   = dex.get("price", 0)
                        cur_mc      = dex.get("mcap", 0)
                        if entry_price > 0 and cur_price > 0:
                            ratio = cur_price / entry_price
                        elif entry_mc > 0 and cur_mc > 0:
                            ratio = cur_mc / entry_mc
                if ratio <= 0:
                    continue
                # Mark every milestone that has ALREADY been passed, silently
                for ms in milestones_list:
                    if ms > MAX_MILESTONE:
                        continue
                    if ratio >= ms and ms not in sent_milestones[call_key]:
                        sent_milestones[call_key].add(ms)
                        pre_marked += 1
            except Exception as e:
                logger.warning(f"_silent_catchup {call_key}: {e}")
        if pre_marked:
            _save_milestones()
            logger.info(f"✅ Silent catchup: {pre_marked} already-passed milestones marked (no alerts sent)")
    except Exception as e:
        logger.error(f"_silent_catchup_milestones crash: {e}")


@owner_only
async def cmd_restorenow(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Telegram backup se abhi restore karo — userbot connected hona chahiye."""
    if not userbot_client:
        await update.message.reply_text(
            "❌ <b>Userbot connected nahi hai!</b>\n\n"
            "Pehle userbot connect karo:\n"
            "👉 <code>/userbotlogin</code> bhejo → OTP enter karo\n\n"
            "Phir dobara <code>/restorenow</code> chalao.",
            parse_mode="HTML"
        )
        return
    await update.message.reply_text("⏳ Telegram se backup dhund raha hoon...")
    ok = await restore_data_from_telegram(userbot_client)
    if ok:
        # Run template migrations after every restore so old backups don't
        # bring back X/Twitter lines or wrong template order.
        _migrate_remove_x_from_templates()
        # KEY FIX: silently pre-mark all already-passed milestones so monitoring_job
        # does NOT re-post duplicate alerts for tokens that already crossed X levels.
        status_msg = await update.message.reply_text(
            "⏳ <b>Milestone history sync ho rahi hai...</b>\n"
            "<i>(Yeh step purane duplicate alerts rok ta hai — bas 10-15 seconds...)</i>",
            parse_mode="HTML"
        )
        await _silent_catchup_milestones()
        await status_msg.delete()
        await update.message.reply_text(
            "✅ <b>Restore complete!</b>\n\n"
            "Sab videos, photos, channels, members — sab wapas aa gaye.\n"
            "🔒 <b>Purane milestone alerts block ho gaye</b> — koi duplicate posts nahi jayenge.\n"
            "<i>Ab /listmomentumvideos, /listxrayvideos etc. se check kar sakte ho.</i>",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(
            "⚠️ <b>Koi backup nahi mila.</b>\n\n"
            "Ya to pehle kabhi <code>/backupnow</code> nahi chali, "
            "ya BACKUP_CHAT_ID galat set hai.\n\n"
            f"<i>Abhi BACKUP_CHAT_ID = <code>{BACKUP_CHAT_ID}</code> pe dhund raha tha.</i>",
            parse_mode="HTML"
        )


@owner_only
async def cmd_ownerhelp2(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        f"{PE_CRYSTAL} <b>OWNER COMMANDS — PAGE 2</b>\n\n"

        "💣 <b>KOL Points Reset (Owner Control)</b>\n"
        "/resetallpoints — ⚠️ SAB channels ke points ek saath zero karo\n"
        "  (confirm step bhi hai — galti se nahi hoga)\n"
        "/zerocolpoints @channel — sirf EK channel ke points zero karo\n"
        "/checkpoints — sab channels ke current points dekho\n"
        "/checkpoints @channel — kisi ek channel ke points dekho\n\n"
        "ℹ️ <i>Champions/Leaderboard reset karne se points affect NAHI honge.\n"
        "Points sirf inhi commands se reset honge.</i>\n\n"

        "📣 <b>Dropped-Call Posts (jab KOL pehli baar call kare)</b>\n"
        "/setdroppedtemplate — custom template set karo\n"
        "/showdroppedtemplate — current template dekho\n"
        "/cleardroppedtemplate — default par wapas\n"
        "/adddroppedvideo — video add karo rotation mein (max 20)\n"
        "/listdroppedvideos — stored videos dekho\n"
        "/removedroppedvideo N — video N hata do\n"
        "/cleardroppedvideos — sab videos hata do (text-only)\n"
        "/testdropped — test post bhejo channel mein\n"
        "/joinkols — userbot ko sab KOL channels join karwao (realtime tracking ke liye)\n\n"

        "🔘 <b>Command Button Media (har button ki apni photo/video)</b>\n"
        "/setbuttonmedia BUTTON — button ka media set karo (reply karo)\n"
        "  Buttons: kol_request, promo_hub, tracked_kols, leaderboard, fast_track, chat_us\n"
        "  Example: <code>/setbuttonmedia fast_track</code> (phir video reply karo)\n"
        "/clearbuttonmedia BUTTON — button ka media hata do\n\n"

        "🌐 <b>Public Command Media (/submit /subscribe /linkme)</b>\n"
        "/setcommandmedia COMMAND — public command reply mein photo/video set karo (reply se)\n"
        "  Commands: <code>submit</code>, <code>subscribe</code>, <code>linkme</code>\n"
        "  Example: <code>/setcommandmedia subscribe</code> (phir video reply karo)\n"
        "/clearcommandmedia COMMAND — command ka media hata do\n\n"

        "🎬 <b>X-Ray Report Rotating Videos (1–10)</b>\n"
        "/addxrayvideo — video bhejo, X-Ray report mein rotate hogi\n"
        "/listxrayvideos — stored videos ki list\n"
        "/removexrayvideo N — video N hata do\n"
        "/clearxrayvideos — sab hata do (built-in par wapas)\n\n"

        "📜 <b>History Media</b>\n"
        "/sethistorymedia — /history reply mein photo/video set karo (reply karo)\n"
        "/clearhistorymedia — history media hata do\n\n"

        "🔗 <b>Extra Alert Links (custom links in every alert post)</b>\n"
        "/addpostlink EMOJI_ID TEXT URL — alert mein extra link add karo\n"
        "  Example: <code>/addpostlink 5368324170671202310 ALPHA https://t.me/mychannel</code>\n"
        "/removepostlink N — link N hata do\n"
        "/listpostlinks — current extra links dekho\n\n"

        "ℹ️ Pehle waale commands ke liye: /ownerhelp",
        parse_mode="HTML"
    )

@owner_only
async def cmd_setbuttonmedia(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set a custom photo/video for a specific command button.
    Usage: /setbuttonmedia BUTTON_NAME  (reply to a photo/video)
    Buttons: kol_request, promo_hub, tracked_kols, leaderboard, fast_track, chat_us"""
    VALID_BUTTONS = ["kol_request", "promo_hub", "tracked_kols", "leaderboard", "fast_track", "chat_us"]
    msg = update.message
    if not context.args:
        await msg.reply_text(
            "📸 <b>Button Media Set Karne Ka Tarika:</b>\n\n"
            "1. Photo ya video bhejo is chat mein\n"
            "2. Us media ko reply karo:\n"
            "   <code>/setbuttonmedia BUTTON_NAME</code>\n\n"
            "<b>Available buttons:</b>\n"
            + "\n".join(f"• <code>{b}</code>" for b in VALID_BUTTONS) +
            "\n\nExample: <code>/setbuttonmedia fast_track</code>",
            parse_mode="HTML"
        ); return
    btn = context.args[0].strip().lower()
    if btn not in VALID_BUTTONS:
        await msg.reply_text(
            f"❌ Invalid button: <code>{btn}</code>\n\n"
            f"Valid buttons:\n" + "\n".join(f"• <code>{b}</code>" for b in VALID_BUTTONS),
            parse_mode="HTML"
        ); return
    reply = msg.reply_to_message
    if not reply:
        await msg.reply_text(
            f"📸 Video ya photo ko reply karo <code>/setbuttonmedia {btn}</code> se.",
            parse_mode="HTML"
        ); return
    if reply.video:
        fid = reply.video.file_id; ftype = "video"
    elif reply.photo:
        fid = reply.photo[-1].file_id; ftype = "photo"
    elif reply.document and reply.document.mime_type and reply.document.mime_type.startswith("video"):
        fid = reply.document.file_id; ftype = "video"
    else:
        await msg.reply_text("❌ Sirf video ya photo reply karo."); return
    c = load_config()
    bm = c.get("button_media", {})
    bm[btn] = {"file_id": fid, "type": ftype}
    c["button_media"] = bm
    save_config(c)
    await msg.reply_text(f"✅ <b>{btn}</b> button ka media set ho gaya! ({ftype})", parse_mode="HTML")

@owner_only
async def cmd_clearbuttonmedia(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove custom media from a specific command button."""
    VALID_BUTTONS = ["kol_request", "promo_hub", "tracked_kols", "leaderboard", "fast_track", "chat_us"]
    if not context.args:
        await update.message.reply_text(
            "Usage: <code>/clearbuttonmedia BUTTON_NAME</code>\n\nButtons: " +
            ", ".join(f"<code>{b}</code>" for b in VALID_BUTTONS),
            parse_mode="HTML"
        ); return
    btn = context.args[0].strip().lower()
    c = load_config()
    bm = c.get("button_media", {})
    if btn in bm:
        del bm[btn]
        c["button_media"] = bm
        save_config(c)
        await update.message.reply_text(f"✅ <b>{btn}</b> button ka custom media hata diya.", parse_mode="HTML")
    else:
        await update.message.reply_text(f"ℹ️ <b>{btn}</b> button ka koi custom media nahi tha.", parse_mode="HTML")

@owner_only
async def cmd_addxrayvideo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start flow to add an X-Ray report video (up to 10 rotating)."""
    owner_edit_state[update.effective_user.id] = {"state": ST_ADD_XRAY_VID}
    vids = load_config().get("xray_videos", [])
    await update.message.reply_text(
        f"🎬 <b>Add X-Ray Video</b>\n\n"
        f"Stored X-Ray videos: <b>{len(vids)}/10</b>\n\n"
        f"Jo video bhejein ge woh X-Ray reports mein rotate hogi.\n"
        f"(/cancel se cancel karo)",
        parse_mode="HTML"
    )

@owner_only
async def cmd_listxrayvideos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all stored X-Ray report videos."""
    vids = load_config().get("xray_videos", [])
    if not vids:
        await update.message.reply_text(
            "📭 Koi custom X-Ray video nahi hai.\n\n"
            "Bot built-in VID_XRAY file use kar raha hai.\n"
            "Use /addxrayvideo to upload your own."
        ); return
    lines = [f"🎬 <b>X-Ray Videos ({len(vids)} total)</b>\n"]
    for i, v in enumerate(vids, 1):
        lines.append(f"<b>{i}.</b> {v.get('type','video')} — <code>{v.get('file_id','?')[:30]}...</code>")
    ctr = load_config().get("xray_video_counter", 0)
    lines.append(f"\n⏩ Next video: #{(ctr % len(vids)) + 1}")
    lines.append("Use /removexrayvideo N to remove.")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")

@owner_only
async def cmd_removexrayvideo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove an X-Ray video by position."""
    if not context.args:
        await update.message.reply_text("Usage: /removexrayvideo <number>\nUse /listxrayvideos to see numbers."); return
    try: n = int(context.args[0])
    except ValueError: await update.message.reply_text("Please send a valid number."); return
    vids = load_config().get("xray_videos", [])
    if n < 1 or n > len(vids):
        await update.message.reply_text(f"❌ Invalid number. There are {len(vids)} videos."); return
    vids.pop(n - 1)
    cfg_set("xray_videos", vids)
    await update.message.reply_text(f"✅ X-Ray Video #{n} removed. {len(vids)} videos remaining.")

@owner_only
async def cmd_clearxrayvideos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Clear all stored X-Ray videos (revert to built-in)."""
    cfg_set("xray_videos", [])
    cfg_set("xray_video_counter", 0)
    await update.message.reply_text("✅ Sab X-Ray videos hata diye.\n\nBot ab built-in VID_XRAY file use karega.")

@owner_only
async def cmd_testxray(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Owner: directly test X-Ray Report for any channel + x_val.
    Usage: /testxray @channel 20
    Shows exactly what the X-Ray button would show."""
    if not context.args or len(context.args) < 2:
        await update.message.reply_text(
            "Usage: <code>/testxray @channel X</code>\n"
            "Example: <code>/testxray @klevercalls 20</code>\n\n"
            "Ye command X-Ray Report simulate karta hai bina button click ke.",
            parse_mode="HTML"
        ); return
    channel = context.args[0].lstrip("@")
    try:
        x_val = int(float(context.args[1]))
    except ValueError:
        await update.message.reply_text("❌ X value number hona chahiye. Example: /testxray @klevercalls 20")
        return

    # Debug info first
    ch_calls = [(ck, c) for ck, c in tracked_calls.items() if c.get("channel","").lower() == channel.lower()]
    if not ch_calls:
        await update.message.reply_text(
            f"⚠️ <b>@{channel}</b> ka koi call tracked nahi.\n\n"
            f"Total tracked calls: {len(tracked_calls)}\n"
            f"<i>Channel name check karo — exactly jaisa add kiya tha waisa likhna hoga.</i>",
            parse_mode="HTML"
        ); return

    ms_info = []
    for ck, c in ch_calls:
        ms_list = sorted(sent_milestones.get(ck, set()))
        posts   = milestone_posts.get(ck, {})
        ms_info.append(f"• <code>{ck}</code>\n  Milestones: {ms_list}\n  Posts: {dict(list(posts.items())[:3])}")

    debug_text = (
        f"🔍 <b>Debug: @{channel}</b>\n\n"
        f"Tracked calls: {len(ch_calls)}\n\n"
        + "\n\n".join(ms_info[:5])
        + f"\n\n⏳ Ab {x_val}X X-Ray report generate ho rahi hai..."
    )
    await update.message.reply_text(debug_text[:3000], parse_mode="HTML")

    # Now run the actual X-Ray report
    await _show_xray_report(update, channel, x_val)

@owner_only
async def cmd_sethistorymedia(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Reply to a photo/video → sets it as the /history reply media."""
    msg   = update.message
    reply = msg.reply_to_message
    if not reply:
        await msg.reply_text(
            "📜 <b>History Media Set Karne Ka Tarika:</b>\n\n"
            "1. Photo ya video bhejo is chat mein\n"
            "2. Us media ko reply karo <code>/sethistorymedia</code> se\n\n"
            "Yeh /history @channel reply mein dikhega.",
            parse_mode="HTML"
        ); return
    if reply.video:
        fid = reply.video.file_id; ftype = "video"
    elif reply.photo:
        fid = reply.photo[-1].file_id; ftype = "photo"
    elif reply.document and reply.document.mime_type and reply.document.mime_type.startswith("video"):
        fid = reply.document.file_id; ftype = "video"
    else:
        await msg.reply_text("❌ Sirf video ya photo reply karo."); return
    cfg_set("history_media", {"file_id": fid, "type": ftype})
    await msg.reply_text(f"✅ /history media set ho gaya! ({ftype})", parse_mode="HTML")

@owner_only
async def cmd_clearhistorymedia(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove the custom /history media (revert to built-in VID_HISTORY)."""
    cfg_set("history_media", None)
    await update.message.reply_text("✅ History custom media hata diya. Ab built-in video use hogi.")

@owner_only
async def cmd_setcommandmedia(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/setcommandmedia COMMAND — reply to a photo/video to set media for a public command.
    Supported: submit, subscribe, linkme"""
    VALID_CMDS = ["submit", "subscribe", "linkme"]
    msg = update.message
    if not context.args:
        await msg.reply_text(
            "📸 <b>Public Command Media Set Karne Ka Tarika:</b>\n\n"
            "1. Photo ya video bhejo is chat mein\n"
            "2. Us media ko reply karo:\n"
            "   <code>/setcommandmedia COMMAND</code>\n\n"
            "<b>Available commands:</b>\n"
            + "\n".join(f"• <code>{c}</code> → /{c}" for c in VALID_CMDS) +
            "\n\nExample: <code>/setcommandmedia submit</code> (video reply ke saath)",
            parse_mode="HTML"
        ); return
    cmd = context.args[0].strip().lower().lstrip("/")
    if cmd not in VALID_CMDS:
        await msg.reply_text(
            f"❌ Invalid command: <code>{cmd}</code>\n\n"
            f"Valid options:\n" + "\n".join(f"• <code>{c}</code>" for c in VALID_CMDS),
            parse_mode="HTML"
        ); return
    reply = msg.reply_to_message
    if not reply:
        await msg.reply_text(
            f"📸 Photo ya video ko reply karo <code>/setcommandmedia {cmd}</code> se.",
            parse_mode="HTML"
        ); return
    if reply.video:
        fid = reply.video.file_id; ftype = "video"
    elif reply.photo:
        fid = reply.photo[-1].file_id; ftype = "photo"
    elif reply.document and reply.document.mime_type and reply.document.mime_type.startswith("video"):
        fid = reply.document.file_id; ftype = "video"
    else:
        await msg.reply_text("❌ Sirf video ya photo reply karo."); return
    c = load_config()
    cm = c.get("command_media", {})
    cm[cmd] = {"file_id": fid, "type": ftype}
    c["command_media"] = cm
    save_config(c)
    await msg.reply_text(
        f"✅ <b>/{cmd}</b> command ka media set ho gaya! ({ftype})\n\n"
        f"Ab jab koi <code>/{cmd}</code> use karega, yeh {ftype} dikhegi.",
        parse_mode="HTML"
    )

@owner_only
async def cmd_clearcommandmedia(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/clearcommandmedia COMMAND — remove custom media from a public command."""
    VALID_CMDS = ["submit", "subscribe", "linkme"]
    if not context.args:
        await update.message.reply_text(
            "Usage: <code>/clearcommandmedia COMMAND</code>\n\nCommands: " +
            ", ".join(f"<code>{c}</code>" for c in VALID_CMDS),
            parse_mode="HTML"
        ); return
    cmd = context.args[0].strip().lower().lstrip("/")
    c = load_config()
    cm = c.get("command_media", {})
    if cmd in cm:
        del cm[cmd]
        c["command_media"] = cm
        save_config(c)
        await update.message.reply_text(
            f"✅ <b>/{cmd}</b> ka custom media hata diya. Ab default text/image use hoga.",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(
            f"ℹ️ <b>/{cmd}</b> ka koi custom media nahi tha.",
            parse_mode="HTML"
        )

@owner_only
async def cmd_addpostlink(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Add an extra link to every alert post with a custom premium emoji.
    Usage: /addpostlink EMOJI_ID LINK_TEXT URL
    Example: /addpostlink 5368324170671202310 ALPHA https://t.me/mychannel"""
    if len(context.args) < 3:
        await update.message.reply_text(
            "🔗 <b>Alert Post Extra Link Add Karne Ka Tarika:</b>\n\n"
            "<code>/addpostlink EMOJI_ID LINK_TEXT URL</code>\n\n"
            "Example:\n"
            "<code>/addpostlink 5368324170671202310 ALPHA https://t.me/mychannel</code>\n\n"
            "EMOJI_ID = premium emoji ka ID (/getemoji se hasil karo)\n"
            "LINK_TEXT = button ka text (e.g. ALPHA, SIGNALS, JOIN)\n"
            "URL = link address\n\n"
            "Alert post mein yeh line add hogi:\n"
            "<code>🔮<a href='URL'>LINK_TEXT</a></code>",
            parse_mode="HTML"
        ); return
    try:
        emoji_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("⚠️ EMOJI_ID number hona chahiye. /getemoji se ID nikal lo."); return
    link_text = context.args[1].strip()
    link_url  = context.args[2].strip()
    if not link_url.startswith("http"):
        await update.message.reply_text("⚠️ URL http/https se shuru hona chahiye."); return
    c = load_config()
    links = c.get("extra_post_links", [])
    if len(links) >= 5:
        await update.message.reply_text("⚠️ Maximum 5 extra links allowed. /removepostlink se pehle ek hata do."); return
    links.append({"emoji_id": emoji_id, "text": link_text, "url": link_url})
    c["extra_post_links"] = links
    save_config(c)
    await update.message.reply_text(
        f"✅ <b>Extra Link #{len(links)} Added!</b>\n\n"
        f"Emoji ID: <code>{emoji_id}</code>\n"
        f"Text: {html.escape(link_text)}\n"
        f"URL: {link_url}\n\n"
        f"Ab har alert post mein yeh link dikhega.\n"
        f"Use /listpostlinks to see all · /removepostlink N to remove",
        parse_mode="HTML"
    )

@owner_only
async def cmd_removepostlink(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove an extra post link by number."""
    if not context.args:
        await update.message.reply_text("Usage: /removepostlink <number>\nUse /listpostlinks to see numbers."); return
    try: n = int(context.args[0])
    except ValueError: await update.message.reply_text("Please send a valid number."); return
    links = load_config().get("extra_post_links", [])
    if n < 1 or n > len(links):
        await update.message.reply_text(f"❌ Invalid number. There are {len(links)} links."); return
    removed = links.pop(n - 1)
    cfg_set("extra_post_links", links)
    await update.message.reply_text(
        f"✅ Link #{n} hata diya: <b>{html.escape(removed.get('text',''))}</b>",
        parse_mode="HTML"
    )

@owner_only
async def cmd_listpostlinks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all extra post links."""
    links = load_config().get("extra_post_links", [])
    if not links:
        await update.message.reply_text(
            "📭 Koi extra post link nahi hai.\n\n"
            "Use /addpostlink EMOJI_ID TEXT URL to add one."
        ); return
    lines = [f"🔗 <b>Extra Alert Post Links ({len(links)})</b>\n"]
    for i, lnk in enumerate(links, 1):
        lines.append(
            f"<b>{i}.</b> Emoji: <code>{lnk.get('emoji_id','?')}</code>\n"
            f"     Text: {html.escape(lnk.get('text',''))}\n"
            f"     URL: {lnk.get('url','')}"
        )
    lines.append("\nUse /removepostlink N to remove · /addpostlink to add more")
    await update.message.reply_text("\n\n".join(lines), parse_mode="HTML", disable_web_page_preview=True)

@owner_only
async def cmd_setcommandvideo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Reply to a video/photo → sets it as the /command menu media."""
    msg = update.message
    reply = msg.reply_to_message
    if not reply:
        await msg.reply_text(
            "📹 <b>Command Video Set karne ka tarika:</b>\n\n"
            "1. Apni video forward karo is chat mein\n"
            "2. Us video ko reply karo <code>/setcommandvideo</code> se\n\n"
            "Video /command mein dikhnay lagegi.",
            parse_mode="HTML"
        )
        return
    if reply.video:
        fid = reply.video.file_id; ftype = "video"
    elif reply.photo:
        fid = reply.photo[-1].file_id; ftype = "photo"
    elif reply.document and reply.document.mime_type and reply.document.mime_type.startswith("video"):
        fid = reply.document.file_id; ftype = "video"
    else:
        await msg.reply_text("❌ Sirf video ya photo reply karo."); return
    cfg_set("command_media", {"file_id": fid, "type": ftype})
    await msg.reply_text(f"✅ /command menu video set ho gayi! ({ftype})")

@owner_only
async def cmd_setpromo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set promo template + optional video (reply to video), enables promo every 25 alerts."""
    msg = update.message
    template = " ".join(context.args).strip() if context.args else ""
    if not template:
        await msg.reply_text(
            "📣 <b>Promo Set karne ka tarika:</b>\n\n"
            "<code>/setpromo Apna promo text yahan likhein</code>\n\n"
            "Video ke saath: pehle video bhejo, phir us video ko reply karo "
            "<code>/setpromo Apna text</code> se.\n\n"
            "Promo har <b>25 alerts</b> ke baad @WizardScan mein post hogi.\n"
            "/stoppromo se band karo.",
            parse_mode="HTML"
        )
        return
    c = load_config()
    c["promo_template"] = template
    c["promo_enabled"]  = True
    # Check if replying to video
    reply = msg.reply_to_message
    if reply:
        if reply.video:
            c["promo_video"] = {"file_id": reply.video.file_id, "type": "video"}
        elif reply.photo:
            c["promo_video"] = {"file_id": reply.photo[-1].file_id, "type": "photo"}
        elif reply.document and reply.document.mime_type and reply.document.mime_type.startswith("video"):
            c["promo_video"] = {"file_id": reply.document.file_id, "type": "video"}
    save_config(c)
    vid_status = "✅ Video bhi set ho gayi." if reply and c.get("promo_video") else "ℹ️ Koi video nahi (sirf text post hogi)."
    await msg.reply_text(
        f"✅ <b>Promo Active!</b>\n\n"
        f"Template set ho gaya. Har 25 alerts ke baad @WizardScan mein post hogi.\n\n"
        f"{vid_status}\n\n"
        f"Band karne ke liye: /stoppromo",
        parse_mode="HTML"
    )

@owner_only
async def cmd_stoppromo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Disable the promo post."""
    cfg_set("promo_enabled", False)
    await update.message.reply_text("🔕 Promo band kar diya. Alerts ke baad ab promo post nahi hogi.")

@owner_only
async def cmd_setpromolink(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set a custom text+link for 2X-50X alert posts for 12 hours."""
    uid = update.effective_user.id
    owner_edit_state[uid] = {"state": ST_SETPROMOLINK}
    await update.message.reply_text(
        "🔗 <b>Set Promo Link (12 hours)</b>\n\n"
        "Send your promo text and link in two lines:\n\n"
        "<code>Your custom text here\nhttps://yourlink.com</code>\n\n"
        "This will be appended to all 2X–50X alert posts for 12 hours.",
        parse_mode="HTML"
    )

@owner_only
async def cmd_clearpromolink(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove the active promo link immediately."""
    cfg_set("promo_link", None)
    await update.message.reply_text("✅ Promo link removed from alert posts.")

@owner_only
async def cmd_pendingkols(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show only unreviewed pending KOL requests (not yet accepted/rejected)."""
    pending = load_pending()
    active_channels_lower = {c.lower() for c in load_channels()}
    # Filter to requests whose channel has not been listed yet
    unreviewed = {
        rid: req for rid, req in pending.items()
        if req.get("channel", "").lower() not in active_channels_lower
    }
    if not unreviewed:
        await update.message.reply_text("✅ No unreviewed KOL requests at the moment."); return
    await update.message.reply_text(f"📋 <b>Pending KOL Requests ({len(unreviewed)} unreviewed)</b>", parse_mode="HTML")
    for req_id, req in list(unreviewed.items()):
        uid   = req.get("user_id", "?")
        uname = req.get("username", f"User#{uid}")
        ch    = req.get("channel", "?")
        ts    = req.get("ts", "")[:16]
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ Accept", callback_data=f"kreq|{uid}|{ch[:28]}"),
            InlineKeyboardButton("❌ Reject",  callback_data=f"krej|{uid}|{ch[:28]}"),
        ]])
        await update.message.reply_text(
            f"{PE_CRYSTAL} Channel: <b>@{ch}</b>\n👤 From: @{uname} (ID: <code>{uid}</code>)\n🕐 {ts} UTC",
            parse_mode="HTML", reply_markup=kb)

@owner_only
async def cmd_addmomentumvideo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start flow to add a Momentum Active video."""
    owner_edit_state[update.effective_user.id] = {"state": ST_ADD_MOMENTUM_VID}
    vids = load_config().get("momentum_videos", [])
    await update.message.reply_text(
        f"🎬 <b>Add Momentum Video</b>\n\n"
        f"Current stored videos: <b>{len(vids)}</b>\n\n"
        f"Send the video you want to add to the rotation.\n"
        f"Send /cancel to abort.",
        parse_mode="HTML")

@owner_only
async def cmd_listmomentumvideos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all stored Momentum Active videos."""
    vids = load_config().get("momentum_videos", [])
    if not vids:
        await update.message.reply_text(
            "📭 No custom momentum videos stored.\n\n"
            "Bot is using the 5 built-in rotating videos.\n"
            "Use /addmomentumvideo to upload your own."); return
    lines = [f"🎬 <b>Momentum Videos ({len(vids)} total)</b>\n"]
    for i, v in enumerate(vids, 1):
        fid = v.get("file_id", "?")
        lines.append(f"<b>{i}.</b> {v.get('type','video')} — <code>{fid[:30]}...</code>")
    lines.append("\nUse /removemomentumvideo N to remove by number.")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")

@owner_only
async def cmd_removemomentumvideo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove a Momentum Active video by position."""
    if not context.args:
        await update.message.reply_text("Usage: /removemomentumvideo <number>\nUse /listmomentumvideos to see numbers."); return
    try: n = int(context.args[0])
    except ValueError: await update.message.reply_text("Please send a valid number."); return
    vids = load_config().get("momentum_videos", [])
    if n < 1 or n > len(vids):
        await update.message.reply_text(f"❌ Invalid number. There are {len(vids)} videos."); return
    vids.pop(n - 1)
    cfg_set("momentum_videos", vids)
    await update.message.reply_text(f"✅ Video #{n} removed. {len(vids)} videos remaining.")

@owner_only
async def cmd_clearmomentumvideos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Clear all stored Momentum Active videos (revert to built-in)."""
    cfg_set("momentum_videos", [])
    await update.message.reply_text(
        "✅ All custom momentum videos cleared.\n\n"
        "Bot will now use the 5 built-in rotating videos.")

@owner_only
async def cmd_previewtemplate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Preview what an alert post looks like for a given X value."""
    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text("Usage: /previewtemplate 100\nExample: /previewtemplate 1000")
        return
    x_val = int(context.args[0])
    preview = build_alert(
        channel="DemoKOL", msg_id=1, x_val=x_val, chain="SOL",
        entry_fmt="$5K", current_fmt=f"${x_val*5}K", ca="So1DemoCA1111111111111111111111111111111111", symbol="DEMO"
    )
    await update.message.reply_text(
        f"🔍 <b>Preview — {x_val}X Template:</b>\n\n{preview}",
        parse_mode="HTML", disable_web_page_preview=True
    )

@owner_only
async def cmd_previewmomentum(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Preview a MOMENTUM ACTIVE post in owner DM — bot API only (fast, reliable)."""
    bot_username = (await context.bot.get_me()).username
    xray_url     = f"https://t.me/{bot_username}?start=xray_DemoKOL_10"
    text = (
        "<b>🔮 MOMENTUM ACTIVE 🔮</b>\n\n"
        "<b>@DemoKOL</b> has delivered <b>5</b> calls above <b>10X</b> in the last 7 days.\n\n"
        "Consistent edge. Consistent results. Track the pattern."
    )
    buttons = [
        [InlineKeyboardButton("🔮 KOL Signal", url="https://t.me/WizardScan"),
         InlineKeyboardButton("🔮 KOL Signal", url="https://t.me/WizardScan")],
        [InlineKeyboardButton("🔮 KOL Signal", url="https://t.me/WizardScan"),
         InlineKeyboardButton("🔮 KOL Signal", url="https://t.me/WizardScan")],
        [InlineKeyboardButton("🔮 KOL Signal", url="https://t.me/WizardScan")],
        [InlineKeyboardButton("🔮 X-Ray Report", url=xray_url)],
    ]
    kb = InlineKeyboardMarkup(buttons)

    # Use bot API directly for DM preview (reliable; userbot reserved for channel posts)
    _pcfg    = load_config()
    mom_vids = _pcfg.get("momentum_videos", [])
    sent     = False

    if mom_vids:
        idx     = _pcfg.get("momentum_video_index", 0)
        _mv     = mom_vids[idx % len(mom_vids)]
        vid_fid = _mv.get("file_id")
        ftype   = _mv.get("type", "video")
        if vid_fid:
            try:
                if ftype == "gif":
                    await update.message.reply_animation(animation=vid_fid, caption=text, parse_mode="HTML", reply_markup=kb)
                else:
                    await update.message.reply_video(video=vid_fid, caption=text, parse_mode="HTML", reply_markup=kb)
                sent = True
            except Exception as ep:
                logger.warning(f"previewmomentum video send failed: {ep}")

    if not sent:
        no_vid_note = (
            "\n\n<i>📌 No momentum video set yet.\n"
            "Use /addmomentumvideo to add videos — actual channel posts will include the video.</i>"
        ) if not mom_vids else ""
        await update.message.reply_text(text + no_vid_note, parse_mode="HTML", reply_markup=kb)

@owner_only
async def cmd_testmomentum(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Post N rotating Momentum Active videos to TARGET_CHANNEL. Usage: /testmomentum [count]"""
    args = context.args
    count = 20
    if args:
        try: count = max(1, min(int(args[0]), 30))
        except ValueError: pass

    bot_username = (await context.bot.get_me()).username
    await update.message.reply_text(f"⏳ {count} Momentum Active posts channel pe bhej raha hoon...")

    for i in range(1, count + 1):
        xray_url = f"https://t.me/{bot_username}?start=xray_TestKOL_10"
        text = (
            f"<b>🔮 MOMENTUM ACTIVE 🔮</b>\n\n"
            f"<b>@TestKOL</b> has delivered <b>5</b> calls above <b>10X</b> in the last 7 days.\n\n"
            f"Consistent edge. Consistent results. Track the pattern."
        )
        test_momentum_emoji_ids = [MOMENTUM_ACTIVE_EMOJI_ID, MOMENTUM_ACTIVE_EMOJI_ID]
        # 5 KOL Signal buttons (2 per row) + X-Ray button
        signal_rows = []
        row = []
        for j in range(1, 6):
            row.append(InlineKeyboardButton(
                "🔮 KOL Signal", url=f"https://t.me/WizardScan"
            ))
            if len(row) == 2:
                signal_rows.append(row); row = []
        if row:
            signal_rows.append(row)
        signal_rows.append([InlineKeyboardButton("🔮 X-Ray Report", url=xray_url)])
        kb = InlineKeyboardMarkup(signal_rows)

        _tcfg = load_config()
        momentum_idx = _tcfg.get("momentum_video_index", 0)
        _tmom_vids = _tcfg.get("momentum_videos", [])
        if _tmom_vids:
            _tmv = _tmom_vids[momentum_idx % len(_tmom_vids)]
            cfg_set("momentum_video_index", (momentum_idx + 1) % len(_tmom_vids))
            vid_file_id_t = _tmv.get("file_id"); vid_ftype_t = _tmv.get("type", "video")
            vid_path = None
        else:
            vid_file_id_t = None; vid_ftype_t = None
            vid_path = VID_MOMENTUM_LIST[momentum_idx % len(VID_MOMENTUM_LIST)]
            cfg_set("momentum_video_index", (momentum_idx + 1) % len(VID_MOMENTUM_LIST))

        try:
            posted_test = False
            if vid_file_id_t:
                if userbot_client and test_momentum_emoji_ids:
                    try:
                        sent_t = await _userbot_send_media_with_emoji(
                            context.bot, TARGET_CHANNEL, vid_file_id_t, vid_ftype_t,
                            text, test_momentum_emoji_ids, kb)
                        if sent_t: posted_test = True
                    except Exception as e_fid_t:
                        logger.warning(f"testmomentum userbot file_id failed: {e_fid_t}")
                if not posted_test:
                    await context.bot.send_video(chat_id=TARGET_CHANNEL, video=vid_file_id_t,
                        caption=text, parse_mode="HTML", reply_markup=kb)
                    posted_test = True
            elif userbot_client and vid_path and os.path.exists(vid_path):
                try:
                    from telethon.extensions.html import parse as tl_html_parse
                    from telethon.tl.types import ReplyInlineMarkup, KeyboardButtonRow, KeyboardButtonUrl
                    plain_test, base_test = tl_html_parse(text)
                    all_ents_t = _build_premium_entities(plain_test, base_test, test_momentum_emoji_ids)
                    tl_rows_t = []
                    for row_btns_t in kb.inline_keyboard:
                        tl_row_btns_t = [KeyboardButtonUrl(text=b.text, url=b.url) for b in row_btns_t if b.url]
                        if tl_row_btns_t:
                            tl_rows_t.append(KeyboardButtonRow(buttons=tl_row_btns_t))
                    tl_kb_t = ReplyInlineMarkup(rows=tl_rows_t) if tl_rows_t else None
                    with open(vid_path, "rb") as vf_t:
                        vid_bytes_t = vf_t.read()
                    import tempfile as _tft, os as _ost
                    tmp_t = _tft.NamedTemporaryFile(delete=False, suffix='.mp4')
                    tmp_t.write(vid_bytes_t); tmp_t.close()
                    await userbot_client.send_file(
                        TARGET_CHANNEL, tmp_t.name,
                        caption=plain_test, formatting_entities=all_ents_t,
                        buttons=tl_kb_t, supports_streaming=True
                    )
                    try: _ost.unlink(tmp_t.name)
                    except Exception: pass
                    posted_test = True
                except Exception as e_t:
                    logger.warning(f"testmomentum userbot send failed: {e_t}")
            if not posted_test:
                if vid_path and os.path.exists(vid_path):
                    with open(vid_path, "rb") as vf:
                        await context.bot.send_video(
                            chat_id=TARGET_CHANNEL, video=vf,
                            caption=text, parse_mode="HTML", reply_markup=kb
                        )
                else:
                    await context.bot.send_message(
                        chat_id=TARGET_CHANNEL, text=text,
                        parse_mode="HTML", reply_markup=kb,
                        disable_web_page_preview=True
                    )
            logger.info(f"testmomentum post {i}/{count} — vid_idx={momentum_idx}")
        except Exception as e:
            await update.message.reply_text(f"❌ Post {i} fail: {e}")
            return
        await asyncio.sleep(1)

    await update.message.reply_text(f"✅ {count} posts channel pe bhej diye! Sab 5 videos rotate hoi hain.")

@owner_only
async def cmd_premiumguide(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🌟 <b>PREMIUM EMOJI SETUP GUIDE</b>\n\n"

        "━━━━━━━━━━━━━━━━━━━━\n"
        "📌 <b>STEP 1 — Emoji ID nikalna</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "1️⃣ Telegram mein koi bhi chat kholo\n"
        "2️⃣ Message type karo aur woh premium emoji add karo jo chahiye\n"
        "3️⃣ Us message ko <b>@getidsbot</b> ko forward karo\n"
        "4️⃣ Bot ek lamba reply dega — usme <code>custom_emoji_id</code> wala number copy karo\n\n"
        "Woh number kuch aisa hoga:\n"
        "<code>5368324170671202286</code>\n\n"

        "━━━━━━━━━━━━━━━━━━━━\n"
        "📌 <b>STEP 2 — Range set karna</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "2x se 49x tak ek style:\n"
        "<code>/setalertemoji low 5368324170671202286</code>\n\n"
        "50x aur upar dusra style:\n"
        "<code>/setalertemoji high 5391210377057173506</code>\n\n"
        "Sirf 10x ke liye alag (optional):\n"
        "<code>/setalertemoji 10 5368324170671202286</code>\n\n"

        "━━━━━━━━━━━━━━━━━━━━\n"
        "📌 <b>STEP 3 — Check karo</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "/listalertemojis — sab set emojis dekho\n"
        "/testalert — channel pe test post karo\n\n"

        "━━━━━━━━━━━━━━━━━━━━\n"
        "⚠️ <b>Zaruri baatein</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "• Userbot (premium account) ka connected hona zaruri hai\n"
        "• /userbotcheck se confirm karo ke connected hai\n"
        "• Premium emoji sirf 🔮 wali jagah replace hoti hai post mein\n"
        "• Agar emoji show na ho — userbot ka premium active check karo\n\n"
        "💡 <b>Asaan tarika:</b> Bot ko seedha premium emoji bhejo — /getemoji command se!",
        parse_mode="HTML"
    )

@owner_only
async def cmd_getemoji(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """User premium emoji bhejta hai, bot ID nikal ke deta hai aur set bhi kar deta hai."""
    msg = update.message

    # Check if this is a reply to a message with premium emojis
    target = msg.reply_to_message if msg.reply_to_message else msg

    # Collect all custom emoji IDs from entities
    all_entities = list(target.entities or []) + list(target.caption_entities or [])
    emoji_ids = []
    for ent in all_entities:
        if ent.type == "custom_emoji" and ent.custom_emoji_id:
            if ent.custom_emoji_id not in emoji_ids:
                emoji_ids.append(ent.custom_emoji_id)

    if not emoji_ids:
        await msg.reply_text(
            "🌟 <b>Premium Emoji ID Nikalo</b>\n\n"
            "Aisa karo:\n"
            "1️⃣ Message box mein emoji button dabao\n"
            "2️⃣ ✨ wala star icon dabao — premium emojis aayenge\n"
            "3️⃣ Jo emoji chahiye woh select karo\n"
            "4️⃣ Send karo\n"
            "5️⃣ Us message ko reply karo <code>/getemoji</code> se\n\n"
            "Ya seedha: premium emoji type karo aur bhejo — main ID nikal dunga!",
            parse_mode="HTML"
        )
        return

    lines = []
    for i, eid in enumerate(emoji_ids[:5]):
        lines.append(f"Emoji {i+1}: <code>{eid}</code>")

    # Quick-set buttons — position based
    # pos1 = pehla 🔮 (top line), pos2 = doosra 🔮 (price line), global = sab same
    keyboard_rows = []
    if len(emoji_ids) == 1:
        eid = emoji_ids[0]
        keyboard_rows.append([
            InlineKeyboardButton("1️⃣ Pehla 🔮 (top)", callback_data=f"setemoji:pos1:{eid}"),
            InlineKeyboardButton("2️⃣ Doosra 🔮 (price)", callback_data=f"setemoji:pos2:{eid}"),
        ])
        keyboard_rows.append([
            InlineKeyboardButton("🌍 Dono 🔮 same", callback_data=f"setemoji:global:{eid}"),
        ])
        keyboard_rows.append([
            InlineKeyboardButton("🟢 LOW range (2x–49x)", callback_data=f"setemoji:low:{eid}"),
            InlineKeyboardButton("🔴 HIGH range (50x+)", callback_data=f"setemoji:high:{eid}"),
        ])
    else:
        for i, eid in enumerate(emoji_ids[:2]):
            keyboard_rows.append([
                InlineKeyboardButton(f"Emoji {i+1} → Pos1 (top 🔮)", callback_data=f"setemoji:pos1:{eid}"),
                InlineKeyboardButton(f"Emoji {i+1} → Pos2 (price 🔮)", callback_data=f"setemoji:pos2:{eid}"),
            ])
        keyboard_rows.append([
            InlineKeyboardButton(f"Emoji 1 → LOW", callback_data=f"setemoji:low:{emoji_ids[0]}"),
            InlineKeyboardButton(f"Emoji 1 → HIGH", callback_data=f"setemoji:high:{emoji_ids[0]}"),
        ])

    reply = (
        f"✅ <b>{len(emoji_ids)} premium emoji(s) mili!</b>\n\n"
        + "\n".join(lines) +
        "\n\n<b>Kahan set karna hai? Button dabao:</b>\n"
        "<i>Pos1 = post ka pehla 🔮 | Pos2 = price wala 🔮</i>"
    )
    await msg.reply_text(reply, parse_mode="HTML",
                         reply_markup=InlineKeyboardMarkup(keyboard_rows))

async def cb_setemoji(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Callback: set emoji from getemoji buttons."""
    query = update.callback_query
    await query.answer()
    if not query.from_user or not is_admin_or_owner(query.from_user.id):
        await query.answer("⛔ Sirf admin/owner", show_alert=True); return
    try:
        _, range_key, emoji_id = query.data.split(":", 2)
    except Exception:
        return
    c = load_config()
    emojis = c.get("alert_emoji_ids", {})
    emojis[range_key] = emoji_id
    c["alert_emoji_ids"] = emojis
    save_config(c)
    labels = {
        "low":    "LOW range (2x – 49x)",
        "high":   "HIGH range (50x aur upar)",
        "global": "Dono 🔮 same (global)",
        "pos1":   "Pehla 🔮 position (top line)",
        "pos2":   "Doosra 🔮 position (price line)",
    }
    label = labels.get(range_key, f"{range_key}X")
    await query.edit_message_text(
        f"✅ <b>Premium emoji set!</b>\n\n"
        f"Range: <b>{label}</b>\n"
        f"ID: <code>{emoji_id}</code>\n\n"
        f"Ab channel posts mein 🔮 ki jagah yeh emoji lagegi!\n"
        f"Test karo: /debugemoji",
        parse_mode="HTML"
    )

@owner_only
async def cmd_debugemoji(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a live test to channel with current premium emoji settings."""
    msg = update.message
    c = load_config()
    emojis = c.get("alert_emoji_ids", {})

    if not emojis:
        await msg.reply_text("⚠️ Koi emoji set nahi hai!\nPehle /getemoji use karo.")
        return

    await msg.reply_text(
        f"🔍 <b>Debug info:</b>\n\n"
        f"Saved emojis: <code>{emojis}</code>\n"
        f"Userbot connected: <b>{'✅ Yes' if userbot_client else '❌ No'}</b>\n\n"
        f"Channel pe test post bhej raha hun...",
        parse_mode="HTML"
    )

    # Build a test post text exactly like real alerts
    test_text = (
        "🔮 <b>@TestKOL KOL Hit 2X!</b>\n\n"
        "(<b>$TEST</b>) SOL play called at $10K. Current: $20K.\n\n"
        "Ca: <code>0xTESTCALONLY</code>\n\n"
        "🔮 $10K    🔮    $20K\n\n"
        f"{PE_ARROW} <a href='https://t.me/WizardScan'>KOL</a>\n"
        f"{PE_ARROW} <a href='https://t.me/WizardScan'>TG</a>"
    )

    # Figure out which emoji_id to use (same logic as send_alert)
    range_key = "low"
    base_emoji = emojis.get("global") or emojis.get("low") or emojis.get("high")
    pos1 = emojis.get("pos1") or base_emoji
    pos2 = emojis.get("pos2") or base_emoji
    if pos1 and pos2 and pos1 != pos2:
        emoji_id = [pos1, pos2]
    elif pos1:
        emoji_id = pos1
    elif pos2:
        emoji_id = pos2
    else:
        emoji_id = base_emoji

    await msg.reply_text(f"Using emoji_id: <code>{emoji_id}</code>", parse_mode="HTML")

    if not userbot_client:
        await msg.reply_text(
            "❌ <b>Userbot connected nahi hai!</b>\n\n"
            "Premium emoji ke liye userbot zaroori hai.\n"
            "Type karo: /userbotlogin",
            parse_mode="HTML"
        )
        return

    try:
        from telethon.extensions.html import parse as tl_html_parse
        plain_text, base_ents = tl_html_parse(test_text)
        all_entities = _build_premium_entities(plain_text, base_ents, emoji_id)
        sent = await userbot_client.send_message(
            TARGET_CHANNEL, plain_text,
            formatting_entities=all_entities,
            link_preview=False
        )
        await msg.reply_text(
            f"✅ <b>Test post channel pe bhej diya!</b>\n"
            f"Message ID: <code>{sent.id}</code>\n\n"
            f"Channel check karo — 🔮 ki jagah premium emoji dikhni chahiye!",
            parse_mode="HTML"
        )
    except Exception as e:
        await msg.reply_text(
            f"❌ <b>Error:</b> <code>{e}</code>\n\n"
            f"Yeh error share karo please.",
            parse_mode="HTML"
        )

@owner_only
async def cmd_addadmin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: /addadmin USER_ID"); return
    try:
        uid = int(context.args[0])
    except ValueError:
        await update.message.reply_text("⚠️ USER_ID must be a number."); return
    admins = load_admins()
    if uid in admins:
        await update.message.reply_text(f"ℹ️ {uid} is already an admin."); return
    admins.append(uid); save_admins(admins)
    await update.message.reply_text(f"✅ {uid} added as admin.\n\nAdmin can now use: /setalertemoji /listalertemojis /clearalertemoji /setrankingemojis")

@owner_only
async def cmd_removeadmin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: /removeadmin USER_ID"); return
    try:
        uid = int(context.args[0])
    except ValueError:
        await update.message.reply_text("⚠️ USER_ID must be a number."); return
    admins = load_admins()
    if uid not in admins:
        await update.message.reply_text(f"⚠️ {uid} is not an admin."); return
    admins.remove(uid); save_admins(admins)
    await update.message.reply_text(f"✅ {uid} removed from admins.")

@owner_only
async def cmd_listadmins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    admins = load_admins()
    if not admins:
        await update.message.reply_text("👤 No admins added yet.\n\nUse /addadmin USER_ID"); return
    lines = [f"{i+1}. <code>{uid}</code>" for i, uid in enumerate(admins)]
    await update.message.reply_text(
        f"👤 <b>Admins ({len(admins)})</b>\n\n" + "\n".join(lines), parse_mode="HTML")

@admin_only
async def cmd_setalertemoji(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set premium emoji ID for alert posts. Usage: /setalertemoji <x_val|global|low|high> <EMOJI_ID>"""
    if len(context.args) < 2:
        current = cfg_get("alert_emoji_ids", {})
        def label_key(k):
            if k == "global": return "🌍 global (sab)"
            if k == "low":    return "🟢 low (2x–49x)"
            if k == "high":   return "🔴 high (50x+)"
            return f"⚡ {k}X"
        lines = [f"{label_key(k)}: <code>{v}</code>" for k, v in current.items()]
        await update.message.reply_text(
            "🌟 <b>Alert Emoji IDs</b>\n\n"
            "Usage:\n"
            "<code>/setalertemoji low EMOJI_ID</code> — 2x se 49x tak\n"
            "<code>/setalertemoji high EMOJI_ID</code> — 50x aur upar\n"
            "<code>/setalertemoji global EMOJI_ID</code> — sab ke liye\n"
            "<code>/setalertemoji 10 EMOJI_ID</code> — sirf 10x ke liye\n\n"
            f"<b>Currently set:</b>\n" + ("\n".join(lines) if lines else "<i>None</i>"),
            parse_mode="HTML"); return
    key      = context.args[0].lower().strip()
    emoji_id = context.args[1].strip()
    try: int(emoji_id)
    except ValueError:
        await update.message.reply_text("⚠️ EMOJI_ID sirf numbers hota hai (e.g. 5368324170671202286)."); return
    c = load_config()
    emojis = c.get("alert_emoji_ids", {})
    emojis[key] = emoji_id
    c["alert_emoji_ids"] = emojis
    save_config(c)
    if key == "low":    label = "2x – 49x range"
    elif key == "high": label = "50x aur upar"
    elif key == "global": label = "global (sab posts)"
    else: label = f"{key}X posts"
    await update.message.reply_text(f"✅ Premium emoji set for <b>{label}</b>\n\nID: <code>{emoji_id}</code>", parse_mode="HTML")

@admin_only
async def cmd_listalertemojis(update: Update, context: ContextTypes.DEFAULT_TYPE):
    emojis = cfg_get("alert_emoji_ids", {})
    ranking = cfg_get("ranking_emojis", [])
    lines = [f"{'global' if k == 'global' else k+'X'}: <code>{v}</code>" for k, v in emojis.items()]
    rank_lines = [f"Pos {i+1}: <code>{e}</code>" for i, e in enumerate(ranking) if e]
    text = "🌟 <b>Premium Emoji IDs</b>\n\n"
    text += "<b>Alert Emojis:</b>\n" + ("\n".join(lines) if lines else "<i>None set</i>") + "\n\n"
    text += "<b>Ranking Emojis (post 136):</b>\n" + ("\n".join(rank_lines) if rank_lines else "<i>None set</i>")
    await update.message.reply_text(text, parse_mode="HTML")

@admin_only
async def cmd_clearalertemoji(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: /clearalertemoji <x_val|global>"); return
    key = context.args[0].lower().strip()
    c   = load_config(); emojis = c.get("alert_emoji_ids", {})
    if key not in emojis:
        await update.message.reply_text(f"⚠️ No emoji set for '{key}'."); return
    del emojis[key]; c["alert_emoji_ids"] = emojis; save_config(c)
    await update.message.reply_text(f"✅ Emoji removed for '{key}'.")

@owner_only
async def cmd_addchannel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args: await update.message.reply_text("Usage: /addchannel username"); return
    ch = context.args[0].lstrip("@"); channels = load_channels()
    if ch in channels: await update.message.reply_text(f"@{ch} already tracked."); return
    channels.append(ch); save_channels(channels)
    await update.message.reply_text(f"✅ @{ch} added to tracking. Scanning existing posts to skip old calls...")
    # Pre-populate seen_message_ids so bot only tracks NEW posts from now on
    try:
        posts = await fetch_channel_posts(ch)
        for post in posts:
            seen_message_ids[ch].add(post["id"])
        _save_seen()
        await update.message.reply_text(f"✅ {len(posts)} existing posts marked as seen. Only new posts will be tracked.")
    except Exception as e:
        logger.warning(f"addchannel pre-scan failed for @{ch}: {e}")

    # FIX: Auto-register new channel with realtime Telethon monitoring
    # Without this, the new channel is only polled every 15s instead of getting instant alerts
    global userbot_client
    if userbot_client and userbot_client.is_connected():
        try:
            from telethon import events
            ent = await userbot_client.get_entity(ch)
            # Add to existing realtime handler by re-registering with updated chats list
            # The cleanest way is to add the entity to userbot and re-call setup
            try:
                await userbot_client.get_input_entity(ch)
            except Exception:
                pass
            # Re-run setup to include the new channel in the realtime handler
            await setup_realtime_monitoring(context.bot)
            await update.message.reply_text(
                f"✅ @{ch} realtime monitoring mein register ho gaya (instant tracking active).",
                parse_mode="HTML")
        except Exception as e:
            logger.warning(f"Realtime re-register for @{ch} failed: {e}")
            await update.message.reply_text(
                f"⚠️ Realtime monitoring update fail: {e}\n"
                f"/joinkols run karo taake realtime tracking start ho.",
                parse_mode="HTML")

@owner_only
async def cmd_removechannel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args: await update.message.reply_text("Usage: /removechannel username"); return
    ch_input = context.args[0].lstrip("@"); channels = load_channels()
    # Case-insensitive lookup — stored name kaisa bhi ho
    ch = next((c for c in channels if c.lower() == ch_input.lower()), None)
    if ch is None: await update.message.reply_text(f"@{ch_input} not found."); return
    channels.remove(ch); save_channels(channels)

    ch_lower = ch.lower()

    # Collect all tracked calls for this channel BEFORE removing them
    bl = load_trending_blacklist()
    blocked_cas = []
    removed_call_keys = []
    for call_key, call in list(tracked_calls.items()):
        if call.get("channel", "").lower() != ch_lower: continue
        removed_call_keys.append(call_key)
        ca = call.get("ca", "")
        if ca and ca.lower() not in bl:
            bl.add(ca.lower())
            blocked_cas.append(ca)

    # Remove tracked calls + milestones from memory so monitoring_job stops alerting
    for call_key in removed_call_keys:
        tracked_calls.pop(call_key, None)
        sent_milestones.pop(call_key, None)
        milestone_posts.pop(call_key, None)
    if removed_call_keys:
        _save_tracked()
        _save_milestones()
        _save_milestone_posts()

    # Clear seen message IDs so if channel is re-added it starts fresh
    seen_message_ids.pop(ch_lower, None)
    seen_message_ids.pop(ch, None)
    _save_seen()

    if blocked_cas:
        save_trending_blacklist(bl)

    # Build reply message
    parts = [f"✅ @{ch} removed."]
    if removed_call_keys:
        parts.append(f"🗑 {len(removed_call_keys)} tracked call(s) delete ho gayi — ab koi alert nahi aayega.")
    if blocked_cas:
        parts.append(
            f"⛔ {len(blocked_cas)} token(s) trending se bhi block kar diye gaye:\n"
            + "\n".join(f"  • <code>{ca}</code>" for ca in blocked_cas[:5])
            + ("\n  ..." if len(blocked_cas) > 5 else "")
        )
    await update.message.reply_text("\n\n".join(parts), parse_mode="HTML")

@owner_only
async def cmd_mychannels(update: Update, context: ContextTypes.DEFAULT_TYPE):
    channels = load_channels()
    if not channels: await update.message.reply_text("No channels tracked."); return
    await update.message.reply_text(
        "📡 <b>Tracked Channels:</b>\n\n" + "\n".join(f"{i+1}. @{c}" for i, c in enumerate(channels)),
        parse_mode="HTML")

@owner_only
async def cmd_givepoints(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Give (or take) points to/from a channel manually.
    Usage: /givepoints @channel 50
           /givepoints @channel -20  (to deduct)"""
    if len(context.args) < 2:
        await update.message.reply_text(
            "📊 <b>Points Manually Dene Ka Tarika:</b>\n\n"
            "<code>/givepoints @channelname 50</code> — 50 points do\n"
            "<code>/givepoints @channelname -20</code> — 20 points kato\n\n"
            "100 points milne par channel Champion KOL list mein aa jata hai.",
            parse_mode="HTML"); return
    channel = context.args[0].lstrip("@").strip()
    try:
        amount = int(context.args[1])
    except ValueError:
        await update.message.reply_text("⚠️ Amount number hona chahiye. Example: /givepoints @channel 50"); return
    new_total = await give_manual_points(channel, amount)
    action = f"+{amount}" if amount >= 0 else str(amount)
    await update.message.reply_text(
        f"✅ <b>Points Updated!</b>\n\n"
        f"Channel: @{channel}\n"
        f"Change: <b>{action} points</b>\n"
        f"New Total: <b>{new_total}/{POINTS_FOR_CHAMPION} points</b>\n\n"
        f"{'🏆 Champion KOL list mein aa gaya!' if new_total >= POINTS_FOR_CHAMPION else f'{POINTS_FOR_CHAMPION - new_total} aur points chahiye Champion list ke liye.'}",
        parse_mode="HTML")

@owner_only
async def cmd_checkpoints(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check points for a channel or all channels.
    Usage: /checkpoints @channel  OR  /checkpoints (shows top 20)"""
    if context.args:
        channel = context.args[0].lstrip("@").strip()
        pts = get_channel_points(channel)
        pts_data = load_channel_points()
        entry = pts_data.get(channel.lower(), {})
        awarded_calls = len(entry.get("awarded_tiers", {}))
        deducted_calls = len(entry.get("deducted_calls", []))
        await update.message.reply_text(
            f"📊 <b>Points for @{channel}</b>\n\n"
            f"Total Points: <b>{pts}/{POINTS_FOR_CHAMPION}</b>\n"
            f"Calls with points: {awarded_calls}\n"
            f"Failed calls (deducted): {deducted_calls}\n\n"
            f"{'✅ Champion KOL list mein hai!' if pts >= POINTS_FOR_CHAMPION else f'❌ {POINTS_FOR_CHAMPION - pts} aur points chahiye.'}",
            parse_mode="HTML")
    else:
        pts_data = load_channel_points()
        if not pts_data:
            await update.message.reply_text("📊 Kisi channel ke abhi points nahi hain."); return
        sorted_pts = sorted(
            [(ch, d.get("points", 0)) for ch, d in pts_data.items()],
            key=lambda x: x[1], reverse=True
        )[:20]
        lines = [f"📊 <b>Channel Points (Top 20)</b>\n"]
        for i, (ch, pts) in enumerate(sorted_pts, 1):
            star = "🏆" if pts >= POINTS_FOR_CHAMPION else "  "
            lines.append(f"{star} {i}. @{ch} — <b>{pts}/{POINTS_FOR_CHAMPION}</b>")
        await update.message.reply_text("\n".join(lines), parse_mode="HTML")

@owner_only
async def cmd_zerocolpoints(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Zero out all points for a specific KOL channel.
    Usage: /zerocolpoints @channel"""
    if not context.args:
        await update.message.reply_text(
            "📊 <b>KOL Points Zero Karne Ka Tarika:</b>\n\n"
            "<code>/zerocolpoints @channelname</code>\n\n"
            "This will reset that channel's points, awarded tiers, and deduction history to zero.",
            parse_mode="HTML"); return
    channel = context.args[0].lstrip("@").strip()
    async with _points_lock:
        pts_data = load_channel_points()
        key = channel.lower()
        pts_data[key] = {"points": 0, "awarded_tiers": {}, "deducted_calls": []}
        save_channel_points(pts_data)
    await update.message.reply_text(
        f"✅ <b>Points Reset!</b>\n\n"
        f"@{channel} ke sab points zero kar diye gaye.\n"
        f"Awarded tiers aur deduction history bhi clear ho gayi.",
        parse_mode="HTML")

@owner_only
async def cmd_resetallpoints(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Zero out ALL KOL channels' points at once.
    /resetallpoints          — confirmation maango
    /resetallpoints confirm  — sab points zero karo
    """
    if not context.args or context.args[0].lower() != "confirm":
        pts_data = load_channel_points()
        total_channels = len([ch for ch, d in pts_data.items() if d.get("points", 0) > 0])
        await update.message.reply_text(
            "⚠️ <b>Sab Channels ke Points Reset</b>\n\n"
            f"Abhi <b>{total_channels}</b> channel(s) ke points hain.\n\n"
            "Yeh command <b>SARE</b> KOL channels ke points, awarded tiers, "
            "aur deduction history ek saath zero kar deta hai.\n\n"
            "Confirm karne ke liye:\n<code>/resetallpoints confirm</code>",
            parse_mode="HTML"
        )
        return

    async with _points_lock:
        save_channel_points({})
    await update.message.reply_text(
        "✅ <b>Sab KOL Points Reset!</b>\n\n"
        "Har channel ke points, awarded tiers, aur deduction history zero ho gayi.\n\n"
        "Champion/Leaderboard lists ab refresh hongi — "
        "channels dobara points earn karke wapas ayenge.",
        parse_mode="HTML"
    )


@owner_only
async def cmd_freezecall(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Freeze a tracked call — stop all future milestone alerts for it.
    Usage: /freezecall CA
    Optionally: /freezecall @channel CA  (freeze only that channel's call)"""
    if not context.args:
        await update.message.reply_text(
            "⛔ <b>Call Freeze</b>\n\n"
            "Usage:\n"
            "<code>/freezecall CA</code>\n"
            "<code>/freezecall @channel CA</code>\n\n"
            "Ye command ek suspicious call ke sab future milestone alerts rokh degi.",
            parse_mode="HTML"); return

    if len(context.args) >= 2 and context.args[0].startswith("@"):
        target_channel = context.args[0].lstrip("@").lower()
        ca = context.args[1].strip()
    else:
        target_channel = None
        ca = context.args[0].strip()

    frozen_keys = []
    for call_key, call in tracked_calls.items():
        if call.get("ca", "").lower() != ca.lower(): continue
        if target_channel and call.get("channel", "").lower() != target_channel: continue
        call["frozen"] = True
        frozen_keys.append(f"@{call.get('channel')} — {call.get('symbol','?')}")

    if not frozen_keys:
        await update.message.reply_text(
            f"❌ CA <code>{ca}</code> abhi tracked calls mein nahi mila.\n"
            "Pehle /addmissedcall se add karo, ya CA check karo.",
            parse_mode="HTML"); return

    _save_tracked()
    lines = "\n".join(f"  • {k}" for k in frozen_keys)
    await update.message.reply_text(
        f"⛔ <b>Call Frozen!</b>\n\n{lines}\n\n"
        f"Ab koi milestone alert nahi jayega is call ka.\n"
        f"Unfreeze karne ke liye: <code>/unfreezecall {ca}</code>",
        parse_mode="HTML")


@owner_only
async def cmd_unfreezecall(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unfreeze a previously frozen call — resume milestone alerts.
    Usage: /unfreezecall CA"""
    if not context.args:
        await update.message.reply_text(
            "Usage: <code>/unfreezecall CA</code>",
            parse_mode="HTML"); return

    if len(context.args) >= 2 and context.args[0].startswith("@"):
        target_channel = context.args[0].lstrip("@").lower()
        ca = context.args[1].strip()
    else:
        target_channel = None
        ca = context.args[0].strip()

    unfrozen_keys = []
    for call_key, call in tracked_calls.items():
        if call.get("ca", "").lower() != ca.lower(): continue
        if target_channel and call.get("channel", "").lower() != target_channel: continue
        if call.get("frozen"):
            call.pop("frozen", None)
            unfrozen_keys.append(f"@{call.get('channel')} — {call.get('symbol','?')}")

    if not unfrozen_keys:
        await update.message.reply_text(
            f"❌ <code>{ca}</code> ya toh frozen nahi tha, ya tracked nahi mila.",
            parse_mode="HTML"); return

    _save_tracked()
    lines = "\n".join(f"  • {k}" for k in unfrozen_keys)
    await update.message.reply_text(
        f"✅ <b>Call Unfrozen!</b>\n\n{lines}\n\n"
        f"Ab is call ke milestone alerts phir se jayenge.",
        parse_mode="HTML")


@owner_only
async def cmd_addmissedcall(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manually add a call that the bot missed tracking.
    Usage: /addmissedcall @channel CA x_achieved [entry_mc] [token_name] [kol_tg_link] [chain]
    Example: /addmissedcall @SomeKOL So1ABC...xyz 100
             /addmissedcall @SomeKOL So1ABC...xyz 100 5K PEPE https://t.me/SomeKOL/123 RH
    chain = SOL / ETH / BNB / BASE / RH / TON (optional — auto-detected if not given)"""
    if len(context.args) < 3:
        await update.message.reply_text(
            "📡 <b>Missed Call Add Karne Ka Tarika:</b>\n\n"
            "<code>/addmissedcall @channel CA x_achieved</code>\n"
            "<code>/addmissedcall @channel CA x_achieved entry_mc</code>\n"
            "<code>/addmissedcall @channel CA x_achieved entry_mc token_name kol_tg_link</code>\n"
            "<code>/addmissedcall @channel CA x_achieved entry_mc token_name kol_tg_link chain</code>\n\n"
            "Example:\n"
            "<code>/addmissedcall @SomeKOL So1ABC123xyz 100</code>\n"
            "<code>/addmissedcall @SomeKOL So1ABC123xyz 100 5K</code>\n"
            "<code>/addmissedcall @SomeKOL So1ABC123xyz 100 5K PEPE https://t.me/SomeKOL/123</code>\n"
            "<code>/addmissedcall @SomeKOL 0xABC123... 50 5K DOGE https://t.me/SomeKOL/123 RH</code>\n\n"
            "x_achieved = call kitna x gayi (e.g. 100 matlab 100x)\n"
            "entry_mc (optional) = agar DexScreener fail ho toh manually dein (e.g. 5K)\n"
            "token_name (optional) = token symbol/naam (e.g. PEPE, DOGE)\n"
            "kol_tg_link (optional) = KOL ki original call ka link (e.g. https://t.me/KOL/123)\n"
            "<b>chain (optional)</b> = SOL / ETH / BNB / BASE / RH / TON — agar DexScreener fail ho toh chain specify karen\n\n"
            "💡 RH token ke liye hamesha chain=RH likhein taake galat SOL emojis na aayein.",
            parse_mode="HTML"); return
    channel = context.args[0].lstrip("@").strip()
    ca = context.args[1].strip()
    try:
        x_achieved = int(context.args[2])
    except ValueError:
        await update.message.reply_text("⚠️ x_achieved number hona chahiye. Example: 100"); return
    if x_achieved < 2:
        await update.message.reply_text("⚠️ x_achieved kam se kam 2 hona chahiye."); return

    # Optional 4th argument: manual entry_mc override (for pump.fun / dead tokens)
    manual_entry_mc = 0.0
    if len(context.args) >= 4:
        manual_entry_mc = parse_mc_string(context.args[3])

    # Optional 5th argument: token name / symbol override
    manual_symbol = ""
    if len(context.args) >= 5:
        manual_symbol = context.args[4].strip().upper()

    # Optional 6th argument: KOL Telegram post link override
    manual_kol_tg_link = ""
    if len(context.args) >= 6:
        manual_kol_tg_link = context.args[5].strip()

    # Optional 7th argument: chain override — FIX for wrong chain/emoji bug
    # e.g. RH, SOL, ETH, BNB, BASE, TON
    manual_chain_arg = ""
    _valid_chains = {"SOL", "ETH", "BNB", "BSC", "BASE", "RH", "TON", "EVM"}
    if len(context.args) >= 7:
        _chain_inp = context.args[6].strip().upper()
        if _chain_inp in _valid_chains:
            manual_chain_arg = _chain_inp
        else:
            await update.message.reply_text(
                f"⚠️ Invalid chain: <b>{_chain_inp}</b>\n\n"
                f"Valid chains: SOL, ETH, BNB, BASE, RH, TON\n\n"
                f"Example: <code>/addmissedcall @channel CA 50 5K TOKEN link RH</code>",
                parse_mode="HTML"); return

    # FIX: Auto-detect chain from CA pattern as a best-guess fallback
    def _detect_chain_from_ca(addr: str) -> str:
        """Guess chain from contract address format."""
        if addr.startswith("0x") and len(addr) == 42:
            return "ETH"   # EVM address — ETH/BNB/BASE/RH; DexScreener will narrow it down
        if re.match(r'^(EQ|UQ)[A-Za-z0-9_-]{46}$', addr):
            return "TON"
        # Solana: base58, 32–44 chars, no 0x prefix
        return "SOL"

    channels = load_channels()
    if channel.lower() not in [c.lower() for c in channels]:
        await update.message.reply_text(
            f"⚠️ @{channel} tracked channels mein nahi hai.\n"
            f"Pehle /addchannel {channel} karo."); return

    msg = await update.message.reply_text(f"⏳ DexScreener se {ca[:12]}... ka data fetch ho raha hai...")
    dex = await fetch_dexscreener(ca)
    call_key = f"{channel}_{ca}"

    if dex and dex.get("mcap"):
        entry_mc = dex["mcap"] / x_achieved  # Back-calculate entry MC
        entry_fmt = fmt_mc(entry_mc)
        cur_mc_val = dex["mcap"]
        cur_fmt = fmt_mc(cur_mc_val)
        chain_val = dex["chain"]
        symbol_val = manual_symbol or dex.get("symbol", "UNKNOWN")
        if call_key not in tracked_calls:
            tracked_calls[call_key] = {
                "channel": channel, "msg_id": 0, "ca": ca,
                "chain": chain_val, "entry_mc": entry_mc,
                "entry_price": dex.get("price", 0) / x_achieved if dex.get("price") else 0,
                "entry_fmt": entry_fmt, "symbol": symbol_val,
                "tracked_since": datetime.utcnow().isoformat(),
                **({"kol_tg_link": manual_kol_tg_link} if manual_kol_tg_link else {}),
            }
            _save_tracked()
        else:
            # Update symbol/link even if call was already tracked
            if manual_symbol:   tracked_calls[call_key]["symbol"] = manual_symbol
            if manual_kol_tg_link: tracked_calls[call_key]["kol_tg_link"] = manual_kol_tg_link
            _save_tracked()
    elif manual_entry_mc > 0:
        # Manual entry MC provided — calculate values without DexScreener
        entry_mc  = manual_entry_mc
        entry_fmt = fmt_mc(entry_mc)
        cur_mc_val = entry_mc * x_achieved
        cur_fmt   = fmt_mc(cur_mc_val)
        # FIX: Use manual chain arg first, then auto-detect from CA pattern
        chain_val = manual_chain_arg or _detect_chain_from_ca(ca)
        symbol_val = manual_symbol or "UNKNOWN"
        if call_key not in tracked_calls:
            tracked_calls[call_key] = {
                "channel": channel, "msg_id": 0, "ca": ca,
                "chain": chain_val, "entry_mc": entry_mc, "entry_price": 0,
                "entry_fmt": entry_fmt, "symbol": symbol_val,
                "tracked_since": datetime.utcnow().isoformat(),
                **({"kol_tg_link": manual_kol_tg_link} if manual_kol_tg_link else {}),
            }
            _save_tracked()
        else:
            if manual_chain_arg: tracked_calls[call_key]["chain"] = chain_val
            if manual_symbol:    tracked_calls[call_key]["symbol"] = manual_symbol
            if manual_kol_tg_link: tracked_calls[call_key]["kol_tg_link"] = manual_kol_tg_link
            _save_tracked()
    else:
        # No DexScreener data and no manual MC — warn user
        entry_mc  = 0; entry_fmt = "N/A"; cur_fmt = "N/A"
        # FIX: Use manual chain arg first, then auto-detect from CA pattern
        chain_val = manual_chain_arg or _detect_chain_from_ca(ca)
        symbol_val = manual_symbol or "UNKNOWN"
        if call_key not in tracked_calls:
            tracked_calls[call_key] = {
                "channel": channel, "msg_id": 0, "ca": ca,
                "chain": chain_val, "entry_mc": 0, "entry_price": 0,
                "entry_fmt": entry_fmt, "symbol": symbol_val,
                "tracked_since": datetime.utcnow().isoformat(),
                **({"kol_tg_link": manual_kol_tg_link} if manual_kol_tg_link else {}),
            }
            _save_tracked()
        else:
            if manual_chain_arg: tracked_calls[call_key]["chain"] = chain_val
            if manual_symbol:    tracked_calls[call_key]["symbol"] = manual_symbol
            if manual_kol_tg_link: tracked_calls[call_key]["kol_tg_link"] = manual_kol_tg_link
            _save_tracked()

    # Mark all milestones up to x_achieved as hit
    milestones_to_mark = [m for m in get_milestones() if m <= x_achieved]
    newly_marked = []
    for ms in milestones_to_mark:
        if ms not in sent_milestones[call_key]:
            sent_milestones[call_key].add(ms)
            newly_marked.append(ms)
            await award_points_for_milestone(channel, call_key, ms)
    _save_milestones()

    # Post alert for the x_achieved milestone to main channel
    call_data = tracked_calls[call_key]
    # Also send the initial "Dropped a Call" post to WizardScan channel
    asyncio.create_task(send_dropped_alert(
        context.bot, channel, call_data.get("msg_id", 0), ca,
        call_data.get("chain", chain_val), call_data.get("entry_fmt", "N/A"),
        call_data.get("symbol", "UNKNOWN")
    ))
    asyncio.create_task(send_alert(
        context.bot, channel, call_data.get("msg_id", 0), x_achieved,
        call_data.get("chain", chain_val), call_data.get("entry_fmt", "N/A"),
        cur_fmt, ca, call_data.get("symbol", "UNKNOWN")
    ))

    new_pts = get_channel_points(channel)
    dex_note = ""
    chain_warn = ""
    if not (dex and dex.get("mcap")) and manual_entry_mc <= 0:
        dex_note = "\n\n⚠️ DexScreener data nahi mila. Entry MC N/A hai.\nAgar entry MC pata ho toh yeh use karein:\n<code>/addmissedcall @{} {} {} 5K</code>".format(channel, ca, x_achieved)
        if not manual_chain_arg:
            chain_warn = f"\n\n💡 <b>Chain auto-detect: {chain_val}</b> — Agar chain galat lage (jaise RH token tha lekin SOL dikhaya) toh chain argument add karein:\n<code>/addmissedcall @{channel} {ca} {x_achieved} 5K TOKEN link RH</code>"
    elif not (dex and dex.get("mcap")) and manual_entry_mc > 0:
        dex_note = f"\n\n📌 Manual entry MC use kiya: {entry_fmt}"
        if not manual_chain_arg:
            chain_warn = f"\n\n💡 Chain auto-detect: <b>{chain_val}</b> — Galat lage toh add karein: <code>... {x_achieved} {fmt_mc(entry_mc)} {symbol_val} link {chain_val}</code>"
    await msg.edit_text(
        f"✅ <b>Missed Call Added!</b>\n\n"
        f"Channel: @{channel}\n"
        f"CA: <code>{ca}</code>\n"
        f"Chain: <b>{chain_val}</b>{'  ✅ (manual)' if manual_chain_arg else '  ⚡ (auto-detect)'}\n"
        f"Symbol: {symbol_val}\n"
        f"Entry MC: {entry_fmt} → Current: {cur_fmt}\n"
        f"X Achieved: <b>{x_achieved}X</b>\n"
        f"Milestones Marked: {len(newly_marked)}\n\n"
        f"📊 @{channel} ke ab <b>{new_pts}/{POINTS_FOR_CHAMPION} points</b> hain.{dex_note}{chain_warn}",
        parse_mode="HTML")

@owner_only
async def cmd_adjustcall(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manually fix the entry MC of a tracked call (when bot tracked late).
    Usage: /adjustcall @channel CA entry_mc
    Example: /adjustcall @SomeKOL So1ABC123 100K
    This is useful when the channel called at 100K but bot tracked at 120K+."""
    if len(context.args) < 3:
        await update.message.reply_text(
            "📡 <b>Call Entry MC Fix Karne Ka Tarika:</b>\n\n"
            "<code>/adjustcall @channelname CONTRACT_ADDRESS entry_mc</code>\n\n"
            "Example:\n"
            "<code>/adjustcall @SomeKOL So1ABC123 100K</code>\n"
            "<code>/adjustcall @SomeKOL 0xABC... 50K</code>\n\n"
            "⚠️ Yeh tab use karo jab channel ne call 100K pe ki lekin bot ne 120K+ pe late track ki.\n"
            "entry_mc = woh actual MC jo channel ne call ki thi (e.g. 50K, 100K, 1M, 500000)",
            parse_mode="HTML"); return
    channel = context.args[0].lstrip("@").strip().lower()
    ca = context.args[1].strip()
    new_entry_mc = parse_mc_string(context.args[2])
    if new_entry_mc <= 0:
        await update.message.reply_text("⚠️ Valid entry MC dain. Example: 100K, 1M, 500000"); return

    call_key = f"{channel}_{ca}"
    if call_key not in tracked_calls:
        # Try case-insensitive search
        found_key = next((k for k in tracked_calls if k.lower() == call_key.lower()), None)
        if found_key:
            call_key = found_key
        else:
            await update.message.reply_text(
                f"⚠️ Yeh call tracked nahi hai: @{channel} / {ca[:16]}...\n\n"
                "Pehle /addmissedcall se add karo.", parse_mode="HTML"); return

    call = tracked_calls[call_key]
    old_entry_fmt = call.get("entry_fmt", "N/A")
    old_entry_mc  = call.get("entry_mc", 0)

    # Update entry MC and recalculate entry_fmt
    call["entry_mc"]  = new_entry_mc
    call["entry_fmt"] = fmt_mc(new_entry_mc)
    if call.get("entry_price", 0) > 0:
        # Also scale entry_price proportionally
        if old_entry_mc > 0:
            ratio = new_entry_mc / old_entry_mc
            call["entry_price"] = call["entry_price"] * ratio

    _save_tracked()
    await update.message.reply_text(
        f"✅ <b>Entry MC Updated!</b>\n\n"
        f"Channel: @{call.get('channel', channel)}\n"
        f"CA: <code>{ca}</code>\n"
        f"Symbol: {call.get('symbol','UNKNOWN')}\n"
        f"Old Entry MC: <b>{old_entry_fmt}</b>\n"
        f"New Entry MC: <b>{call['entry_fmt']}</b>\n\n"
        f"Ab se milestones is nayi entry MC se calculate honge.",
        parse_mode="HTML")

@owner_only
async def cmd_setkolowner(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set which Telegram user gets DM alerts for a KOL channel.
    Multi-step: bot asks for channel name then user username.
    Or direct: /setkolowner @channel @user"""
    uid = update.effective_user.id
    # Direct usage: /setkolowner @channel @user
    if len(context.args) >= 2:
        ch_input   = context.args[0].lstrip("@").strip().lower()
        user_input = context.args[1].lstrip("@").strip()
        channels = load_channels()
        if ch_input not in [c.lower() for c in channels]:
            await update.message.reply_text(
                f"⚠️ @{ch_input} tracked nahi hai. Pehle /addchannel karo."); return
        d = load_users_dict()
        found_id = None
        for uid_str, udata in d.items():
            if (udata.get("username") or "").lower() == user_input.lower():
                found_id = int(uid_str)
                break
        if not found_id:
            await update.message.reply_text(
                f"⚠️ @{user_input} ka ID nahi mila.\n\n"
                f"User ne pehle bot pe /start karna chahiye.\n\n"
                f"Agar numeric ID pata ho:\n"
                f"<code>/setkolownerid {ch_input} NUMERIC_ID</code>",
                parse_mode="HTML"); return
        kol_owners = load_kol_owners()
        kol_owners[ch_input] = found_id
        save_kol_owners(kol_owners)
        await update.message.reply_text(
            f"✅ <b>KOL Owner Set!</b>\n\n"
            f"Channel: @{ch_input}\n"
            f"Owner: @{user_input} (ID: {found_id})\n\n"
            f"Ab se @{ch_input} ki sab call milestones directly @{user_input} ke DM mein jaengi.",
            parse_mode="HTML"); return
    # Interactive multi-step flow
    owner_edit_state[uid] = {"state": ST_SETKOLOWNER_CH}
    await update.message.reply_text(
        "🔔 <b>KOL Call Alert Setup</b>\n\n"
        "Step 1/2: Kaunse channel ki calls ka alert set karna hai?\n\n"
        "Channel ka username bhejo (e.g. @ChannelName):",
        parse_mode="HTML")

@owner_only
async def cmd_setkolownerid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set KOL owner by direct Telegram user ID (when username lookup fails).
    Usage: /setkolownerid @channel NUMERIC_USER_ID"""
    if len(context.args) < 2:
        await update.message.reply_text(
            "Usage: <code>/setkolownerid @channel NUMERIC_USER_ID</code>\n\n"
            "Example: <code>/setkolownerid SomeKOL 123456789</code>",
            parse_mode="HTML"); return
    ch_input = context.args[0].lstrip("@").strip().lower()
    try:
        user_id = int(context.args[1])
    except ValueError:
        await update.message.reply_text("⚠️ User ID numeric hona chahiye."); return
    channels = load_channels()
    if ch_input not in [c.lower() for c in channels]:
        await update.message.reply_text(
            f"⚠️ @{ch_input} tracked nahi hai."); return
    kol_owners = load_kol_owners()
    kol_owners[ch_input] = user_id
    save_kol_owners(kol_owners)
    await update.message.reply_text(
        f"✅ <b>KOL Owner Set!</b>\n\n"
        f"Channel: @{ch_input}\n"
        f"User ID: <code>{user_id}</code>\n\n"
        f"Ab se @{ch_input} ki sab call milestones is user ke DM mein jaengi.",
        parse_mode="HTML")

@owner_only
async def cmd_removekolowner(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove KOL owner mapping for a channel.
    Usage: /removekolowner @channel"""
    if not context.args:
        await update.message.reply_text(
            "Usage: <code>/removekolowner @channel</code>", parse_mode="HTML"); return
    ch_input = context.args[0].lstrip("@").strip().lower()
    kol_owners = load_kol_owners()
    if ch_input in kol_owners:
        del kol_owners[ch_input]
        save_kol_owners(kol_owners)
        await update.message.reply_text(f"✅ @{ch_input} ka KOL owner mapping hata diya gaya.")
    else:
        await update.message.reply_text(f"⚠️ @{ch_input} ka koi owner set nahi tha.")

@owner_only
async def cmd_listkolowners(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all KOL channel → owner mappings."""
    kol_owners = load_kol_owners()
    if not kol_owners:
        await update.message.reply_text("ℹ️ Koi KOL owner set nahi hai."); return
    d = load_users_dict()
    # Build reverse username lookup
    id_to_uname = {int(uid): udata.get("username","") for uid, udata in d.items()}
    lines = ["🔔 <b>KOL Owner Mappings</b>\n"]
    for ch, owner_id in sorted(kol_owners.items()):
        uname = id_to_uname.get(owner_id, "")
        uname_str = f"@{uname}" if uname else f"ID:{owner_id}"
        lines.append(f"• @{ch} → {uname_str}")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")

@owner_only
async def cmd_xcheck(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check how much a token has moved since it was shared in a channel.
    Usage: /xcheck @channel CA
    Example: /xcheck @SomeKOL So1ABC123xyz
    Shows: when the call was made, entry MC, current MC, and how many X it went."""
    if len(context.args) < 2:
        await update.message.reply_text(
            "📊 <b>Token Performance Check</b>\n\n"
            "Usage: <code>/xcheck @channel CA</code>\n\n"
            "Example:\n"
            "<code>/xcheck @SomeKOL So1ABC123xyz</code>\n\n"
            "Yeh batayega:\n"
            "• Call kab ki gayi thi\n"
            "• Entry MC kya tha\n"
            "• Abhi MC kitna hai\n"
            "• Kitne X ho gaya",
            parse_mode="HTML"); return
    channel = context.args[0].lstrip("@").strip().lower()
    ca = context.args[1].strip()
    call_key = f"{channel}_{ca}"
    # Try case-insensitive search
    if call_key not in tracked_calls:
        found_key = next((k for k in tracked_calls if k.lower() == call_key.lower()), None)
        if found_key:
            call_key = found_key
    if call_key not in tracked_calls:
        await update.message.reply_text(
            f"⚠️ Yeh call tracked nahi hai.\n\n"
            f"Channel: @{channel}\nCA: <code>{ca[:20]}...</code>",
            parse_mode="HTML"); return
    call = tracked_calls[call_key]
    msg = await update.message.reply_text("⏳ Current data fetch ho raha hai...")
    dex = await fetch_dexscreener(ca)
    entry_mc  = call.get("entry_mc", 0)
    entry_fmt = call.get("entry_fmt", "N/A")
    symbol    = (call.get("symbol","") or "TOKEN").upper()
    chain     = call.get("chain","SOL")
    tracked_since = call.get("tracked_since","")
    # Calculate time since call
    time_str = "N/A"
    if tracked_since:
        try:
            ts_dt = datetime.fromisoformat(tracked_since)
            delta = datetime.utcnow() - ts_dt
            hours = int(delta.total_seconds() // 3600)
            mins  = int((delta.total_seconds() % 3600) // 60)
            if hours >= 24:
                days = hours // 24
                time_str = f"{days}d {hours%24}h ago"
            elif hours > 0:
                time_str = f"{hours}h {mins}m ago"
            else:
                time_str = f"{mins}m ago"
        except Exception:
            time_str = "N/A"
    cur_mc_fmt = "N/A"
    x_val_str  = "N/A"
    if dex and dex.get("mcap", 0) > 0:
        cur_mc = dex["mcap"]
        cur_mc_fmt = dex.get("mcap_fmt", fmt_mc(cur_mc))
        if entry_mc > 0:
            x_val = cur_mc / entry_mc
            x_val_str = fmt_x(x_val)
    # Best milestone hit so far
    milestones_hit = sorted(sent_milestones.get(call_key, set()))
    best_x_str = f"{max(milestones_hit)}X" if milestones_hit else "Not hit yet"
    dex_path   = CHAIN_TO_DEXPATH.get(chain.upper(), "ethereum")
    chart_url  = f"https://dexscreener.com/{dex_path}/{ca}"
    await msg.edit_text(
        f"📊 <b>@{channel} — ${symbol}</b>\n\n"
        f"⏱ Called: <b>{time_str}</b>\n"
        f"⛓ Chain: <b>{chain}</b>\n"
        f"📌 Entry MC: <b>{entry_fmt}</b>\n"
        f"💰 Current MC: <b>{cur_mc_fmt}</b>\n"
        f"📈 Current X: <b>{x_val_str}</b>\n"
        f"🏆 Best Milestone: <b>{best_x_str}</b>\n\n"
        f"CA: <code>{ca}</code>\n"
        f'<a href="{chart_url}">📊 Chart</a>',
        parse_mode="HTML", disable_web_page_preview=True)

@owner_only
async def cmd_addx(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set X/Twitter handle for a KOL channel.
    Usage: /addx @channel xhandle
    Example: /addx @SomeKOL WizardScan
    What it does: Adds a clickable X (Twitter) link next to the KOL's name in:
      • Post 136 (Leaderboard) — KOL name ke saath 𝕏 icon
      • Post 137 (Champions)   — KOL name ke saath 𝕏 icon
    Viewers can click to go directly to the KOL's X profile."""
    if len(context.args) < 2:
        await update.message.reply_text(
            "📋 <b>X Handle Set Karne Ka Tarika:</b>\n\n"
            "<code>/addx @channel xhandle</code>\n\n"
            "Example:\n<code>/addx @SomeKOL WizardScan</code>\n\n"
            "Handle @ ke bina likhain (e.g. WizardScan, not @WizardScan)\n\n"
            "━━━━━━━━━━━━━━━\n"
            "💡 <b>Yeh kya karta hai?</b>\n\n"
            "Jab yeh set hota hai toh post 136 (Leaderboard) aur post 137 (Champions) mein "
            "KOL ke naam ke saath ek <b>𝕏</b> icon appear hota hai. "
            "Viewers us par click karke directly KOL ka X (Twitter) profile dekh sakte hain.\n\n"
            "Use /xlist to see all set X handles.",
            parse_mode="HTML"); return
    channel = context.args[0].lstrip("@").strip().lower()
    handle  = context.args[1].lstrip("@").strip()
    if not channel or not handle:
        await update.message.reply_text("⚠️ Channel aur X handle dono dain."); return
    x_acc = load_x_accounts()
    x_acc[channel] = handle
    save_x_accounts(x_acc)
    await update.message.reply_text(
        f"✅ <b>X Handle Set!</b>\n\n"
        f"Channel: @{channel}\n"
        f"X: <a href=\"https://x.com/{html.escape(handle)}\">@{html.escape(handle)}</a>\n\n"
        f"<b>Kya hoga ab:</b>\n"
        f"• Post 136 (Leaderboard) mein @{channel} ke naam ke saath <b>𝕏</b> link aayega\n"
        f"• Post 137 (Champions) mein bhi <b>𝕏</b> link aayega\n"
        f"• Viewers click karke directly X profile dekh sakte hain\n\n"
        f"Agla update cycle (2 min) ke baad visible hoga.",
        parse_mode="HTML", disable_web_page_preview=True)

@owner_only
async def cmd_removex(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove X/Twitter handle for a KOL channel.
    Usage: /removex @channel"""
    if not context.args:
        await update.message.reply_text("Usage: <code>/removex @channel</code>", parse_mode="HTML"); return
    channel = context.args[0].lstrip("@").strip().lower()
    x_acc = load_x_accounts()
    if channel in x_acc:
        del x_acc[channel]
        save_x_accounts(x_acc)
        await update.message.reply_text(f"✅ @{channel} ka X handle hata diya.")
    else:
        await update.message.reply_text(f"⚠️ @{channel} ka koi X handle set nahi tha.")

@owner_only
async def cmd_xtrending(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("ℹ️ X feature hataya gaya hai.")

@owner_only
async def cmd_updateleaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("⏳ Updating leaderboard post (136) via userbot with premium emojis...")
    ok = await _update_leaderboard_with_premium_emojis(context.bot)
    if ok:
        cfg_set("last_leaderboard_update", datetime.utcnow().isoformat())
        await update.message.reply_text("✅ Leaderboard (post 136) updated with premium emojis!")
    else:
        await update.message.reply_text(
            "⚠️ Could not edit post 136. Make sure userbot is connected (/userbotlogin) "
            "and has access to the channel.")

@owner_only
async def cmd_refreshleaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Force refresh leaderboard post 136 — RESETS scores to zero, only counts calls from now onward."""
    now = datetime.utcnow()
    cfg_set("leaderboard_reset_since", now.isoformat())  # ← real score reset
    cfg_set("last_leaderboard_reset",  now.isoformat())
    cfg_set("last_leaderboard_update", "")
    msg = await update.message.reply_text("⏳ Leaderboard scores reset ho rahe hain aur post 136 update ho raha hai...")
    try:
        ok = await _update_leaderboard_with_premium_emojis(context.bot)
        if ok:
            cfg_set("last_leaderboard_update", now.isoformat())
            await msg.edit_text(
                "✅ <b>Leaderboard Reset + Refresh!</b>\n\n"
                "Purane sab scores zero ho gaye.\n"
                "Post 136 update ho gayi — ab sirf nayi calls count hongi. 🏆",
                parse_mode="HTML")
        else:
            ub_status = "✅ Connected" if (userbot_client and userbot_client.is_connected()) else "❌ Not connected"
            await msg.edit_text(
                f"⚠️ Scores reset hue lekin post 136 edit nahi hua.\n\n"
                f"Userbot: {ub_status}\n\n"
                f"Agar userbot connected nahi: /userbotcheck se confirm karo.",
                parse_mode="HTML")
    except Exception as e:
        await msg.edit_text(f"⚠️ Error: <code>{html.escape(str(e))}</code>", parse_mode="HTML")

@owner_only
async def cmd_updatechampions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("⏳ Updating champions post (137) with premium emojis...")
    ok = await _update_champions_with_premium_emojis(context.bot)
    if ok:
        cfg_set("last_champions_update", datetime.utcnow().isoformat())
        await update.message.reply_text("✅ Champions (post 137) updated with premium emojis!")
    else:
        await update.message.reply_text("⚠️ Could not edit post 137. Check bot admin permissions in @WizardScan.")

@owner_only
async def cmd_refreshchampions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Full champions reset + refresh post 137.
    - Saare channel points zero ho jaate hain
    - Purane tracked call keys exclude ho jaate hain (old X records nahi dikhenge)
    - Post 137 seedha fresh (empty) list se update hoti hai
    """
    now = datetime.utcnow()

    # 1. Snapshot max milestone per call_key at reset time.
    #    build_champions_text() will only count milestones ABOVE this snapshot —
    #    so new records on existing calls appear after reset.
    c = load_config()
    champ_snap = {}
    for ck, _ in tracked_calls.items():
        ms = list(sent_milestones.get(ck, set()))
        champ_snap[ck] = max(ms) if ms else 0
    c["champion_milestone_snapshot"] = champ_snap
    c["champion_excluded_call_keys"] = []  # clear legacy blanket list
    c["last_champions_update"] = ""
    c["last_champions_reset"]  = now.isoformat()
    save_config(c)

    # 2. Reset ALL channel points to zero
    async with _points_lock:
        save_channel_points({})

    msg = await update.message.reply_text("⏳ Champions reset ho rahi hai — points zero, purane records exclude, post 137 update ho raha hai...")
    try:
        ok = await _update_champions_with_premium_emojis(context.bot)
        if ok:
            cfg_set("last_champions_update", now.isoformat())
            await msg.edit_text(
                "✅ <b>Champions (post 137) reset + refresh!</b>\n\n"
                "• Sare points zero ho gaye\n"
                "• Purane records (1000x etc.) ab nahi dikhenge\n"
                "• Post 137 fresh ho gayi — ab se sirf naye calls count honge 🏆",
                parse_mode="HTML")
        else:
            await msg.edit_text(
                "⚠️ Points reset hue lekin post 137 edit nahi hua.\n"
                "Userbot check karo: /userbotcheck",
                parse_mode="HTML")
    except Exception as e:
        await msg.edit_text(f"⚠️ Error: <code>{html.escape(str(e))}</code>", parse_mode="HTML")

@owner_only
async def cmd_trending(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show live trending tokens from DexScreener — owner only."""
    msg = await update.message.reply_text("⏳ Fetching trending from DexScreener...")
    try:
        chain_tokens = await fetch_trending()
        text = build_trending_text(chain_tokens)
        await msg.edit_text(text, parse_mode="HTML", disable_web_page_preview=True)
    except Exception as e:
        await msg.edit_text(f"⚠️ DexScreener fetch failed: {e}")

@owner_only
async def cmd_refreshtrending(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Force refresh trending post 135 — reset timer, fetch fresh data, update immediately."""
    cfg_set("last_trending_update", "")
    save_trending_cache({})  # clear cache so full fresh list is fetched
    msg = await update.message.reply_text("⏳ DexScreener/GeckoTerminal se bilkul naya data fetch ho raha hai...")
    try:
        # Fetch once and pass directly — avoids double-fetch inside _update_trending_with_premium_emojis
        chain_tokens = await fetch_trending()
        save_trending_cache(chain_tokens)  # store for next price-only cycle
        total = sum(len(v) for v in chain_tokens.values())
        breakdown = " | ".join(f"{c}:{len(chain_tokens.get(c,[]))}" for c in ["SOL","ETH","BNB","BASE"])
        ok = await _update_trending_with_premium_emojis(context.bot, chain_tokens=chain_tokens)
        if ok:
            cfg_set("last_trending_update", datetime.utcnow().isoformat())
            await msg.edit_text(
                f"✅ Trending (post 135) refresh ho gayi!\n"
                f"📊 {breakdown}\n"
                f"Total: {total} tokens."
            )
        else:
            await msg.edit_text(
                f"⚠️ Data fetch hua ({total} tokens) lekin post 135 edit nahi hua.\n"
                f"📊 {breakdown}\n"
                f"Userbot check karo: /userbotcheck"
            )
    except Exception as e:
        await msg.edit_text(f"⚠️ Error: {e}")

@owner_only
async def cmd_refreshtrending2(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Force refresh new trending posts 3560 + 3562 with DexScreener data."""
    save_trending2_cache({})  # clear cache so full fresh list is fetched
    msg = await update.message.reply_text("⏳ DexScreener/GeckoTerminal se naya data fetch ho raha hai (SOL/ETH/BSC/RH/BASE/TON)...")
    try:
        chain_tokens2 = await fetch_trending2()
        save_trending2_cache(chain_tokens2)  # store for next price-only cycle
        total = sum(len(v) for v in chain_tokens2.values())
        breakdown = " | ".join(f"{c}:{len(chain_tokens2.get(c,[]))}" for c in ["SOL","ETH","BSC","RH","BASE","TON"])
        results = await _update_trending2_posts(context.bot, chain_tokens2=chain_tokens2)
        ok1 = results.get(POST_TRENDING_1, False)
        ok2 = results.get(POST_TRENDING_2, False)
        cfg_set("last_trending2_update", datetime.utcnow().isoformat())
        await msg.edit_text(
            f"{'✅' if ok1 else '❌'} Post {POST_TRENDING_1} (SOL/ETH/BSC): {'Updated' if ok1 else 'Failed'}\n"
            f"{'✅' if ok2 else '❌'} Post {POST_TRENDING_2} (RH/BASE/TON): {'Updated' if ok2 else 'Failed'}\n\n"
            f"📊 {breakdown}\nTotal: {total} tokens."
        )
    except Exception as e:
        await msg.edit_text(f"⚠️ Error: {e}")

@owner_only
async def cmd_ownerhelpt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Owner help for trending management commands."""
    await update.message.reply_text(
        "📊 <b>Trending Management Commands</b>\n\n"
        "🔄 <b>Chain Reset (clears that chain's tokens, shows new data in seconds)</b>\n"
        "/resetsoltrend — SOL trending reset\n"
        "/resetethtrend — ETH trending reset\n"
        "/resetbsctrend — BSC trending reset\n"
        "/resetbasetrend — BASE trending reset\n"
        "/resettontrend — TON trending reset\n"
        "/resetrhtrend — Robinhood trending reset\n\n"
        "ℹ️ <b>Note:</b> Sirf selected chain ka data reset hota hai. Baki chains unchanged.\n\n"
        "📌 <b>Pin Token to Trending (24 hours, live MC)</b>\n"
        "/pintrending CHAIN CA [TG_LINK] — Pin a token to #1 position\n"
        "Example: /pintrending BSC 0xABCDef... https://t.me/MyToken\n\n"
        "📌 <b>Remove Pin</b>\n"
        "/unpintrending CHAIN — Remove pinned token from a chain\n"
        "/listpinned — See all currently pinned tokens\n\n"
        "Chains: SOL, ETH, BSC, BASE, TON, RH",
        parse_mode="HTML"
    )


async def _do_chain_trend_reset(update, context, chain_key: str):
    """Helper: reset ONE chain's trending tokens and update only the relevant post(s).
    Other chains are NOT touched — they keep their existing cached tokens."""
    msg = await update.message.reply_text(f"⏳ {chain_key} trending reset ho rahi hai...")
    try:
        blacklist = load_trending_blacklist()
        ok135 = ok2 = False

        # ── Chains that appear in post 135 (SOL/ETH/BNB/BASE) ────────────────
        if chain_key in ("SOL", "ETH", "BNB", "BASE"):
            # Load existing cache so other chains are preserved
            cache = load_trending_cache()
            if not cache:
                cache = {"SOL": [], "ETH": [], "BNB": [], "BASE": []}
            # Fetch fresh tokens for ONLY this chain
            try:
                if chain_key == "SOL":
                    fresh = await asyncio.to_thread(_fetch_trending_sync)
                    cache["SOL"] = fresh.get("SOL", [])
                elif chain_key == "ETH":
                    cache["ETH"] = await asyncio.to_thread(_fetch_gecko_chain, "eth", "ETH", blacklist)
                elif chain_key in ("BNB", "BSC"):
                    new_bnb = await asyncio.to_thread(_fetch_gecko_chain, "bsc", "BNB", blacklist)
                    cache["BNB"] = new_bnb
                elif chain_key == "BASE":
                    cache["BASE"] = await asyncio.to_thread(_fetch_gecko_chain, "base", "BASE", blacklist)
            except Exception as fe:
                logger.warning(f"Chain {chain_key} fresh-fetch failed: {fe}")
            _inject_pinned_tokens(cache)
            save_trending_cache(cache)
            ok135 = await _update_trending_with_premium_emojis(context.bot, chain_tokens=cache)

        # ── Chains that appear in posts 3560/3562 (SOL/ETH/BSC/RH/BASE/TON) ──
        if chain_key in ("SOL", "ETH", "BSC", "BNB", "RH", "BASE", "TON"):
            cache2 = load_trending2_cache()
            if not cache2:
                cache2 = {"SOL": [], "ETH": [], "BSC": [], "RH": [], "BASE": [], "TON": []}
            try:
                if chain_key == "SOL":
                    fresh2 = await asyncio.to_thread(_fetch_trending2_sync)
                    cache2["SOL"] = fresh2.get("SOL", [])
                elif chain_key == "ETH":
                    cache2["ETH"] = await asyncio.to_thread(_fetch_gecko_chain, "eth", "ETH", blacklist)
                elif chain_key in ("BNB", "BSC"):
                    new_bsc = await asyncio.to_thread(_fetch_gecko_chain, "bsc", "BSC", blacklist)
                    cache2["BSC"] = new_bsc
                elif chain_key == "RH":
                    cache2["RH"] = await asyncio.to_thread(_fetch_gecko_chain, "robinhood", "RH", blacklist)
                elif chain_key == "BASE":
                    cache2["BASE"] = await asyncio.to_thread(_fetch_gecko_chain, "base", "BASE", blacklist)
                elif chain_key == "TON":
                    fresh2 = await asyncio.to_thread(_fetch_trending2_sync)
                    cache2["TON"] = fresh2.get("TON", [])
            except Exception as fe:
                logger.warning(f"Chain {chain_key} fresh-fetch (trending2) failed: {fe}")
            _inject_pinned_tokens(cache2)
            save_trending2_cache(cache2)
            res = await _update_trending2_posts(context.bot, chain_tokens2=cache2)
            ok2 = any(res.values())

        await msg.edit_text(
            f"✅ <b>{chain_key} Trending Reset!</b>\n\n"
            f"Post 135: {'✅' if ok135 else '—'}\n"
            f"Posts 3560/3562: {'✅' if ok2 else '—'}\n\n"
            f"Sirf <b>{chain_key}</b> tokens reset hue. Baaki chains unchanged.",
            parse_mode="HTML"
        )
    except Exception as e:
        await msg.edit_text(f"❌ {chain_key} reset failed: {e}")


@owner_only
async def cmd_resetsoltrend(update, context):
    await _do_chain_trend_reset(update, context, "SOL")

@owner_only
async def cmd_resetethtrend(update, context):
    await _do_chain_trend_reset(update, context, "ETH")

@owner_only
async def cmd_resetbsctrend(update, context):
    await _do_chain_trend_reset(update, context, "BSC")

@owner_only
async def cmd_resetbasetrend(update, context):
    await _do_chain_trend_reset(update, context, "BASE")

@owner_only
async def cmd_resettontrend(update, context):
    await _do_chain_trend_reset(update, context, "TON")

@owner_only
async def cmd_resetrhtrend(update, context):
    await _do_chain_trend_reset(update, context, "RH")


@owner_only
async def cmd_pintrending(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Pin a token CA to position #1 in a chain's trending for 24 hours with live MC updates.
    Usage: /pintrending CHAIN CA [TG_LINK]
    Example: /pintrending BSC 0xABCD... https://t.me/TokenGroup
    """
    if len(context.args) < 2:
        await update.message.reply_text(
            "Usage: <code>/pintrending CHAIN CA [TG_LINK]</code>\n\n"
            "Examples:\n"
            "<code>/pintrending BSC 0xABCDef1234...40hex</code>\n"
            "<code>/pintrending SOL AbCDefg...SolanaCA https://t.me/TokenGroup</code>\n\n"
            "Chains: SOL, ETH, BSC, BASE, TON, RH\n"
            "Pin lasts 24 hours. MC auto-updates every 2 minutes.",
            parse_mode="HTML"
        ); return

    chain_key = context.args[0].strip().upper()
    ca        = context.args[1].strip()
    tg_link   = context.args[2].strip() if len(context.args) > 2 else ""
    valid_chains = {"SOL", "ETH", "BSC", "BASE", "TON", "RH", "BNB"}
    if chain_key not in valid_chains:
        await update.message.reply_text(
            f"❌ Unknown chain: <code>{chain_key}</code>\nValid: SOL, ETH, BSC, BASE, TON, RH",
            parse_mode="HTML"); return
    # Normalise BSC/BNB
    if chain_key == "BNB": chain_key = "BSC"

    msg = await update.message.reply_text(f"⏳ {chain_key} ke liye CA <code>{ca}</code> pin ho raha hai...", parse_mode="HTML")
    # Fetch initial data
    sym    = "PIN"
    mc_fmt = "N/A"
    dex_path = {"SOL":"solana","ETH":"ethereum","BSC":"bsc","BASE":"base","TON":"ton","RH":"robinhood"}.get(chain_key,"ethereum")
    dex_url  = f"https://dexscreener.com/{dex_path}/{ca}"
    try:
        r = await asyncio.to_thread(
            _dex_session.get, f"https://api.dexscreener.com/latest/dex/tokens/{ca}", timeout=12
        )
        if r.status_code == 200:
            pairs = r.json().get("pairs") or []
            if pairs:
                best   = max(pairs, key=lambda p: float(p.get("liquidity",{}).get("usd",0) or 0))
                mc_raw = float(best.get("marketCap") or best.get("fdv") or 0)
                sym    = best.get("baseToken",{}).get("symbol", "PIN")
                mc_fmt = fmt_mc(mc_raw) if mc_raw > 0 else "N/A"
                dex_url = f"https://dexscreener.com/{best.get('chainId','ethereum').lower()}/{ca}"
    except Exception as e:
        logger.warning(f"pintrending initial fetch failed: {e}")

    pins = load_pinned_trending()
    pins[chain_key] = {
        "ca":        ca,
        "tg_link":   tg_link,
        "symbol":    sym,
        "mc_fmt":    mc_fmt,
        "dex_url":   dex_url,
        "pinned_at": datetime.utcnow().isoformat(),
    }
    save_pinned_trending(pins)

    # Immediately refresh the trending posts so pin shows up
    try:
        if chain_key in ("SOL","ETH","BSC","BASE"):
            await _update_trending_with_premium_emojis(context.bot)
        await _update_trending2_posts(context.bot)
    except Exception: pass

    await msg.edit_text(
        f"📌 <b>Pinned!</b>\n\n"
        f"Chain: <b>{chain_key}</b>\n"
        f"CA: <code>{ca}</code>\n"
        f"Symbol: ${sym}\n"
        f"MC: {mc_fmt}\n"
        f"TG: {tg_link or '—'}\n\n"
        f"✅ Token ab #1 position par hai (24 hours).\n"
        f"MC har 2 minute mein auto-update hogi.",
        parse_mode="HTML"
    )


@owner_only
async def cmd_unpintrending(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove pinned token from a chain.  Usage: /unpintrending CHAIN"""
    if not context.args:
        await update.message.reply_text("Usage: <code>/unpintrending CHAIN</code>\nExample: /unpintrending BSC", parse_mode="HTML"); return
    chain_key = context.args[0].strip().upper()
    if chain_key == "BNB": chain_key = "BSC"
    pins = load_pinned_trending()
    if chain_key not in pins:
        await update.message.reply_text(f"ℹ️ {chain_key} mein koi pinned token nahi hai."); return
    del pins[chain_key]
    save_pinned_trending(pins)
    await update.message.reply_text(f"✅ {chain_key} ka pinned token hata diya gaya.")


@owner_only
async def cmd_listpinned(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all currently pinned trending tokens."""
    pins = load_pinned_trending()
    now  = datetime.utcnow()
    if not pins:
        await update.message.reply_text("📌 Koi pinned token nahi hai."); return
    lines = ["📌 <b>Pinned Trending Tokens</b>\n"]
    for chain_key, pin in pins.items():
        try:
            pinned_at = datetime.fromisoformat(pin.get("pinned_at",""))
            expires   = pinned_at + timedelta(hours=24)
            remaining = max(timedelta(0), expires - now)
            rem_str   = f"{int(remaining.total_seconds()//3600)}h {int((remaining.total_seconds()%3600)//60)}m"
        except Exception:
            rem_str = "?"
        lines.append(
            f"<b>{chain_key}:</b> ${pin.get('symbol','?')} — {pin.get('mc_fmt','N/A')}\n"
            f"   CA: <code>{pin.get('ca','?')}</code>\n"
            f"   ⏱ Expires in: {rem_str}"
        )
    await update.message.reply_text("\n\n".join(lines), parse_mode="HTML")


@owner_only
async def cmd_blocktrending(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Block a token CA from ever appearing in trending."""
    if not context.args:
        await update.message.reply_text(
            "Usage: <code>/blocktrending TOKEN_CA</code>\n\nExample: <code>/blocktrending So1ABC123xyz</code>",
            parse_mode="HTML"); return
    ca = context.args[0].strip().lower()
    bl = load_trending_blacklist()
    bl.add(ca)
    save_trending_blacklist(bl)
    await update.message.reply_text(
        f"🚫 <b>Blocked from Trending</b>\n\n<code>{ca}</code>\n\nTotal blocked: {len(bl)}",
        parse_mode="HTML")

@owner_only
async def cmd_unblocktrending(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove a CA from the trending blacklist."""
    if not context.args:
        await update.message.reply_text(
            "Usage: <code>/unblocktrending TOKEN_CA</code>", parse_mode="HTML"); return
    ca = context.args[0].strip().lower()
    bl = load_trending_blacklist()
    if ca in bl:
        bl.discard(ca)
        save_trending_blacklist(bl)
        await update.message.reply_text(f"✅ <b>Unblocked:</b> <code>{ca}</code>", parse_mode="HTML")
    else:
        await update.message.reply_text(f"⚠️ <code>{ca}</code> blacklist mein nahi tha.", parse_mode="HTML")

@owner_only
async def cmd_listblockedtrending(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all blocked trending CAs."""
    bl = load_trending_blacklist()
    if not bl:
        await update.message.reply_text("✅ Koi CA block nahi hai. Trending clean hai."); return
    lines = "\n".join(f"• <code>{ca}</code>" for ca in sorted(bl))
    await update.message.reply_text(
        f"🚫 <b>Blocked Trending CAs ({len(bl)})</b>\n\n{lines}",
        parse_mode="HTML")

@owner_only
async def cmd_trendingkols(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show top 10 tracked KOLs ranked by highest X milestone (live, real-time)."""
    numbers = ["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟"]
    top10 = _calc_trending_kols()
    lines = ["🔥 <b>LEADERBOARD KOLS:</b>\n"]
    for i, row in enumerate(top10):
        if i >= 10: break
        ch       = row["channel"]
        best_x   = row["best_x"]
        num      = numbers[i] if i < len(numbers) else f"{i+1}."
        x_str    = f"{best_x}X" if best_x > 0 else "—"
        # Plain username only — no t.me link, no WizardScan post link below
        line = f"{num} @{html.escape(ch)} ➡️ {x_str}"
        lines.append(line)
    if len(top10) == 0:
        lines.append("<i>No data yet. Milestones being tracked...</i>")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML",
                                    disable_web_page_preview=True)

@admin_only
async def cmd_setrankingemojis(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set premium custom emoji IDs for leaderboard rankings (1-10). Admin+Owner."""
    if not context.args:
        current = cfg_get("ranking_emojis", [])
        await update.message.reply_text(
            "📋 <b>Ranking Emojis (Post 136)</b>\n\n"
            "Positions 1-10 k liye premium emoji IDs set karo.\n\n"
            "Usage: <code>/setrankingemojis ID1 ID2 ID3 ... ID10</code>\n\n"
            "Emoji IDs kaise milti hain: kisi custom emoji wali message @getidsbot ko forward karo.\n\n"
            f"Current: <code>{'  '.join(str(e) for e in current) or 'not set (using regular numbers)'}</code>",
            parse_mode="HTML"); return
    ids = [arg.strip() for arg in " ".join(context.args).split() if arg.strip()]
    cfg_set("ranking_emojis", ids[:10])
    await update.message.reply_text(f"✅ Ranking emojis set for {len(ids[:10])} positions.\n\nUse /updateleaderboard to apply to post 136.")

@owner_only
async def cmd_setstartmedia(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/setstartmedia — reply to a video/photo to set it as /start media."""
    msg = update.message.reply_to_message
    if not msg:
        await update.message.reply_text(
            "📹 <b>Set Start Video/Photo</b>\n\n"
            "Kisi video ya photo ko reply karo aur /setstartmedia bhejo.\n\n"
            "Example:\n1. Video bhejo bot ko\n2. Us video ko reply karo /setstartmedia se",
            parse_mode="HTML"); return
    if msg.video:
        file_id = msg.video.file_id; ftype = "video"
    elif msg.photo:
        file_id = msg.photo[-1].file_id; ftype = "photo"
    elif msg.animation:
        file_id = msg.animation.file_id; ftype = "video"
    else:
        await update.message.reply_text("⚠️ Sirf video ya photo reply karo."); return
    cfg_set("start_media", {"file_id": file_id, "type": ftype})
    await update.message.reply_text(f"✅ /start ka {ftype} set ho gaya!\n\nAb /start try karo.")

@owner_only
async def cmd_clearstartmedia(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/clearstartmedia — remove /start media (reverts to default video)."""
    cfg_set("start_media", None)
    await update.message.reply_text("✅ /start ki media hata di gayi. Ab default video use hogi.")

@owner_only
async def cmd_postnow(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/postnow — manually post hashtag image to channel right now."""
    await update.message.reply_text("⏳ Hashtag image channel pe post ho rhi hai...")
    try:
        await _post_hashtag_to_channel(context.bot)
        await update.message.reply_text("✅ Hashtag image @WizardScan pe post ho gayi!")
    except Exception as e:
        await update.message.reply_text(f"⚠️ Post nahi ho sakti: {e}\n\nMake sure bot channel ka admin hai.")

@owner_only
async def cmd_myusers(update: Update, context: ContextTypes.DEFAULT_TYPE):
    d = load_users_dict(); subs = load_subscriptions()
    await update.message.reply_text(
        f"👥 Total users: <b>{len(d)}</b>\n🔔 DM subscribers: <b>{len(subs)}</b>", parse_mode="HTML")

@owner_only
async def cmd_resetusers(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Clear all users from users.json — fresh start. Real users re-added when they interact."""
    args = context.args
    if not args or args[0].lower() != "confirm":
        d = load_users_dict()
        await update.message.reply_text(
            f"⚠️ <b>Reset Users</b>\n\n"
            f"Abhi <b>{len(d)}</b> users hain.\n\n"
            f"Yeh sab delete ho jayenge. Sirf woh users wapas aayenge jo bot pe command use karenge.\n\n"
            f"Confirm karne ke liye:\n<code>/resetusers confirm</code>",
            parse_mode="HTML"
        ); return

    save_users_dict({})  # clear completely
    await update.message.reply_text(
        "✅ <b>Done!</b> Sab users reset ho gaye.\n\n"
        "Ab jab bhi koi user koi bhi command use karega, woh automatically count hoga.",
        parse_mode="HTML"
    )

@owner_only
async def cmd_resetmembercount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Reset the bot member/user counter to zero. Users are recounted as they interact."""
    save_users_dict({})
    await update.message.reply_text(
        "✅ <b>Member count reset ho gaya!</b>\n\n"
        "Ab counter zero se shuru hoga. Jab bhi koi user bot se interact karega, "
        "woh automatically count mein add ho jayega.",
        parse_mode="HTML"
    )

@owner_only
async def cmd_mystats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    d = load_users_dict()
    channels = load_channels(); subs = load_subscriptions()
    ub_status = "❌ Not connected"
    if userbot_client:
        try: me = await userbot_client.get_me(); ub_status = f"✅ @{me.username}"
        except Exception: ub_status = "⚠️ Error"
    config = load_config()
    last_lb = config.get("last_leaderboard_update","never")[:10]
    last_ch = config.get("last_champions_update","never")[:10]
    last_tr = config.get("last_trending_update","never")[:16]

    # Split: users with @username first, then ID-only
    with_uname = []
    no_uname   = []
    for k, v in d.items():
        uname = v.get("username") or ""
        fname = v.get("name") or ""
        if uname:
            with_uname.append(f"@{uname}" + (f" ({html.escape(fname)})" if fname else ""))
        else:
            no_uname.append(f"ID:{k}" + (f" ({html.escape(fname)})" if fname else ""))

    all_lines = [f"• {l}" for l in with_uname] + [f"• {l}" for l in no_uname]

    # ── Header message ────────────────────────────────────────────────────────
    header = (
        f"📊 <b>Bot Stats</b>\n\n"
        f"👥 Total users: <b>{len(d)}</b>\n"
        f"✅ With @username: <b>{len(with_uname)}</b>\n"
        f"🔔 DM subscribers: <b>{len(subs)}</b>\n"
        f"📡 Tracked channels: <b>{len(channels)}</b>\n"
        f"🎯 Active calls: <b>{len(tracked_calls)}</b>\n"
        f"🔔 Milestones fired: <b>{sum(len(v) for v in sent_milestones.values())}</b>\n"
        f"🤖 Userbot: <b>{ub_status}</b>\n\n"
        f"📅 LB: <b>{last_lb}</b> | Champs: <b>{last_ch}</b> | Trending: <b>{last_tr}</b>"
    )
    await update.message.reply_text(header, parse_mode="HTML")

    # ── Paginated user list — 50 per message ─────────────────────────────────
    if not all_lines:
        await update.message.reply_text("👥 <b>Users:</b>\nNo users yet.", parse_mode="HTML")
        return

    PAGE = 50
    total_pages = (len(all_lines) + PAGE - 1) // PAGE
    for page_num in range(total_pages):
        chunk = all_lines[page_num * PAGE : (page_num + 1) * PAGE]
        page_text = (
            f"👥 <b>Users ({page_num+1}/{total_pages})</b>\n\n"
            + "\n".join(chunk)
        )
        await update.message.reply_text(page_text, parse_mode="HTML")
        await asyncio.sleep(0.3)  # avoid flood limit

@owner_only
async def cmd_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    d = load_users_dict()
    if not d:
        await update.message.reply_text("No users found."); return
    uid_state = update.effective_user.id
    owner_edit_state[uid_state] = {"state": ST_BROADCAST_PICK, "all_users": d}
    # Show only usernames — skip users without a username
    with_username = [(k, v) for k, v in d.items() if v.get("username")]
    no_username   = len(d) - len(with_username)
    lines = [f"@{v['username']}" for k, v in with_username]
    users_list = "\n".join(lines[:100])
    if len(with_username) > 100:
        users_list += f"\n...+{len(with_username)-100} more"
    no_uname_note = f"\n⚠️ {no_username} user(s) have no username (will still receive if 'all' is used)." if no_username else ""
    await update.message.reply_text(
        f"📢 <b>Broadcast — {len(d)} Users</b>\n\n"
        f"<pre>{users_list}</pre>{no_uname_note}\n\n"
        f"Reply with usernames (comma-separated):\n"
        f"Example: <code>@user1, @user2</code>\n\n"
        f"Or send <code>all</code> to broadcast to everyone.",
        parse_mode="HTML"
    )

@owner_only
async def cmd_mediabroadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a photo or video with caption to ALL bot users at once."""
    d = load_users_dict()
    if not d:
        await update.message.reply_text("No users found."); return
    uid = update.effective_user.id
    owner_edit_state[uid] = {"state": ST_MEDIABROADCAST_MSG}
    await update.message.reply_text(
        f"📸 <b>Media Broadcast — {len(d)} Users</b>\n\n"
        f"Ab photo ya video bhejain caption ke saath.\n"
        f"Bot yeh sab users ko forward karega.\n\n"
        f"⚡ Rate limiting active hai — 10k+ users safe hain.\n"
        f"❌ Deleted/blocked accounts auto-skip honge.",
        parse_mode="HTML"
    )

@owner_only
async def cmd_showtemplate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show the current alert post template clearly."""
    cur = cfg_get("alert_template", DEFAULT_TEMPLATE)
    emojis = cfg_get("alert_emoji_ids", {})
    emoji_info = []
    if emojis.get("pos1"): emoji_info.append(f"• Pehla 🔮 (Pos1): <code>{emojis['pos1']}</code>")
    if emojis.get("pos2"): emoji_info.append(f"• Doosra 🔮 (Pos2): <code>{emojis['pos2']}</code>")
    if emojis.get("global"): emoji_info.append(f"• Global (sab): <code>{emojis['global']}</code>")
    if emojis.get("low"): emoji_info.append(f"• LOW (2x–49x): <code>{emojis['low']}</code>")
    if emojis.get("high"): emoji_info.append(f"• HIGH (50x+): <code>{emojis['high']}</code>")
    emoji_str = "\n".join(emoji_info) if emoji_info else "  (koi nahi — /getemoji se set karo)"

    await update.message.reply_text(
        "📋 <b>CURRENT ALERT TEMPLATE</b>\n\n"
        "<b>Template text:</b>\n"
        f"<pre>{cur[:1200]}</pre>\n\n"
        "━━━━━━━━━━━━━━━━\n"
        "<b>Premium Emojis set:</b>\n"
        f"{emoji_str}\n\n"
        "━━━━━━━━━━━━━━━━\n"
        "💡 <b>Tips:</b>\n"
        "• Template mein <b>🔮</b> likho — wahan premium emoji lagegi\n"
        "• Jitne chahein utne 🔮 likhein (har position alag emoji)\n"
        "• Template change karein: /edittemplate\n"
        "• Emojis set karein: /getemoji",
        parse_mode="HTML"
    )

@owner_only
async def cmd_settemplate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """New command: send template WITH premium emojis already in it — bot auto-captures emoji IDs."""
    uid = update.effective_user.id
    owner_edit_state[uid] = {"state": ST_SETTEMPLATE_EM}
    await update.message.reply_text(
        "✏️ <b>TEMPLATE + PREMIUM EMOJI SETUP</b>\n\n"
        "Apna template bhejo — jahan premium emoji chahiye wahan seedha woh premium emoji use karo "
        "(apne premium account se type karo).\n\n"
        "Bot automatically un emojis ka ID capture kar lega aur sab alerts mein use karega.\n\n"
        "━━━━━━━━━━━━━━━━\n"
        "📌 <b>Variables (text mein likhein):</b>\n"
        "<code>{channel}</code> — KOL channel\n"
        "<code>{x}</code> — Multiplier (2, 10, 200...)\n"
        "<code>{symbol}</code> — Token name\n"
        "<code>{chain}</code> — Chain (SOL/ETH/BSC/BASE)\n"
        "<code>{entry}</code> — Entry market cap\n"
        "<code>{current}</code> — Current market cap\n"
        "<code>{ca}</code> — Contract address\n"
        "<code>{kol_link}</code> — KOL post link\n"
        "<code>{bot_link}</code> — Bot link\n\n"
        "━━━━━━━━━━━━━━━━\n"
        "💡 <b>2 tarike:</b>\n"
        "1️⃣ Premium emoji type karo → bot ID save karega\n"
        "2️⃣ Sirf 🔮 likho → pehle se set emoji IDs use honge\n\n"
        "⬇️ <b>Ab apna template bhejo:</b>",
        parse_mode="HTML"
    )

@owner_only
async def cmd_edittemplate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cur = cfg_get("alert_template", DEFAULT_TEMPLATE)
    uid = update.effective_user.id
    owner_edit_state[uid] = {"state": ST_TEMPLATE}
    await update.message.reply_text(
        "✏️ <b>TEMPLATE EDITOR — @WizardScan Alert</b>\n\n"
        "━━━━━━━━━━━━━━━━\n"
        "<b>Variables:</b>\n"
        "<code>{channel}</code> — KOL channel\n"
        "<code>{x}</code> — Multiplier (2, 5, 10...)\n"
        "<code>{symbol}</code> — Token symbol\n"
        "<code>{chain}</code> — Chain (SOL, ETH, BSC, BASE)\n"
        "<code>{entry}</code> — Entry market cap\n"
        "<code>{current}</code> — Current market cap\n"
        "<code>{ca}</code> — Contract address\n"
        "<code>{kol_link}</code> — KOL post link\n"
        "<code>{tg_link}</code> — @WizardScan link\n"
        "<code>{bot_link}</code> — Bot link\n\n"
        "━━━━━━━━━━━━━━━━\n"
        "🔮 = <b>Premium emoji</b> (position 1,2 = chain emoji; 3,4,5 = KOL/X/BOT)\n"
        "Set chain emojis: <code>/setchainemoji sol EMOJI_ID</code>\n"
        "Set any slot: <code>/setemojislot 3 EMOJI_ID</code>\n\n"
        "━━━━━━━━━━━━━━━━\n"
        "<b>Current template:</b>\n"
        f"<pre>{cur[:900]}</pre>\n\n"
        "⬇️ <b>Naya template bhejo:</b>",
        parse_mode="HTML"
    )

@owner_only
async def cmd_editxtemplate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("ℹ️ X feature hataya gaya hai.")

@owner_only
async def cmd_setchainemoji(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set chain-specific premium emoji. Usage: /setchainemoji sol EMOJI_ID"""
    if len(context.args) < 2:
        await update.message.reply_text(
            "⚙️ <b>Chain Emoji Setup</b>\n\n"
            "Usage: <code>/setchainemoji CHAIN EMOJI_ID</code>\n\n"
            "Chains: <code>sol</code> | <code>eth</code> | <code>bsc</code> | <code>base</code>\n\n"
            "Example:\n"
            "<code>/setchainemoji sol 5872901489860550331</code>\n"
            "<code>/setchainemoji bsc 5872901489860550331</code>\n\n"
            "Yeh emoji template mein pehle do 🔮 jagah use hogi (chain ke hisab se).",
            parse_mode="HTML"
        ); return
    chain_key = context.args[0].lower().strip()
    emoji_id  = context.args[1].strip()
    valid = {"sol","eth","bsc","base","bnb"}
    if chain_key not in valid:
        await update.message.reply_text(f"❌ Invalid chain. Use: sol / eth / bsc / base"); return
    if chain_key == "bnb": chain_key = "bsc"
    try: int(emoji_id)
    except ValueError:
        await update.message.reply_text("❌ Emoji ID must be a number."); return
    c = load_config()
    chain_emojis = c.get("chain_emoji_ids", {})
    chain_emojis[chain_key] = emoji_id
    c["chain_emoji_ids"] = chain_emojis
    save_config(c)
    await update.message.reply_text(
        f"✅ <b>{chain_key.upper()} chain emoji set!</b>\n\nID: <code>{emoji_id}</code>\n\nAb alerts mein pehle 2 🔮 yahi emoji use hongi.",
        parse_mode="HTML"
    )

@owner_only
async def cmd_setemojislot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set emoji at any 🔮 slot. Usage: /setemojislot 3 EMOJI_ID"""
    if len(context.args) < 2:
        await update.message.reply_text(
            "⚙️ <b>Emoji Slot Setup</b>\n\n"
            "Usage: <code>/setemojislot SLOT EMOJI_ID</code>\n\n"
            "Current template slots:\n"
            "🔮 Slot 1 = Chain emoji (pehla)\n"
            "🔮 Slot 2 = Chain emoji (Ca: line)\n"
            "🔮 Slot 3 = KOL link emoji\n"
            "🔮 Slot 4 = BOT link emoji\n\n"
            "Example: <code>/setemojislot 3 5872901489860550331</code>\n\n"
            "Note: Slots 1&2 chain emoji ke zariye control hoti hain.\n"
            "Use /setchainemoji for chain slots.",
            parse_mode="HTML"
        ); return
    try:
        slot = int(context.args[0])
        emoji_id = context.args[1].strip()
        int(emoji_id)
    except (ValueError, IndexError):
        await update.message.reply_text("❌ Usage: /setemojislot SLOT_NUMBER EMOJI_ID"); return
    slot_to_key = {1: "pos1", 2: "pos2", 3: "pos3", 4: "pos4"}
    if slot not in slot_to_key:
        await update.message.reply_text("❌ Slot must be 1-4."); return
    key = slot_to_key[slot]
    c = load_config()
    emojis = c.get("alert_emoji_ids", {})
    emojis[key] = emoji_id
    c["alert_emoji_ids"] = emojis
    save_config(c)
    slot_name = {1:"Chain (pos1)",2:"Chain (pos2)",3:"KOL",4:"BOT"}.get(slot,"")
    await update.message.reply_text(
        f"✅ <b>Slot {slot} ({slot_name}) set!</b>\n\nEmoji ID: <code>{emoji_id}</code>",
        parse_mode="HTML"
    )

@owner_only
async def cmd_setemojipack(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Lock the premium emoji pack permanently so it never auto-rotates/reshuffles.
    Usage: /setemojipack red|blue|white|purple|green
           /setemojipack off   (go back to auto-rotation every 10 posts)"""
    valid = [p["name"] for p in EMOJI_PACKS]
    if not context.args:
        c = load_config()
        current = c.get("locked_emoji_pack") or "off (auto-rotating)"
        await update.message.reply_text(
            "🎨 <b>Emoji Pack Lock</b>\n\n"
            f"Available: {', '.join(valid)}\n"
            f"Current: <b>{current}</b>\n\n"
            "Usage: <code>/setemojipack red</code>\n"
            "Ya rotation wapas on karne ke liye: <code>/setemojipack off</code>",
            parse_mode="HTML"
        ); return
    choice = context.args[0].strip().lower()
    c = load_config()
    if choice == "off":
        c.pop("locked_emoji_pack", None)
        save_config(c)
        await update.message.reply_text("✅ Emoji pack ab auto-rotate hoga (har 10 posts par badlega).")
        return
    if choice not in valid:
        await update.message.reply_text(f"❌ Ghalat pack. Options: {', '.join(valid)}, ya off"); return
    c["locked_emoji_pack"] = choice
    save_config(c)
    await update.message.reply_text(
        f"✅ <b>Emoji pack lock ho gaya: {choice}</b>\n\nAb yeh hamesha yehi rahega, "
        "chahe bot restart ho ya post count kuch bhi ho jaye.",
        parse_mode="HTML"
    )

@owner_only
async def cmd_resetleaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manually reset leaderboard (and trending KOLs list) and immediately update post 136."""
    now = datetime.utcnow()
    c = load_config()
    c["last_leaderboard_update"] = ""
    c["leaderboard_reset_date"] = now.isoformat()
    c["leaderboard_reset_since"] = now.isoformat()
    # Also reset trending KOLs so old high-X records don't bleed back in
    c["trending_kols_reset_since"] = now.isoformat()
    # Snapshot-based reset: record the MAX milestone per call_key at reset time.
    # _calc_leaderboard_scores will only count milestones ABOVE the snapshot value —
    # so new records on existing calls appear correctly after reset.
    lb_snap = {}
    for ck, _ in tracked_calls.items():
        ms = list(sent_milestones.get(ck, set()))
        lb_snap[ck] = max(ms) if ms else 0
    c["lb_milestone_snapshot"] = lb_snap
    c["lb_excluded_call_keys"] = []  # clear legacy blanket list
    save_config(c)
    msg = await update.message.reply_text(
        "⏳ Leaderboard + Trending KOLs reset ho raha hai, post 136 abhi update ho raha hai...",
        parse_mode="HTML"
    )
    try:
        ok = await _update_leaderboard_with_premium_emojis(context.bot)
        if ok:
            cfg_set("last_leaderboard_update", now.isoformat())
            await msg.edit_text(
                "✅ <b>Leaderboard Reset!</b>\n\n"
                "Post 136 foran update ho gayi — naya record ab live hai. 🏆\n"
                "Purana record (10000x etc.) ab nahi aayega — sirf reset ke baad ke naye calls count honge.",
                parse_mode="HTML"
            )
        else:
            await msg.edit_text(
                "⚠️ Reset hua lekin post 136 edit nahi hua.\nUserbot check karo: /userbotcheck",
                parse_mode="HTML"
            )
    except Exception as e:
        await msg.edit_text(f"⚠️ Error: <code>{html.escape(str(e))}</code>", parse_mode="HTML")


@owner_only
async def cmd_setleaderboardtemplate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set leaderboard template. {rank1_link}..{rank10_link}, {rank1_x}..{rank10_x}"""
    uid = update.effective_user.id
    cur = cfg_get("leaderboard_template","")
    owner_edit_state[uid] = {"state": ST_LEADERBOARD_TMPL}
    await update.message.reply_text(
        "📋 <b>Leaderboard Template Setup</b>\n\n"
        "Post 136 ka template set karo. Bot channel names aur X values fill karega.\n\n"
        "<b>Variables jo use kar sakte ho:</b>\n"
        "• <code>{rank1_link}</code> → <a href='t.me/ch'>@ch</a> (hyperlink)\n"
        "• <code>{rank1_channel}</code> → @channelname (plain text)\n"
        "• <code>{rank1_x}</code> → 100X\n"
        "• rank1 se rank10 tak\n\n"
        "<b>🔮</b> = premium emoji placeholder (apni emojis ke liye)\n\n"
        "<b>Current template:</b>\n"
        f"<pre>{(cur or '(koi nahi set)')[:700]}</pre>\n\n"
        "⬇️ <b>Pura template paste karo:</b>",
        parse_mode="HTML", disable_web_page_preview=True)

@owner_only
async def cmd_clearleaderboardtemplate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Clear custom leaderboard template — use default format."""
    cf = load_config(); cf.pop("leaderboard_template",""); save_config(cf)
    await update.message.reply_text("✅ Leaderboard template clear. Default format use hogi.\n\nFormat: 1️⃣ @channel 100X")

@owner_only
async def cmd_setrangetemplate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set a custom template for an X range, e.g. /setrangetemplate 100 499
    Overrides the built-in hardcoded tier text for that range."""
    if len(context.args) < 2:
        await update.message.reply_text(
            "✏️ <b>Range Template Setup</b>\n\n"
            "Usage: <code>/setrangetemplate LOW HIGH</code>\n"
            "Example: <code>/setrangetemplate 100 499</code>\n\n"
            "Phir agla message template text bhejo — jo bhi variables aur 🔮\n"
            "chahiye woh isi mein daal do (jaise /settemplate mein).\n\n"
            "Dekhne ke liye: /listrangetemplates\n"
            "Hatane ke liye: /delrangetemplate LOW HIGH",
            parse_mode="HTML"
        ); return
    try:
        low = int(context.args[0]); high = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ LOW aur HIGH numbers honi chahiye. Usage: /setrangetemplate 100 499"); return
    if low > high:
        await update.message.reply_text("❌ LOW, HIGH se bara nahi ho sakta."); return
    owner_edit_state[update.effective_user.id] = {"state": ST_RANGE_TMPL, "low": low, "high": high}
    await update.message.reply_text(
        f"✏️ <b>{low}X – {high}X Template</b>\n\n⬇️ Ab apna template bhejo (text, variables aur 🔮 ke saath):",
        parse_mode="HTML"
    )

@owner_only
async def cmd_listrangetemplates(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ranges = load_config().get("range_templates", [])
    if not ranges:
        await update.message.reply_text("Koi custom range template set nahi hai.\n\n/setrangetemplate LOW HIGH se banao."); return
    lines = ["📋 <b>Custom Range Templates</b>\n"]
    for r in ranges:
        preview = (r.get("template","") or "")[:80].replace("\n"," ")
        lines.append(f"• <b>{r.get('low')}X – {r.get('high')}X</b>: <code>{preview}...</code>")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")

@owner_only
async def cmd_delrangetemplate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("Usage: /delrangetemplate LOW HIGH"); return
    try:
        low = int(context.args[0]); high = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ LOW aur HIGH numbers honi chahiye."); return
    c = load_config()
    ranges = c.get("range_templates", [])
    new_ranges = [r for r in ranges if not (int(r.get("low",-1)) == low and int(r.get("high",-1)) == high)]
    if len(new_ranges) == len(ranges):
        await update.message.reply_text(f"Koi template {low}X–{high}X ke liye nahi mila."); return
    c["range_templates"] = new_ranges; save_config(c)
    await update.message.reply_text(f"✅ {low}X–{high}X template hata diya. Ab hardcoded/default use hoga.")

@owner_only
async def cmd_editmilestone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args: await update.message.reply_text("Usage: /editmilestone <X>"); return
    ms  = context.args[0]; cur = load_config().get("milestone_templates",{}).get(ms,"(using global template)")
    owner_edit_state[update.effective_user.id] = {"state": ST_MILESTONE_TMPL, "milestone": ms}
    await update.message.reply_text(
        f"✏️ <b>Edit {ms}X Template</b>\n\nCurrent:\n<pre>{cur[:600]}</pre>\n\nSend new template:", parse_mode="HTML")

@owner_only
async def cmd_clearmilestone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args: await update.message.reply_text("Usage: /clearmilestone <X>"); return
    ms = context.args[0]; c = load_config(); mt = c.get("milestone_templates",{})
    if ms in mt: del mt[ms]; c["milestone_templates"] = mt; save_config(c); await update.message.reply_text(f"✅ {ms}X template removed.")
    else: await update.message.reply_text(f"No custom template for {ms}X.")

@owner_only
async def cmd_listmilestones(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ms_templates = load_config().get("milestone_templates",{})
    lines = [f"{'✅' if str(ms) in ms_templates else '⬜'} <b>{ms}X</b>" for ms in get_milestones()]
    await update.message.reply_text("📋 <b>Milestones:</b>\n\n" + "\n".join(lines), parse_mode="HTML")

@owner_only
async def cmd_setmilestones(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text(
            f"📊 Current: <code>{', '.join(str(x) for x in get_milestones())}</code>\n\n"
            "Set: <code>/setmilestones 2,3,5,10,50</code>\nReset: <code>/setmilestones default</code>",
            parse_mode="HTML"); return
    raw = " ".join(context.args)
    if raw.lower() == "default":
        c = load_config(); c.pop("custom_milestones",None); save_config(c)
        await update.message.reply_text("✅ Default milestones restored."); return
    try:
        milestones = sorted(set(int(x.strip()) for x in raw.replace(","," ").split() if x.strip()))
        cfg_set("custom_milestones", milestones)
        await update.message.reply_text(f"✅ Milestones updated:\n<code>{', '.join(str(x) for x in milestones)}</code>", parse_mode="HTML")
    except ValueError:
        await update.message.reply_text("⚠️ Format: /setmilestones 2,3,5,10,50")

@owner_only
async def cmd_setmedia(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args: await update.message.reply_text("Usage: /setmedia <X>"); return
    owner_edit_state[update.effective_user.id] = {"state": ST_SET_MEDIA, "milestone": context.args[0]}
    await update.message.reply_text(f"📸 Send photo or video for {context.args[0]}X alerts:")

@owner_only
async def cmd_clearmedia(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args: await update.message.reply_text("Usage: /clearmedia <X>"); return
    ms = context.args[0]; c = load_config(); media = c.get("milestone_media",{})
    if ms in media: del media[ms]; c["milestone_media"] = media; save_config(c); await update.message.reply_text(f"✅ Media for {ms}X removed.")
    else: await update.message.reply_text(f"No media for {ms}X.")

@owner_only
async def cmd_listmedia(update: Update, context: ContextTypes.DEFAULT_TYPE):
    media = cfg_get("milestone_media",{})
    if not media: await update.message.reply_text("No media set. Use /setmedia <X>"); return
    lines = [f"✅ <b>{k}X</b> — {v.get('type','photo')}" for k,v in sorted(media.items(),key=lambda x:int(x[0]) if x[0].isdigit() else 0)]
    await update.message.reply_text("🖼️ <b>Milestone Media:</b>\n\n" + "\n".join(lines), parse_mode="HTML")

@owner_only
async def cmd_editbutton(update: Update, context: ContextTypes.DEFAULT_TYPE):
    valid = {"kol_request","promo_hub","fast_track","chat_us","leaderboard","alert_rules"}
    if not context.args or context.args[0] not in valid:
        await update.message.reply_text(
            "Usage: /editbutton <id>\n\nIDs:\n" + "\n".join(f"• <code>{b}</code>" for b in valid), parse_mode="HTML"); return
    btn = context.args[0]; cur = cfg_get("button_texts",{}).get(btn,"(not set)")
    owner_edit_state[update.effective_user.id] = {"state": ST_EDIT_BTN, "button": btn}
    await update.message.reply_text(f"✏️ <b>Edit '{btn}'</b>\n\nCurrent:\n<pre>{cur[:600]}</pre>\n\nSend new text:", parse_mode="HTML")

@owner_only
async def cmd_editbtnlabel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2: await update.message.reply_text("Usage: /editbtnlabel <id> <label>"); return
    btn, label = context.args[0], " ".join(context.args[1:])
    c = load_config(); lbls = c.get("button_labels",{}); lbls[btn] = label
    c["button_labels"] = lbls; save_config(c)
    await update.message.reply_text(f"✅ {btn} label → {label}")

@owner_only
async def cmd_editstart(update: Update, context: ContextTypes.DEFAULT_TYPE):
    owner_edit_state[update.effective_user.id] = {"state": ST_EDIT_START}
    await update.message.reply_text("✏️ <b>Edit /start</b>\n\nSend new text, photo, or video:", parse_mode="HTML")

@owner_only
async def cmd_editcommandtext(update: Update, context: ContextTypes.DEFAULT_TYPE):
    owner_edit_state[update.effective_user.id] = {"state": ST_EDIT_CMD}
    await update.message.reply_text("✏️ <b>Edit /command text</b>\n\nSend new text, photo, or video:", parse_mode="HTML")


@owner_only
async def cmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel any active editing state."""
    uid = update.effective_user.id
    if uid in owner_edit_state and owner_edit_state[uid].get("state"):
        s = owner_edit_state[uid].get("state","")
        owner_edit_state[uid] = {"state": None}
        await update.message.reply_text(f"✅ <b>Cancelled</b> — <code>{s}</code> band ho gaya.", parse_mode="HTML")
    else:
        await update.message.reply_text("ℹ️ Koi active state nahi thi.")

@owner_only
async def cmd_addcmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args: await update.message.reply_text("Usage: /addcmd <name>"); return
    name = context.args[0].lstrip("/").lower()
    owner_edit_state[update.effective_user.id] = {"state": ST_ADD_CMD2, "cmd_name": name}
    await update.message.reply_text(f"Send response for <code>/{name}</code>:", parse_mode="HTML")

@owner_only
async def cmd_removecmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args: await update.message.reply_text("Usage: /removecmd <name>"); return
    name = context.args[0].lstrip("/").lower(); c = load_config(); cmds = c.get("custom_commands",{})
    if name in cmds: del cmds[name]; c["custom_commands"] = cmds; save_config(c); await update.message.reply_text(f"✅ /{name} removed.")
    else: await update.message.reply_text(f"/{name} not found.")

@owner_only
async def cmd_listcmds(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cmds = cfg_get("custom_commands",{})
    if not cmds: await update.message.reply_text("No custom commands."); return
    await update.message.reply_text("📋 <b>Custom Commands:</b>\n\n" + "\n".join(f"• <code>/{k}</code>" for k in cmds), parse_mode="HTML")

@owner_only
async def cmd_testalert(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ms = int(context.args[0]) if context.args else 2
    await update.message.reply_text(f"📤 Sending test {ms}X alert to {TARGET_CHANNEL}...")
    try:
        await send_alert(context.bot,"TestChannel","1",ms,"SOL","$10K","$20K","TestCA123","TEST")
        await update.message.reply_text(f"✅ Test alert sent!")
    except Exception as e:
        await update.message.reply_text(f"❌ Failed: <code>{e}</code>", parse_mode="HTML")

@owner_only
async def cmd_userbotlogin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global _login_client, _userbot_login
    if not OWNER_API_ID or not OWNER_API_HASH:
        await update.message.reply_text("❌ OWNER_API_ID or OWNER_API_HASH not set."); return
    if userbot_client:
        try: me = await userbot_client.get_me(); await update.message.reply_text(f"✅ Already connected: @{me.username}"); return
        except Exception: pass
    phone = context.args[0].strip() if context.args else OWNER_PHONE
    if not phone: await update.message.reply_text("Usage: /userbotlogin +1234567890"); return
    await _send_otp_now(update, phone)

@owner_only
async def cmd_userbotresend(update: Update, context: ContextTypes.DEFAULT_TYPE):
    phone = context.args[0].strip() if context.args else (_userbot_login.get("phone") or OWNER_PHONE)
    _userbot_login.clear(); await _send_otp_now(update, phone)

@owner_only
async def cmd_userbotlogout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global userbot_client
    if not userbot_client: await update.message.reply_text("⚠️ Not connected."); return
    await userbot_client.disconnect(); userbot_client = None
    try: os.remove(USERBOT_SESSION_FILE)
    except Exception: pass
    await update.message.reply_text("✅ Userbot disconnected.")

@owner_only
async def cmd_reconnectuserbot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Reconnect userbot using saved SESSION_STRING — no OTP needed."""
    global userbot_client
    await update.message.reply_text("⏳ Userbot reconnect ho raha hai SESSION_STRING se...")
    try:
        if userbot_client:
            try: await userbot_client.disconnect()
            except Exception: pass
            userbot_client = None
        await init_userbot()
        if userbot_client:
            me = await userbot_client.get_me()
            await update.message.reply_text(f"✅ Userbot reconnect ho gaya: @{me.username}\n\nAb premium emojis kaam karein ge.")
        else:
            await update.message.reply_text(
                "❌ Reconnect fail hua.\n\n"
                "SESSION_STRING Replit Secrets mein check karo ya /userbotlogin se login karo.")
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {e}")

@owner_only
async def cmd_forceupdateposts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manually force-update posts 135 (trending), 136 (leaderboard), 137 (champions), 3560+3562 (new trending)."""
    msg = await update.message.reply_text("⏳ Posts 135/136/137/3560/3562 update ho rahe hain...")
    results = []
    try:
        ok = await _update_trending_with_premium_emojis(context.bot)
        results.append(f"📊 Post 135 (Trending): {'✅ Updated' if ok else '❌ Failed'}")
    except Exception as e:
        results.append(f"📊 Post 135 (Trending): ❌ {e}")
    try:
        ok = await _update_leaderboard_with_premium_emojis(context.bot)
        results.append(f"🏆 Post 136 (Leaderboard): {'✅ Updated' if ok else '❌ Failed'}")
    except Exception as e:
        results.append(f"🏆 Post 136 (Leaderboard): ❌ {e}")
    try:
        ok = await _update_champions_with_premium_emojis(context.bot)
        results.append(f"🔮 Post 137 (Champions): {'✅ Updated' if ok else '❌ Failed'}")
    except Exception as e:
        results.append(f"🔮 Post 137 (Champions): ❌ {e}")
    try:
        res2 = await _update_trending2_posts(context.bot)
        ok1  = res2.get(POST_TRENDING_1, False)
        ok2  = res2.get(POST_TRENDING_2, False)
        results.append(f"📈 Post {POST_TRENDING_1} (SOL/ETH/BSC): {'✅ Updated' if ok1 else '❌ Failed'}")
        results.append(f"📈 Post {POST_TRENDING_2} (RH/BASE/TON): {'✅ Updated' if ok2 else '❌ Failed'}")
    except Exception as e:
        results.append(f"📈 Posts {POST_TRENDING_1}/{POST_TRENDING_2}: ❌ {e}")
    await msg.edit_text(
        "📡 <b>Force Update Complete:</b>\n\n" + "\n".join(results),
        parse_mode="HTML"
    )

@owner_only
async def cmd_markseen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Mark all current posts in all tracked channels as seen (prevents old post tracking)."""
    msg = await update.message.reply_text("⏳ Sabhi tracked channels ki existing posts mark ho rahi hain...")
    channels = load_channels()
    total = 0
    for ch in channels:
        try:
            posts = await fetch_channel_posts(ch)
            for post in posts:
                seen_message_ids[ch].add(post["id"])
            total += len(posts)
        except Exception as e:
            logger.warning(f"markseen failed for @{ch}: {e}")
    _save_seen()
    await msg.edit_text(
        f"✅ <b>Done!</b>\n\n{len(channels)} channels mein {total} posts mark ho gayi hain.\n"
        f"Ab sirf naye posts track honge.",
        parse_mode="HTML"
    )

@owner_only
async def cmd_userbotcheck(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not userbot_client: await update.message.reply_text("❌ Userbot not connected."); return
    try:
        me = await userbot_client.get_me()
        await update.message.reply_text(f"✅ Userbot: @{me.username} ({me.id})")
    except Exception as e: await update.message.reply_text(f"❌ Error: {e}")

@owner_only
async def cmd_qrlogin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """QR code login — no OTP needed. Scan with Telegram app."""
    global userbot_client
    if not OWNER_API_ID or not OWNER_API_HASH:
        await update.message.reply_text("❌ USERBOT_API_ID/HASH not set."); return
    if userbot_client:
        try:
            me = await userbot_client.get_me()
            await update.message.reply_text(f"✅ Already connected: @{me.username}"); return
        except Exception: pass

    msg = await update.message.reply_text(
        "📲 <b>QR Code Login shuru ho raha hai...</b>\n\n"
        "Abhi aapke Telegram par QR code aayega.\n"
        "Telegram → Settings → Devices → Link Desktop Device → Scan karo",
        parse_mode="HTML"
    )
    asyncio.create_task(_qrlogin_task(update.effective_chat.id, msg.message_id, context))

async def _qrlogin_task(chat_id, status_msg_id, context):
    global userbot_client
    import base64, time
    from datetime import datetime
    bot = context.bot
    link_msg_id = None
    client = None
    try:
        from telethon import TelegramClient
        from telethon.sessions import StringSession
        from telethon.tl.functions.auth import ExportLoginTokenRequest, AcceptLoginTokenRequest
        from telethon.tl.types import auth as tl_auth

        client = TelegramClient(StringSession(), OWNER_API_ID, OWNER_API_HASH)
        await client.connect()

        attempt = 0
        while True:
            attempt += 1
            try:
                result = await client(ExportLoginTokenRequest(
                    api_id=OWNER_API_ID, api_hash=OWNER_API_HASH, except_ids=[]
                ))
            except Exception as e:
                await bot.send_message(chat_id, f"❌ Error: {e}")
                await client.disconnect(); return

            if isinstance(result, tl_auth.LoginTokenMigrateTo):
                await client._switch_dc(result.dc_id)
                try: await client(AcceptLoginTokenRequest(token=result.token))
                except Exception: pass
                continue

            if isinstance(result, tl_auth.LoginTokenSuccess):
                break

            token_b64 = base64.urlsafe_b64encode(result.token).decode()
            tg_link   = f"tg://login?token={token_b64}"
            exp       = result.expires
            exp_ts    = exp.timestamp() if isinstance(exp, datetime) else float(exp)

            text = (
                f"🔑 <b>Login Link — {attempt}. Koshish</b>\n\n"
                "👇 <b>PHONE PAR YEH LINK TAP KARO:</b>\n\n"
                f"<a href='{tg_link}'>✅ TAP HERE TO LOGIN</a>\n\n"
                "Tap karte hi Telegram ek popup dikhayega:\n"
                "<b>\"Allow login? Confirm\"</b> — Confirm dabao, ho gaya!\n\n"
                f"⏳ <i>Auto-renew hoga — koi rush nahi</i>"
            )
            try:
                if link_msg_id:
                    await bot.edit_message_text(chat_id=chat_id, message_id=link_msg_id,
                                                text=text, parse_mode="HTML",
                                                disable_web_page_preview=True)
                else:
                    sent = await bot.send_message(chat_id, text, parse_mode="HTML",
                                                  disable_web_page_preview=True)
                    link_msg_id = sent.message_id
            except Exception: pass

            # Poll until scanned or expired
            scanned = False
            while time.time() < exp_ts - 1:
                await asyncio.sleep(2)
                try:
                    chk = await client(ExportLoginTokenRequest(
                        api_id=OWNER_API_ID, api_hash=OWNER_API_HASH, except_ids=[]
                    ))
                    if isinstance(chk, tl_auth.LoginTokenSuccess):
                        scanned = True; break
                    if isinstance(chk, tl_auth.LoginTokenMigrateTo):
                        await client._switch_dc(chk.dc_id)
                        try:
                            r2 = await client(AcceptLoginTokenRequest(token=chk.token))
                            if hasattr(r2, 'user'): scanned = True; break
                        except Exception: pass
                except Exception: pass
            if scanned: break

        # ── Success ──
        me = await client.get_me()
        session_str = client.session.save()
        userbot_client = client
        save_userbot_session(session_str)

        try:
            if link_msg_id: await bot.delete_message(chat_id, link_msg_id)
        except Exception: pass

        await bot.send_message(
            chat_id,
            f"✅ <b>Login ho gaya!</b> @{me.username or me.first_name}\n\n"
            f"🎉 Userbot active — premium emojis ON!\n\n"
            f"📋 <b>SESSION_STRING copy karo (Replit → Secrets mein save karo):</b>\n\n"
            f"<code>{session_str}</code>",
            parse_mode="HTML"
        )
        logger.info(f"✅ QR/Link Login success: @{me.username}")

    except Exception as e:
        logger.error(f"qrlogin task error: {e}")
        try: await bot.send_message(chat_id, f"❌ Login failed: {e}")
        except Exception: pass
        if client:
            try: await client.disconnect()
            except Exception: pass

LOGIN_STATE_FILE  = _dp("login_state.json")   # persists phone + hash across restarts
LOGIN_SESSION_NAME = "temp_login"        # SQLite session file (not StringSession)

def _save_login_state(phone, phone_code_hash):
    import json
    with open(LOGIN_STATE_FILE, "w") as f:
        json.dump({"phone": phone, "phone_code_hash": phone_code_hash}, f)

def _load_login_state():
    import json
    try:
        with open(LOGIN_STATE_FILE) as f:
            return json.load(f)
    except Exception:
        return {}

def _clear_login_state():
    try: os.remove(LOGIN_STATE_FILE)
    except Exception: pass
    # Remove SQLite session file too
    for ext in ("", ".session"):
        try: os.remove(LOGIN_SESSION_NAME + ext)
        except Exception: pass

async def _get_or_create_login_client():
    """Return existing _login_client or recreate from SQLite session file."""
    global _login_client
    from telethon import TelegramClient
    if _login_client and _login_client.is_connected():
        return _login_client
    # Recreate from persistent SQLite session
    _login_client = TelegramClient(LOGIN_SESSION_NAME, OWNER_API_ID, OWNER_API_HASH)
    await _login_client.connect()
    return _login_client

async def _send_otp_now(update, phone):
    global _login_client, _userbot_login
    await update.message.reply_text(f"📨 Sending OTP to <code>{phone}</code>...", parse_mode="HTML")
    try:
        from telethon import TelegramClient
        if _login_client:
            try: await _login_client.disconnect()
            except Exception: pass
        # Use SQLite session (not StringSession) — survives bot restarts
        _login_client = TelegramClient(LOGIN_SESSION_NAME, OWNER_API_ID, OWNER_API_HASH)
        await _login_client.connect()
        result = await _login_client.send_code_request(phone)
        # Persist to file — survives restarts
        _save_login_state(phone, result.phone_code_hash)
        _userbot_login.update({"state": ST_USERBOT_OTP, "phone": phone, "phone_code_hash": result.phone_code_hash})
        await update.message.reply_text(
            "✅ <b>OTP bheja gaya!</b>\n\n"
            "📌 <b>Code kahan milega?</b>\n"
            "Telegram app kholo → <b>\"Telegram\"</b> wali official chat dhundo "
            "(Contacts mein sabse upar hoti hai) → wahan 5-digit code hoga.\n\n"
            "<i>(SMS nahi aata — Telegram apni app ke andar hi code bhejta hai)</i>\n\n"
            "⬇️ Woh 5-digit code yahan bhejo:",
            parse_mode="HTML"
        )
    except Exception as e:
        err = str(e)
        _userbot_login.clear()
        _clear_login_state()
        if "FLOOD_WAIT" in err:
            wait = ''.join(filter(str.isdigit, err)) or "kuch"
            await update.message.reply_text(
                f"⏳ <b>Telegram ne temporarily block kiya hai OTP ke liye.</b>\n\n"
                f"<b>{wait} seconds</b> baad dobara try karo: /userbotresend",
                parse_mode="HTML"
            )
        else:
            await update.message.reply_text(f"❌ Failed: <code>{e}</code>", parse_mode="HTML")

async def _handle_userbot_login_flow(update, msg_text):
    global userbot_client, _login_client, _userbot_login
    state = _userbot_login.get("state")

    # If bot restarted, reload state from file and recreate client
    if not _userbot_login.get("phone_code_hash"):
        saved = _load_login_state()
        if saved.get("phone_code_hash"):
            _userbot_login.update({"state": ST_USERBOT_OTP,
                                   "phone": saved["phone"],
                                   "phone_code_hash": saved["phone_code_hash"]})
            state = ST_USERBOT_OTP

    if state == ST_USERBOT_OTP:
        otp = msg_text.strip().replace(" ","")
        try:
            client = await _get_or_create_login_client()
            await client.sign_in(phone=_userbot_login["phone"], code=otp,
                                 phone_code_hash=_userbot_login["phone_code_hash"])
            from telethon.sessions import StringSession
            session_str = StringSession.save(client.session)
            save_userbot_session(session_str)
            userbot_client = client; _login_client = None
            _userbot_login.clear(); _clear_login_state()
            me = await userbot_client.get_me()
            await update.message.reply_text(
                f"🎉 <b>Userbot connected: @{me.username}!</b>\n\n"
                f"✅ Premium emojis ab kaam karengy!",
                parse_mode="HTML"
            )
        except Exception as e:
            err = str(e)
            if "SessionPasswordNeeded" in err or "two-step" in err.lower():
                _userbot_login["state"] = ST_USERBOT_2FA
                await update.message.reply_text("🔐 2FA enabled hai. Cloud password daalo:")
            elif "PHONE_CODE_EXPIRED" in err:
                _userbot_login.clear(); _clear_login_state()
                await update.message.reply_text(
                    "⏰ <b>Code expire ho gaya.</b>\n\n"
                    "👉 Dobara /userbotresend bhejo — naya code aayega.",
                    parse_mode="HTML"
                )
            elif "PHONE_CODE_INVALID" in err:
                await update.message.reply_text("❌ Wrong code — dobara try karo.")
            else:
                _userbot_login.clear(); _clear_login_state()
                await update.message.reply_text(f"❌ Error: <code>{e}</code>", parse_mode="HTML")
    elif state == ST_USERBOT_2FA:
        try:
            client = await _get_or_create_login_client()
            await client.sign_in(password=msg_text.strip())
            from telethon.sessions import StringSession
            session_str = StringSession.save(client.session)
            save_userbot_session(session_str)
            userbot_client = client; _login_client = None
            _userbot_login.clear(); _clear_login_state()
            me = await userbot_client.get_me()
            await update.message.reply_text(
                f"🎉 <b>Userbot connected: @{me.username}!</b>\n\n"
                f"✅ Premium emojis ab kaam karengy!",
                parse_mode="HTML"
            )
        except Exception as e:
            _userbot_login.clear(); _clear_login_state()
            await update.message.reply_text(f"❌ 2FA error: <code>{e}</code>", parse_mode="HTML")

# ─── Message handler ──────────────────────────────────────────────────────────
async def _block_group_activity(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Bot must be completely silent/inactive in groups, supergroups and channels.
    Runs before every other handler and stops the update chain there."""
    chat = update.effective_chat
    if chat is not None and getattr(chat, "type", "") in ("group", "supergroup", "channel"):
        raise ApplicationHandlerStop


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    if chat is not None and getattr(chat, "type", "") != "private":
        return   # never act on group / channel messages
    uid = update.effective_user.id if update.effective_user else None
    msg = update.message
    if not msg or not uid: return

    # Custom commands
    if msg.text and msg.text.startswith("/"):
        cmd_name = msg.text.split()[0].lstrip("/").split("@")[0].lower()
        custom   = cfg_get("custom_commands",{})
        if cmd_name in custom:
            await msg.reply_text(custom[cmd_name], parse_mode="HTML"); return

    # Userbot login flow
    if uid in OWNER_IDS and _userbot_login.get("state") in (ST_USERBOT_OTP, ST_USERBOT_2FA):
        if msg.text: await _handle_userbot_login_flow(update, msg.text)
        return

    # Owner edit states
    if uid in OWNER_IDS and uid in owner_edit_state and owner_edit_state[uid].get("state"):
        si = owner_edit_state[uid]; state = si["state"]

        if state == ST_SETTEMPLATE_EM:
            text_val = msg.text or msg.caption
            if not text_val:
                await msg.reply_text("⚠️ Template text bhejo (sirf text, koi media nahi)."); return
            entities = list(msg.entities or msg.caption_entities or [])
            # Extract custom premium emoji IDs in order of appearance
            custom_ents = sorted(
                [e for e in entities if e.type == "custom_emoji"],
                key=lambda e: e.offset
            )
            custom_emoji_ids = [e.custom_emoji_id for e in custom_ents]
            # Replace each custom emoji in the text with 🔮 (using UTF-16 offsets)
            processed_text = text_val
            if custom_ents:
                text_utf16 = text_val.encode('utf-16-le')
                parts = []
                prev = 0
                for ent in custom_ents:
                    s = ent.offset * 2
                    e_ = (ent.offset + ent.length) * 2
                    parts.append(text_utf16[prev:s])
                    parts.append('🔮'.encode('utf-16-le'))
                    prev = e_
                parts.append(text_utf16[prev:])
                processed_text = b''.join(parts).decode('utf-16-le')
            # Save template text (with 🔮 placeholders)
            cfg_set("alert_template", processed_text)
            # Save captured emoji IDs
            if custom_emoji_ids:
                c = load_config()
                emoji_map = {f"pos{i+1}": eid for i, eid in enumerate(custom_emoji_ids)}
                c["alert_emoji_ids"] = emoji_map
                # pos1 = chain emoji (used for all chains unless overridden)
                chain_ids = c.get("chain_emoji_ids", {})
                for chain in ["sol", "eth", "bsc", "base"]:
                    if not chain_ids.get(chain):
                        chain_ids[chain] = custom_emoji_ids[0]
                c["chain_emoji_ids"] = chain_ids
                save_config(c)
            owner_edit_state[uid] = {"state": None}
            emoji_note = (
                f"\n\n🎯 <b>{len(custom_emoji_ids)} premium emoji ID(s) captured aur save ho gayi!</b>\n" +
                "\n".join(f"  Pos{i+1}: <code>{eid}</code>" for i, eid in enumerate(custom_emoji_ids))
            ) if custom_emoji_ids else "\n\n⚠️ Koi premium emoji detect nahi hua — pehle se set emoji IDs use honge."
            await msg.reply_text(
                f"✅ <b>Template saved!</b>{emoji_note}\n\n"
                f"<b>Saved template:</b>\n<pre>{processed_text[:800]}</pre>",
                parse_mode="HTML"
            ); return

        if state == ST_TEMPLATE:
            text_val = msg.text or msg.caption
            if text_val:
                cfg_set("alert_template", text_val)
            if msg.photo or msg.video:
                fid = msg.photo[-1].file_id if msg.photo else msg.video.file_id
                ftype = "photo" if msg.photo else "video"
                c = load_config(); media = c.get("milestone_media",{}); media["global"] = {"type":ftype,"file_id":fid}
                c["milestone_media"] = media; save_config(c)
            if not text_val and not (msg.photo or msg.video):
                await msg.reply_text("⚠️ Template text bhejo (ya photo/video with caption)."); return
            owner_edit_state[uid] = {"state": None}
            await msg.reply_text("✅ @WizardScan template saved!\n\nPreview ke liye /showtemplate use karo."); return

        elif state == ST_RANGE_TMPL:
            low = si["low"]; high = si["high"]
            text_val = msg.text or msg.caption
            if not text_val:
                await msg.reply_text("⚠️ Template text bhejo."); return
            c = load_config()
            ranges = c.get("range_templates", [])
            ranges = [r for r in ranges if not (int(r.get("low",-1)) == low and int(r.get("high",-1)) == high)]
            ranges.append({"low": low, "high": high, "template": text_val})
            c["range_templates"] = ranges
            save_config(c)
            owner_edit_state[uid] = {"state": None}
            await msg.reply_text(
                f"✅ <b>{low}X–{high}X template saved!</b>\n\nAb yeh range hamesha isi text ko use karega, "
                f"jab tak /delrangetemplate {low} {high} se hatao.",
                parse_mode="HTML"
            ); return

        elif state == ST_LEADERBOARD_TMPL:
            text_val = msg.text or msg.caption
            if not text_val: await msg.reply_text("⚠️ Template text bhejo."); return
            cfg_set("leaderboard_template", text_val.strip())
            owner_edit_state[uid] = {"state": None}
            await msg.reply_text("✅ Leaderboard template saved!\n/updateleaderboard se update karo."); return

        elif state == ST_MILESTONE_TMPL:
            ms = si["milestone"]; text_val = msg.text or msg.caption
            if text_val:
                c = load_config(); mt = c.get("milestone_templates",{}); mt[ms] = text_val; c["milestone_templates"] = mt; save_config(c)
            if msg.photo or msg.video:
                fid = msg.photo[-1].file_id if msg.photo else msg.video.file_id
                ftype = "photo" if msg.photo else "video"
                c = load_config(); media = c.get("milestone_media",{}); media[ms] = {"type":ftype,"file_id":fid}; c["milestone_media"] = media; save_config(c)
            if not text_val and not (msg.photo or msg.video): await msg.reply_text("⚠️ Send template text or media."); return
            owner_edit_state[uid] = {"state": None}
            await msg.reply_text(f"✅ {ms}X template saved!"); return

        elif state == ST_SET_MEDIA:
            ms = si["milestone"]
            if msg.photo:   fid, ftype = msg.photo[-1].file_id, "photo"
            elif msg.video: fid, ftype = msg.video.file_id, "video"
            else:           await msg.reply_text("⚠️ Send photo or video."); return
            c = load_config(); media = c.get("milestone_media",{}); media[ms] = {"type":ftype,"file_id":fid}
            if msg.caption:
                mt = c.get("milestone_templates",{}); mt[ms] = msg.caption; c["milestone_templates"] = mt
            c["milestone_media"] = media; save_config(c)
            owner_edit_state[uid] = {"state": None}
            await msg.reply_text(f"✅ {ftype.capitalize()} saved for {ms}X!"); return

        elif state == ST_EDIT_BTN:
            btn = si["button"]
            if msg.text:
                c = load_config(); bt = c.get("button_texts",{}); bt[btn] = msg.text; c["button_texts"] = bt; save_config(c)
                owner_edit_state[uid] = {"state": None}
                await msg.reply_text(f"✅ '{btn}' text updated!"); return

        elif state == ST_EDIT_START:
            c = load_config(); saved = []; text_val = msg.text or msg.caption
            if text_val: c["start_text"] = text_val; saved.append("text")
            if msg.photo or msg.video:
                fid = msg.photo[-1].file_id if msg.photo else msg.video.file_id
                ftype = "photo" if msg.photo else "video"
                c["start_media"] = {"type":ftype,"file_id":fid}; saved.append(ftype)
            if not saved: await msg.reply_text("⚠️ Send text or media."); return
            save_config(c); owner_edit_state[uid] = {"state": None}
            await msg.reply_text(f"✅ /start {' + '.join(saved)} saved!"); return

        elif state == ST_EDIT_CMD:
            c = load_config(); saved = []; text_val = msg.text or msg.caption
            if text_val: c["command_text"] = text_val; saved.append("text")
            if msg.photo or msg.video:
                fid = msg.photo[-1].file_id if msg.photo else msg.video.file_id
                ftype = "photo" if msg.photo else "video"
                c["command_media"] = {"type":ftype,"file_id":fid}; saved.append(ftype)
            if not saved: await msg.reply_text("⚠️ Send text or media."); return
            save_config(c); owner_edit_state[uid] = {"state": None}
            await msg.reply_text(f"✅ /command {' + '.join(saved)} saved!"); return

        elif state == ST_ADD_CMD2:
            name = si["cmd_name"]
            if msg.text:
                c = load_config(); cmds = c.get("custom_commands",{}); cmds[name] = msg.text
                c["custom_commands"] = cmds; save_config(c)
                owner_edit_state[uid] = {"state": None}
                await msg.reply_text(f"✅ /{name} added!"); return

        elif state == ST_BROADCAST_PICK:
            sel_text = (msg.text or "").strip()
            d = si.get("all_users", load_users_dict())
            if sel_text.lower() == "all":
                selected_ids = [int(k) for k in d.keys()]
            else:
                parts = [p.strip().lstrip("@") for p in sel_text.replace(",", "\n").split("\n") if p.strip()]
                selected_ids = []
                for k, v in d.items():
                    uname = (v.get("username") or "").lower()
                    if uname and uname in [p.lower() for p in parts]:
                        selected_ids.append(int(k))
                    elif k in parts:
                        selected_ids.append(int(k))
            if not selected_ids:
                await msg.reply_text("⚠️ No matching users found. Try again or send <code>all</code>.", parse_mode="HTML"); return
            owner_edit_state[uid] = {"state": ST_BROADCAST_MSG, "targets": selected_ids}
            await msg.reply_text(
                f"✅ <b>{len(selected_ids)} users selected.</b>\n\n"
                f"Now send your broadcast message (text, photo, or video with caption).",
                parse_mode="HTML"
            ); return

        elif state == ST_BROADCAST_MSG:
            targets = si.get("targets", [])
            owner_edit_state[uid] = {"state": None}
            ok = fail = blocked = 0
            for i, tid in enumerate(targets):
                try:
                    if msg.photo:
                        await context.bot.send_photo(tid, photo=msg.photo[-1].file_id,
                            caption=msg.caption or "", parse_mode="HTML")
                    elif msg.video:
                        await context.bot.send_video(tid, video=msg.video.file_id,
                            caption=msg.caption or "", parse_mode="HTML")
                    elif msg.text:
                        await context.bot.send_message(tid, msg.text, parse_mode="HTML")
                    else:
                        await context.bot.forward_message(tid, from_chat_id=msg.chat_id, message_id=msg.message_id)
                    ok += 1
                except Exception as e:
                    err_str = str(e).lower()
                    if any(x in err_str for x in ("deactivated", "deleted", "blocked", "bot was kicked", "user not found", "chat not found", "forbidden")):
                        blocked += 1
                    else:
                        fail += 1
                # Rate limiting: 25 msg/sec max — sleep every 25 sends (Telegram limit)
                if (i + 1) % 25 == 0:
                    await asyncio.sleep(1)
            await msg.reply_text(
                f"📢 <b>Broadcast Done</b>\n"
                f"✅ Sent: {ok} | 🚫 Blocked/Deleted: {blocked} | ❌ Failed: {fail}",
                parse_mode="HTML"
            ); return

        elif state == ST_MEDIABROADCAST_MSG:
            # Validate FIRST — only clear state after we confirm valid media
            if not (msg.photo or msg.video):
                await msg.reply_text(
                    "⚠️ Sirf photo ya video bhejain caption ke saath.\n"
                    "Text-only support nahi hai is command mein.\n\n"
                    "Dobara photo/video bhejain ya /cancel se cancel karein."
                ); return
            # Valid media — now clear state and start broadcast
            owner_edit_state[uid] = {"state": None}
            d = load_users_dict()
            targets = [int(k) for k in d.keys()]
            ok = fail = blocked = 0
            status_msg = await msg.reply_text(f"⏳ Sending to {len(targets)} users...")
            for i, tid in enumerate(targets):
                try:
                    if msg.photo:
                        await context.bot.send_photo(tid, photo=msg.photo[-1].file_id,
                            caption=msg.caption or "", parse_mode="HTML")
                    elif msg.video:
                        await context.bot.send_video(tid, video=msg.video.file_id,
                            caption=msg.caption or "", parse_mode="HTML")
                    ok += 1
                except Exception as e:
                    err_str = str(e).lower()
                    if any(x in err_str for x in ("deactivated", "deleted", "blocked", "bot was kicked", "user not found", "chat not found", "forbidden")):
                        blocked += 1
                    else:
                        fail += 1
                # Rate limiting — 25 msg/sec (Telegram safe limit)
                if (i + 1) % 25 == 0:
                    await asyncio.sleep(1)
                # Progress update every 500 users
                if (i + 1) % 500 == 0:
                    try:
                        await status_msg.edit_text(f"⏳ Progress: {i+1}/{len(targets)} users done...")
                    except Exception:
                        pass
            summary = (
                f"📸 <b>Media Broadcast Done!</b>\n"
                f"✅ Sent: {ok} | 🚫 Blocked/Deleted: {blocked} | ❌ Failed: {fail}"
            )
            try:
                await status_msg.edit_text(summary, parse_mode="HTML")
            except Exception:
                await msg.reply_text(summary, parse_mode="HTML")
            return

        elif state == ST_SETPROMOLINK:
            owner_edit_state[uid] = {"state": None}
            raw = (msg.text or "").strip()
            lines = [l.strip() for l in raw.split("\n") if l.strip()]
            if len(lines) < 2:
                await msg.reply_text("⚠️ Send text and URL on separate lines.\nFormat:\n<code>Your text\nhttps://url</code>", parse_mode="HTML"); return
            promo_text = lines[0]
            promo_url  = lines[-1]
            if not promo_url.startswith("http"):
                await msg.reply_text("⚠️ Last line must be a valid URL starting with http/https."); return
            cfg_set("promo_link", {"text": promo_text, "url": promo_url, "set_at": datetime.utcnow().isoformat()})
            await msg.reply_text(
                f"✅ <b>Promo Link Set for 12 Hours</b>\n\n"
                f"Text: {promo_text}\nURL: {promo_url}\n\n"
                f"Will appear on all 2X–50X alert posts until expiry.",
                parse_mode="HTML"
            ); return

        elif state == ST_ADD_MOMENTUM_VID:
            owner_edit_state[uid] = {"state": None}
            if msg.video or msg.animation:
                media_obj = msg.video or msg.animation
                ftype = "gif" if msg.animation else "video"
                vids = load_config().get("momentum_videos", [])
                vids.append({"file_id": media_obj.file_id, "type": ftype})
                cfg_set("momentum_videos", vids)
                await msg.reply_text(
                    f"✅ <b>Momentum Video #{len(vids)} Added!</b>\n\n"
                    f"Total stored videos: <b>{len(vids)}</b>\n"
                    f"These will now rotate in MOMENTUM ACTIVE posts.\n\n"
                    f"Use /listmomentumvideos to see all · /addmomentumvideo to add more",
                    parse_mode="HTML"); return
            else:
                await msg.reply_text("⚠️ Please send a video file. No changes made."); return

        elif state == ST_ADD_XRAY_VID:
            owner_edit_state[uid] = {"state": None}
            if msg.video or msg.animation:
                media_obj = msg.video or msg.animation
                ftype = "gif" if msg.animation else "video"
                vids = load_config().get("xray_videos", [])
                if len(vids) >= 10:
                    await msg.reply_text(
                        "⚠️ Maximum 10 X-Ray videos allowed.\n"
                        "Use /removexrayvideo N to remove one first."
                    ); return
                vids.append({"file_id": media_obj.file_id, "type": ftype})
                cfg_set("xray_videos", vids)
                await msg.reply_text(
                    f"✅ <b>X-Ray Video #{len(vids)} Added!</b>\n\n"
                    f"Total stored: <b>{len(vids)}/10</b>\n"
                    f"X-Ray reports mein rotate hongi.\n\n"
                    f"Use /listxrayvideos to see all · /addxrayvideo to add more",
                    parse_mode="HTML"); return
            else:
                await msg.reply_text("⚠️ Please send a video file. No changes made."); return

        elif state == ST_ADD_DROPPED_VID:
            owner_edit_state[uid] = {"state": None}
            if msg.video or msg.animation:
                media_obj = msg.video or msg.animation
                ftype = "gif" if msg.animation else "video"
                vids = load_config().get("dropped_videos", [])
                if len(vids) >= 20:
                    await msg.reply_text(
                        "⚠️ Maximum 20 Dropped-Call videos allowed.\n"
                        "Use /removedroppedvideo N to remove one first."
                    ); return
                vids.append({"file_id": media_obj.file_id, "type": ftype})
                cfg_set("dropped_videos", vids)
                await msg.reply_text(
                    f"✅ <b>Dropped-Call Video #{len(vids)} Added!</b>\n\n"
                    f"Total stored: <b>{len(vids)}/20</b>\n"
                    f"Har nayi tracked call par rotate hogi.\n\n"
                    f"Use /listdroppedvideos to see all · /adddroppedvideo to add more",
                    parse_mode="HTML"); return
            else:
                await msg.reply_text("⚠️ Please send a video file. No changes made."); return

        elif state == ST_DROPPED_TMPL:
            owner_edit_state[uid] = {"state": None}
            text_val = msg.text or msg.caption
            if not text_val:
                await msg.reply_text("⚠️ Template text bhejo."); return
            cfg_set("dropped_call_template", text_val)
            await msg.reply_text(
                "✅ <b>Dropped-Call Template Saved!</b>\n\n"
                "Ab jab bhi koi KOL pehli baar call kare ga, isi template se post hogi.\n"
                "/showdroppedtemplate se dekh sakte ho.",
                parse_mode="HTML"); return

    # /setkolowner multi-step state handler
    if uid in OWNER_IDS and uid in owner_edit_state:
        si_ko = owner_edit_state.get(uid, {})
        if si_ko.get("state") == ST_SETKOLOWNER_CH:
            owner_edit_state[uid] = {"state": None}
            ch_input = (msg.text or "").strip().lstrip("@")
            if not ch_input:
                await msg.reply_text("⚠️ Channel username valid nahi hai."); return
            channels = load_channels()
            if ch_input.lower() not in [c.lower() for c in channels]:
                await msg.reply_text(
                    f"⚠️ @{ch_input} tracked channels mein nahi hai.\n"
                    "Sirf tracked channels ke owners set ho sakte hain."); return
            owner_edit_state[uid] = {"state": ST_SETKOLOWNER_USER, "channel": ch_input.lower()}
            await msg.reply_text(
                f"✅ Channel: @{ch_input}\n\n"
                "Ab us user ka Telegram username bhejo jise is channel ki sab call updates milein.\n"
                "(Format: @username  ya sirf username)",
                parse_mode="HTML"); return
        elif si_ko.get("state") == ST_SETKOLOWNER_USER:
            owner_edit_state[uid] = {"state": None}
            pending_ch = si_ko.get("channel","")
            user_input = (msg.text or "").strip().lstrip("@")
            if not user_input:
                await msg.reply_text("⚠️ Valid username nahi mila."); return
            # Lookup user ID by username from our users DB
            d = load_users_dict()
            found_id = None
            for uid_str, udata in d.items():
                if (udata.get("username") or "").lower() == user_input.lower():
                    found_id = int(uid_str)
                    break
            if not found_id:
                await msg.reply_text(
                    f"⚠️ @{user_input} ka Telegram ID nahi mila bot ke users mein.\n\n"
                    "User ne pehle bot se /start karna chahiye taake bot uska ID store kare.\n\n"
                    "Agar aap directly numeric ID jaante ho, use karein:\n"
                    f"<code>/setkolownerid {pending_ch} NUMERIC_USER_ID</code>",
                    parse_mode="HTML"); return
            kol_owners = load_kol_owners()
            kol_owners[pending_ch] = found_id
            save_kol_owners(kol_owners)
            await msg.reply_text(
                f"✅ <b>KOL Owner Set!</b>\n\n"
                f"Channel: @{pending_ch}\n"
                f"Owner: @{user_input} (ID: {found_id})\n\n"
                f"Ab se @{pending_ch} ki har call milestone alert directly @{user_input} ke DM mein jaegi.",
                parse_mode="HTML"); return

    # Channel / Twitter lookup
    if msg.text and not msg.text.startswith("/"):
        handled = await handle_lookup(update, msg.text)
        if handled: return

    # (Group CA lookup feature removed)

# ─── Post init ────────────────────────────────────────────────────────────────
async def post_init(application: Application):
    await application.bot.set_my_commands([
        BotCommand("start",     "Welcome & Bot Info"),
        BotCommand("command",   "Command Center"),
        BotCommand("history",   "Call history of a KOL channel"),
        BotCommand("linkme",    "Link your channel for alerts"),
        BotCommand("subscribe", "Toggle DM alerts"),
        BotCommand("submit",    "Request KOL tracking"),
    ])
    # Pre-seed known members so they always appear in /myusers even after data loss
    _seed_known_members()
    # Run one-time migration: remove X/Twitter links from stored templates
    try:
        _migrate_remove_x_from_templates()
    except Exception as _me:
        logger.warning(f"Template migration failed: {_me}")
    logger.info("✅ Bot commands menu set")

# ─── Global error handler ─────────────────────────────────────────────────────
async def _global_error_handler(update, context):
    """Catch every unhandled handler/job exception so one bad update can never
    kill the process (the #1 reason the Railway container kept restarting)."""
    err = context.error
    logger.error(f"Unhandled error: {type(err).__name__}: {err}", exc_info=err)


# ─── Railway health check server ──────────────────────────────────────────────
def _start_health_server():
    """Railway web services kill a deploy that never binds $PORT.
    A tiny stdlib HTTP server on a daemon thread keeps the deploy healthy."""
    port = int(os.environ.get("PORT", "0") or 0)
    if not port:
        return
    try:
        import threading
        from http.server import BaseHTTPRequestHandler, HTTPServer

        class _H(BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"status":"ok","service":"wizard-scan-bot"}')
            def log_message(self, *a):  # silence access logs
                pass

        srv = HTTPServer(("0.0.0.0", port), _H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        logger.info(f"✅ Health server listening on :{port}")
    except Exception as e:
        logger.warning(f"Health server failed: {e}")


# ─── Main ─────────────────────────────────────────────────────────────────────
def main():
    if not BOT_TOKEN:
        logger.error("❌ BOT_TOKEN not set! Railway → Variables me BOT_TOKEN add karo.")
        raise SystemExit(1)
    if not OWNER_IDS:
        logger.warning("⚠️ OWNER_ID not set — owner commands disabled.")
    _start_health_server()

    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()

    # Public commands
    app.add_handler(CommandHandler("start",     cmd_start))
    app.add_handler(CommandHandler("command",   cmd_command))
    app.add_handler(CommandHandler("history",   cmd_history))
    app.add_handler(CommandHandler("linkinfo",  cmd_linkinfo))
    app.add_handler(CommandHandler("submit",    cmd_submit))
    app.add_handler(CommandHandler("subscribe", cmd_subscribe))
    app.add_handler(CommandHandler("linkme",    cmd_linkme))

    # Callbacks — specific patterns FIRST, then generic catch-all
    app.add_handler(CallbackQueryHandler(cb_setemoji, pattern=r"^setemoji:"))
    app.add_handler(CallbackQueryHandler(button_callback))

    # Owner — userbot
    app.add_handler(CommandHandler("reconnectuserbot", cmd_reconnectuserbot))
    app.add_handler(CommandHandler("forceupdateposts", cmd_forceupdateposts))
    app.add_handler(CommandHandler("markseen",         cmd_markseen))
    app.add_handler(CommandHandler("userbotlogin",  cmd_userbotlogin))
    app.add_handler(CommandHandler("userbotresend", cmd_userbotresend))
    app.add_handler(CommandHandler("userbotlogout", cmd_userbotlogout))
    app.add_handler(CommandHandler("userbotcheck",  cmd_userbotcheck))
    app.add_handler(CommandHandler("qrlogin",       cmd_qrlogin))

    # Owner — channels
    app.add_handler(CommandHandler("mychannels",    cmd_mychannels))
    app.add_handler(CommandHandler("addchannel",    cmd_addchannel))
    app.add_handler(CommandHandler("removechannel", cmd_removechannel))


    # Owner — post updates
    app.add_handler(CommandHandler("updateleaderboard", cmd_updateleaderboard))
    app.add_handler(CommandHandler("updatechampions",   cmd_updatechampions))
    # app.add_handler(CommandHandler("trending",          cmd_trending))        # disabled
    app.add_handler(CommandHandler("setrankingemojis",  cmd_setrankingemojis))
    # app.add_handler(CommandHandler("refreshtrending",      cmd_refreshtrending))  # disabled
    app.add_handler(CommandHandler("refreshleaderboard",   cmd_refreshleaderboard))
    app.add_handler(CommandHandler("refreshchampions",     cmd_refreshchampions))
    app.add_handler(CommandHandler("refreshtrending2",     cmd_refreshtrending2))
    app.add_handler(CommandHandler("ownerhelpt",           cmd_ownerhelpt))
    app.add_handler(CommandHandler("resetsoltrend",        cmd_resetsoltrend))
    app.add_handler(CommandHandler("resetethtrend",        cmd_resetethtrend))
    app.add_handler(CommandHandler("resetbsctrend",        cmd_resetbsctrend))
    app.add_handler(CommandHandler("resetbasetrend",       cmd_resetbasetrend))
    app.add_handler(CommandHandler("resettontrend",        cmd_resettontrend))
    app.add_handler(CommandHandler("resetrhtrend",         cmd_resetrhtrend))
    app.add_handler(CommandHandler("pintrending",          cmd_pintrending))
    app.add_handler(CommandHandler("unpintrending",        cmd_unpintrending))
    app.add_handler(CommandHandler("listpinned",           cmd_listpinned))
    # app.add_handler(CommandHandler("blocktrending",        cmd_blocktrending))    # disabled
    # app.add_handler(CommandHandler("unblocktrending",      cmd_unblocktrending))  # disabled
    # app.add_handler(CommandHandler("listblockedtrending",  cmd_listblockedtrending))  # disabled
    app.add_handler(CommandHandler("givepoints",        cmd_givepoints))
    app.add_handler(CommandHandler("checkpoints",       cmd_checkpoints))
    app.add_handler(CommandHandler("zerocolpoints",     cmd_zerocolpoints))
    app.add_handler(CommandHandler("resetallpoints",    cmd_resetallpoints))
    app.add_handler(CommandHandler("freezecall",        cmd_freezecall))
    app.add_handler(CommandHandler("unfreezecall",      cmd_unfreezecall))
    app.add_handler(CommandHandler("addmissedcall",     cmd_addmissedcall))
    app.add_handler(CommandHandler("adjustcall",        cmd_adjustcall))
    app.add_handler(CommandHandler("setkolowner",       cmd_setkolowner))
    app.add_handler(CommandHandler("setkolownerid",     cmd_setkolownerid))
    app.add_handler(CommandHandler("removekolowner",    cmd_removekolowner))
    app.add_handler(CommandHandler("listkolowners",     cmd_listkolowners))
    app.add_handler(CommandHandler("xcheck",            cmd_xcheck))

    # Admin + Owner — emoji management
    app.add_handler(CommandHandler("setalertemoji",     cmd_setalertemoji))
    app.add_handler(CommandHandler("listalertemojis",   cmd_listalertemojis))
    app.add_handler(CommandHandler("clearalertemoji",   cmd_clearalertemoji))

    # Owner — admin management
    app.add_handler(CommandHandler("addadmin",          cmd_addadmin))
    app.add_handler(CommandHandler("removeadmin",       cmd_removeadmin))
    app.add_handler(CommandHandler("listadmins",        cmd_listadmins))

    # Owner — users
    app.add_handler(CommandHandler("myusers",        cmd_myusers))
    app.add_handler(CommandHandler("resetmembercount", cmd_resetmembercount))
    app.add_handler(CommandHandler("resetusers",     cmd_resetusers))
    app.add_handler(CommandHandler("broadcast",      cmd_broadcast))
    app.add_handler(CommandHandler("mediabroadcast", cmd_mediabroadcast))
    app.add_handler(CommandHandler("mystats",        cmd_mystats))

    # Owner — templates
    app.add_handler(CommandHandler("settemplate",    cmd_settemplate))
    app.add_handler(CommandHandler("edittemplate",   cmd_edittemplate))
    app.add_handler(CommandHandler("setrangetemplate",   cmd_setrangetemplate))
    app.add_handler(CommandHandler("listrangetemplates", cmd_listrangetemplates))
    app.add_handler(CommandHandler("delrangetemplate",   cmd_delrangetemplate))
    app.add_handler(CommandHandler("editmilestone",  cmd_editmilestone))
    app.add_handler(CommandHandler("clearmilestone", cmd_clearmilestone))
    app.add_handler(CommandHandler("listmilestones", cmd_listmilestones))
    app.add_handler(CommandHandler("setmilestones",  cmd_setmilestones))

    # Owner — media
    app.add_handler(CommandHandler("setmedia",       cmd_setmedia))
    app.add_handler(CommandHandler("clearmedia",     cmd_clearmedia))
    app.add_handler(CommandHandler("listmedia",      cmd_listmedia))
    app.add_handler(CommandHandler("setstartmedia",   cmd_setstartmedia))
    app.add_handler(CommandHandler("clearstartmedia", cmd_clearstartmedia))
    app.add_handler(CommandHandler("postnow",         cmd_postnow))

    # Owner — texts
    app.add_handler(CommandHandler("editbutton",      cmd_editbutton))
    app.add_handler(CommandHandler("editbtnlabel",    cmd_editbtnlabel))
    app.add_handler(CommandHandler("editstart",       cmd_editstart))
    app.add_handler(CommandHandler("editcommandtext", cmd_editcommandtext))

    # Owner — custom commands
    app.add_handler(CommandHandler("cancel",     cmd_cancel))
    app.add_handler(CommandHandler("addcmd",    cmd_addcmd))
    app.add_handler(CommandHandler("removecmd", cmd_removecmd))
    app.add_handler(CommandHandler("listcmds",  cmd_listcmds))

    # Owner — misc
    app.add_handler(CommandHandler("testalert",          cmd_testalert))
    app.add_handler(CommandHandler("ownerhelp",          cmd_ownerhelp))
    app.add_handler(CommandHandler("premiumguide",       cmd_premiumguide))
    app.add_handler(CommandHandler("getemoji",           cmd_getemoji))
    app.add_handler(CommandHandler("debugemoji",         cmd_debugemoji))
    app.add_handler(CommandHandler("showtemplate",       cmd_showtemplate))
    app.add_handler(CommandHandler("editxtemplate",      cmd_editxtemplate))
    app.add_handler(CommandHandler("setchainemoji",      cmd_setchainemoji))
    app.add_handler(CommandHandler("setemojislot",       cmd_setemojislot))
    app.add_handler(CommandHandler("setemojipack",       cmd_setemojipack))
    app.add_handler(CommandHandler("resetleaderboard",   cmd_resetleaderboard))
    app.add_handler(CommandHandler("setleaderboardtemplate", cmd_setleaderboardtemplate))
    app.add_handler(CommandHandler("clearleaderboardtemplate", cmd_clearleaderboardtemplate))
    # app.add_handler(CommandHandler("trendingKols",       cmd_trendingkols))  # disabled
    # app.add_handler(CommandHandler("trendingkols",       cmd_trendingkols))  # disabled
    app.add_handler(CommandHandler("setcommandvideo",    cmd_setcommandvideo))
    app.add_handler(CommandHandler("setpromo",           cmd_setpromo))
    app.add_handler(CommandHandler("stoppromo",          cmd_stoppromo))
    app.add_handler(CommandHandler("setpromolink",        cmd_setpromolink))
    app.add_handler(CommandHandler("clearpromolink",      cmd_clearpromolink))
    app.add_handler(CommandHandler("pendingkols",         cmd_pendingkols))
    app.add_handler(CommandHandler("addmomentumvideo",    cmd_addmomentumvideo))
    app.add_handler(CommandHandler("listmomentumvideos",  cmd_listmomentumvideos))
    app.add_handler(CommandHandler("removemomentumvideo", cmd_removemomentumvideo))
    app.add_handler(CommandHandler("clearmomentumvideos", cmd_clearmomentumvideos))
    app.add_handler(CommandHandler("previewtemplate",     cmd_previewtemplate))
    app.add_handler(CommandHandler("previewmomentum",    cmd_previewmomentum))
    app.add_handler(CommandHandler("testmomentum",       cmd_testmomentum))

    # Owner — new commands (Page 2)
    app.add_handler(CommandHandler("joinkols",             cmd_joinkols))
    app.add_handler(CommandHandler("setdroppedtemplate",  cmd_setdroppedtemplate))
    app.add_handler(CommandHandler("showdroppedtemplate", cmd_showdroppedtemplate))
    app.add_handler(CommandHandler("cleardroppedtemplate",cmd_cleardroppedtemplate))
    app.add_handler(CommandHandler("adddroppedvideo",     cmd_adddroppedvideo))
    app.add_handler(CommandHandler("listdroppedvideos",   cmd_listdroppedvideos))
    app.add_handler(CommandHandler("removedroppedvideo",  cmd_removedroppedvideo))
    app.add_handler(CommandHandler("cleardroppedvideos",  cmd_cleardroppedvideos))
    app.add_handler(CommandHandler("debugscan",           cmd_debugscan))
    app.add_handler(CommandHandler("testdropped",         cmd_testdropped))
    app.add_handler(CommandHandler("ownerhelp2",          cmd_ownerhelp2))
    app.add_handler(CommandHandler("backupnow",           cmd_backupnow))
    app.add_handler(CommandHandler("restorenow",          cmd_restorenow))
    app.add_handler(CommandHandler("setbuttonmedia",     cmd_setbuttonmedia))
    app.add_handler(CommandHandler("clearbuttonmedia",   cmd_clearbuttonmedia))
    app.add_handler(CommandHandler("addx",               cmd_addx))
    app.add_handler(CommandHandler("removex",            cmd_removex))
    app.add_handler(CommandHandler("addxrayvideo",       cmd_addxrayvideo))
    app.add_handler(CommandHandler("listxrayvideos",     cmd_listxrayvideos))
    app.add_handler(CommandHandler("removexrayvideo",    cmd_removexrayvideo))
    app.add_handler(CommandHandler("clearxrayvideos",    cmd_clearxrayvideos))
    app.add_handler(CommandHandler("testxray",           cmd_testxray))
    app.add_handler(CommandHandler("sethistorymedia",    cmd_sethistorymedia))
    app.add_handler(CommandHandler("clearhistorymedia",  cmd_clearhistorymedia))
    app.add_handler(CommandHandler("addpostlink",        cmd_addpostlink))
    app.add_handler(CommandHandler("removepostlink",     cmd_removepostlink))
    app.add_handler(CommandHandler("listpostlinks",      cmd_listpostlinks))
    app.add_handler(CommandHandler("setcommandmedia",    cmd_setcommandmedia))
    app.add_handler(CommandHandler("clearcommandmedia",  cmd_clearcommandmedia))

    # General messages
    # Group / lounge kill-switch — must be registered in the lowest group so it
    # runs before commands, callbacks and message handlers.
    app.add_handler(TypeHandler(Update, _block_group_activity), group=-100)

    app.add_handler(MessageHandler(filters.TEXT | filters.PHOTO | filters.VIDEO, handle_message))

    # Jobs
    app.job_queue.run_repeating(scan_job,            interval=3,         first=20)   # fast: new call detection only
    app.job_queue.run_repeating(monitoring_job,      interval=5,         first=15)   # real-time: bulk DexScreener refresh + milestone alerts
    app.job_queue.run_repeating(leaderboard_job,     interval=90,        first=120)   # every 90 sec
    app.job_queue.run_repeating(champions_job,       interval=90,        first=150)   # every 90 sec
    app.job_queue.run_repeating(trending_job,         interval=120,       first=60)    # every 2 min
    app.job_queue.run_repeating(trending2_job,        interval=120,       first=90)    # every 2 min (posts 3560+3562)
    app.job_queue.run_repeating(momentum_check_job,  interval=86400,     first=300)  # daily
    app.job_queue.run_repeating(backup_job,          interval=1800,      first=60)   # har 30 min Telegram backup
    app.job_queue.run_repeating(userbot_watchdog_job, interval=300,       first=180)
    app.job_queue.run_repeating(baseline_safety_job,  interval=300,       first=240)  # fail-safe scan enable  # har 5 min: userbot alive check + auto-reconnect

    # Startup: notify owner if userbot not connected
    async def _startup_notify(app_ref):
        await init_userbot()

        # Railway ke liye: startup pe Telegram backup se data restore karo
        if userbot_client:
            await restore_data_from_telegram(userbot_client)
            # Silently pre-mark already-passed milestones so monitoring_job
            # does NOT fire duplicate alerts on first run after restart.
            await _silent_catchup_milestones()

        await setup_realtime_monitoring(app_ref.bot)  # instant call detection via Telethon events

        # Start session web generator on port 3002 (proxied via api-server at /api/session)
        try:
            import importlib.util as _ilu
            _sw_spec = _ilu.spec_from_file_location("session_web", "session_web.py")
            _sw = _ilu.module_from_spec(_sw_spec)
            import os as _os
            _os.environ.setdefault("SESSION_BASE", "/api/session")
            _sw_spec.loader.exec_module(_sw)
            from aiohttp import web as _aio_web
            _runner = _aio_web.AppRunner(_sw.app)
            await _runner.setup()
            _site = _aio_web.TCPSite(_runner, "0.0.0.0", 3002)
            await _site.start()
            logger.info("✅ Session web generator started on :3002 → /api/session")
        except Exception as _e_sw:
            logger.warning(f"Session web server failed to start: {_e_sw}")

        # Pre-populate seen_message_ids for ALL channels on every startup.
        # Why ALL (not just empty ones): backup is up to 30 min old — posts in that
        # gap are "unseen" in memory, causing scan_job to flood 50-60 alerts at once.
        # Marking current posts as seen on startup closes that window safely.
        try:
            all_channels = load_channels()
            if all_channels:
                logger.info(f"Startup pre-scan: marking current posts as seen for {len(all_channels)} channel(s)...")
                for ch in all_channels:
                    try:
                        posts = await fetch_channel_posts(ch)
                        added = 0
                        for post in posts:
                            pid = str(post["id"])
                            if pid not in seen_message_ids[ch]:
                                seen_message_ids[ch].add(pid)
                                added += 1
                        if added:
                            logger.info(f"Pre-scan: +{added} new IDs marked seen for @{ch}")
                    except Exception as e_scan:
                        logger.warning(f"Pre-scan failed for @{ch}: {e_scan}")
                _save_seen()
                logger.info("✅ Startup pre-scan complete — old post flooding prevented")
        except Exception as e_prescan:
            logger.warning(f"Startup pre-scan error: {e_prescan}")
        finally:
            global _BASELINE_READY
            _BASELINE_READY = True
            _save_seen()
            logger.info("✅ Baseline ready — scanning enabled (no old-post replay)")

        if not userbot_client and OWNER_ID:
            try:
                await app_ref.bot.send_message(
                    OWNER_ID,
                    "⚠️ <b>Userbot connect nahi hua!</b>\n\n"
                    "Premium emojis kaam nahi karein ge jab tak userbot connect na ho.\n\n"
                    "👉 <b>/userbotlogin</b> bhejo — OTP aayega, enter karo, done!\n\n"
                    "Session ek baar set hone ke baad automatically save ho jaayegi.",
                    parse_mode="HTML"
                )
            except Exception: pass
        elif userbot_client and OWNER_ID:
            try:
                me = await userbot_client.get_me()
                await app_ref.bot.send_message(
                    OWNER_ID,
                    f"✅ <b>Bot started!</b>\nUserbot: @{me.username} connected. Premium emojis ready.",
                    parse_mode="HTML"
                )
            except Exception: pass

    # IMPORTANT: do NOT overwrite the builder's post_init — chain both, otherwise
    # the command menu / seeding step silently never runs.
    async def _background_startup(app_ref):
        try:
            await _startup_notify(app_ref)
        except Exception as e:
            logger.error(f"background startup failed: {type(e).__name__}: {e}")

    async def _combined_post_init(app_ref):
        try:
            await post_init(app_ref)
        except Exception as e:
            logger.error(f"post_init failed: {e}")
        # Telegram polling must start immediately. Restore, pre-scan and Telethon
        # setup can take minutes on a cold Railway deploy, so never await them here.
        asyncio.create_task(_background_startup(app_ref), name="wizard-background-startup")
        logger.info("✅ Command polling released; background startup continues separately")

    app.post_init = _combined_post_init
    app.add_error_handler(_global_error_handler)

    logger.info(f"✅ WIZARD SCAN Bot starting — Owner: {OWNER_ID}")
    # Resilient polling: transient Telegram/network failures must not end the
    # process, otherwise Railway counts it as a crash and restart-loops.
    backoff = 5
    while True:
        try:
            app.run_polling(
                allowed_updates=Update.ALL_TYPES,
                drop_pending_updates=True,
                close_loop=False,
            )
            break  # clean shutdown
        except (KeyboardInterrupt, SystemExit):
            break
        except Exception as e:
            logger.error(f"Polling crashed: {type(e).__name__}: {e} — restarting in {backoff}s")
            time.sleep(backoff)
            backoff = min(backoff * 2, 300)

if __name__ == "__main__":
    main()
