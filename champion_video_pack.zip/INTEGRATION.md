# Champion KOL X-alert videos — setup

Files (drop into repo root of loyal6504-prog/Zard):
- champion_video.py
- assets/wizard_logo.png      (replace with your HD logo, square PNG, transparent corners, 1000px+)
- assets/fonts/Poppins-Bold.ttf

requirements.txt: add
    Pillow
    numpy
    imageio-ffmpeg        # bundles ffmpeg, no apt needed

Tier colours (details screen only; 3s intro logo is always gold):
    2-10x red | 11-20x blue | 21-30x orange | 31-50x green
    51-70x purple | 71-99x green+purple | 100x+ black & white

## Hook (inside send_alert, X-alert branch, BEFORE the normal media send)
Draft — adapt names to your real send_alert code:

    badge = _get_kol_badge(channel)
    if x_style and badge and badge.get("type") != "leaderboard":      # CHAMPION KOL only
        import champion_video
        vid = await champion_video.champion_alert_video(
            channel=channel, x_val=x_val, chain=chain, entry_fmt=_mc_no_label(entry_fmt),
            cur_fmt=_mc_no_label(current_fmt), ca=ca, symbol=symbol,
            stats=_champion_stats(channel),            # dict(rank, points, calls, win_rate)
            avatar_path=None)                          # optional KOL profile photo path
        if vid:
            # send `vid` as a video (supports_streaming=True, width=1920, height=820)
            # with the SAME caption/text the alert already uses. If vid is None -> normal alert.

At bot start (so first alert is fast), in a thread:
    threading.Thread(target=champion_video.warmup, daemon=True).start()

Env (optional): CHAMPION_VIDEO_TIMEOUT=12  CHAMPION_LOGO=...  CHAMPION_FONT=...
Videos are cached in $DATA_DIR/champion_videos and auto-deleted after 3h.
